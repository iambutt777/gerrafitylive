// tiktok.js — TikTok LIVE connection, kept separate from the game engine.
// It turns raw TikTok webcast events into three simple, normalized events:
//   { type: 'like',  user, count }
//   { type: 'share', user }
//   { type: 'gift',  user, coins, giftName, repeat }
// The browser game never talks to TikTok directly; it only sees these.
//
// Works with tiktok-live-connector 2.x (TikTokLiveConnection, ES module) and
// falls back to 1.x (WebcastPushConnection). Field names differ between
// versions, so every value is read defensively from several possible places.

const { EventEmitter } = require('events');

let libPromise = null;
function loadLib() {
  if (!libPromise) {
    libPromise = import('tiktok-live-connector')
      .then((mod) => {
        const lib = mod.TikTokLiveConnection || mod.WebcastPushConnection ? mod : mod.default || mod;
        const Conn = lib.TikTokLiveConnection || lib.WebcastPushConnection;
        if (!Conn) throw new Error('tiktok-live-connector loaded, but no connection class was found.');
        return { Conn, SignConfig: lib.SignConfig || null, version: lib.TikTokLiveConnection ? 2 : 1 };
      })
      .catch((err) => {
        libPromise = null;
        throw err;
      });
  }
  return libPromise;
}

const first = (...vals) => vals.find((v) => v !== undefined && v !== null && v !== '');

function pictureUrl(p) {
  if (!p) return '';
  if (typeof p === 'string') return p;
  const list = p.url || p.urls || p.urlList || p.url_list;
  if (Array.isArray(list) && list.length) return String(list.find((u) => /^https?:/.test(u)) || list[0]);
  return '';
}

function toUser(d) {
  const u = d.user || d.userDetails || d;
  const handle = String(first(u.uniqueId, u.unique_id, d.uniqueId, u.displayId, '') || '');
  return {
    id: String(first(u.uniqueId, d.uniqueId, u.userId, u.id, d.userId, handle, 'viewer')),
    handle,
    name: String(first(u.nickname, d.nickname, handle, 'viewer')),
    avatar: first(
      d.profilePictureUrl,
      u.profilePictureUrl,
      pictureUrl(u.profilePicture),
      pictureUrl(u.avatarThumb),
      pictureUrl(u.avatarMedium),
      pictureUrl(u.avatarLarger),
      '',
    ),
  };
}

function giftInfo(d) {
  const det = d.giftDetails || d.gift || {};
  const ext = d.extendedGiftInfo || {};
  return {
    id: String(first(d.giftId, det.id, det.giftId, ext.id, 'gift')),
    name: String(first(d.giftName, det.giftName, det.name, ext.name, 'Gift')),
    perGift: Number(first(
      d.diamondCount, d.diamond_count, d.coins, d.coinCount,
      det.diamondCount, det.diamond_count, det.coins, det.price,
      ext.diamond_count, ext.diamondCount, 0,
    )) || 0,
    type: first(d.giftType, det.giftType, det.type, ext.type),
    repeat: Math.max(1, Number(first(d.repeatCount, d.comboCount, det.repeatCount, 1)) || 1),
    repeatEnd: Boolean(first(d.repeatEnd, d.repeat_end, false)),
  };
}

function friendlyError(err) {
  const msg = (err && (err.message || err.toString())) || String(err);
  if (/Business plan|Purchase one at|402|401/i.test(msg)) {
    return 'The free TikTok signing service (Euler Stream) refused the request. Add a free Euler API key below (eulerstream.com, then Dashboard, API Keys) and press Connect again.';
  }
  if (/offline|not.*live|LIVE has ended|isn't online|UserOfflineError/i.test(msg)) {
    return 'That account is not live right now. Start your LIVE first, then press Connect.';
  }
  if (/captcha/i.test(msg)) return 'TikTok asked for a captcha. Retrying a different way…';
  if (/rate.?limit|429/i.test(msg)) return 'The free connection service is rate-limited. Wait a minute and try again.';
  if (/ENOTFOUND|EAI_AGAIN|ECONNRESET|ETIMEDOUT|network/i.test(msg)) return 'Network problem reaching TikTok. Check the internet connection.';
  if (/Cannot find (module|package)|ERR_MODULE_NOT_FOUND/i.test(msg)) return 'tiktok-live-connector is not installed. Run "npm install --ignore-scripts".';
  return msg;
}

class TikTokBridge extends EventEmitter {
  constructor() {
    super();
    this.conn = null;
    this.username = null;
    this.state = 'disconnected';
    this.lastError = null;
    this.retries = 0;
    this.manualStop = true;
    this.reconnectTimer = null;
    this.version = null;
    this.available = true; // corrected after the first load attempt
    this.streaks = new Map();
    this.counts = { like: 0, share: 0, gift: 0 };
    this.apiKey = process.env.EULER_API_KEY || '';
    loadLib().then((l) => { this.version = l.version; }).catch(() => { this.available = false; });
  }

  status() {
    return { state: this.state, username: this.username, available: this.available, error: this.lastError, version: this.version, hasKey: Boolean(this.apiKey) };
  }

  _setState(state) {
    this.state = state;
    this.emit('status', this.status());
  }

  setApiKey(key) {
    this.apiKey = String(key || '').trim();
  }

  async connect(username) {
    const clean = String(username || '').trim().replace(/^@/, '').replace(/^https?:\/\/(www\.)?tiktok\.com\/@/, '').split(/[/?]/)[0];
    if (!/^[A-Za-z0-9._]{2,24}$/.test(clean)) throw new Error('That does not look like a TikTok username.');
    this.disconnect();
    this.manualStop = false;
    this.username = clean;
    this.retries = 0;
    await this._open();
  }

  async _open() {
    clearTimeout(this.reconnectTimer);
    this._setState('connecting');
    let lib;
    try {
      lib = await loadLib();
      this.available = true;
      this.version = lib.version;
    } catch (err) {
      this.available = false;
      this.lastError = friendlyError(err);
      this._setState('error');
      throw new Error(this.lastError);
    }
    // Only features that work on Euler Stream's free tier: no gift catalogue
    // download (coin values already arrive with each gift) and no room lookup
    // through Euler (Business plan only).
    const options = {
      processInitialData: false,
      enableExtendedGiftInfo: false,
      requestPollingIntervalMs: 2000,
    };
    if (lib.version === 2) {
      options.fetchRoomInfoOnConnect = true;
      if (this.apiKey) {
        options.signApiKey = this.apiKey;
        if (lib.SignConfig) lib.SignConfig.apiKey = this.apiKey;
      }
    }
    const conn = new lib.Conn(this.username, options);
    this.conn = conn;
    this._wire(conn);
    try {
      const st = await conn.connect();
      this.retries = 0;
      this.lastError = null;
      console.log(`[tiktok] connected to @${this.username} (room ${st && st.roomId}) using connector v${lib.version}`);
      this._setState('connected');
    } catch (err) {
      const raw = (err && err.message) || String(err);
      console.log(`[tiktok] connect failed: ${raw}`);
      this.lastError = friendlyError(err);
      this._setState('error');
      this._scheduleReconnect();
      throw new Error(this.lastError);
    }
  }

  _wire(conn) {
    conn.on('like', (d) => {
      const count = Number(first(d.likeCount, d.count, 0)) || 0;
      if (count <= 0) return;
      this.counts.like += count;
      this.emit('event', { type: 'like', user: toUser(d), count });
    });

    conn.on('share', (d) => {
      this.counts.share++;
      this.emit('event', { type: 'share', user: toUser(d) });
    });

    conn.on('gift', (d) => this._onGift(d));

    // someone joins the LIVE
    conn.on('member', (d) => {
      const user = toUser(d);
      if (user.handle || user.name) this.emit('event', { type: 'join', user });
    });

    conn.on('roomUser', (d) => {
      const n = Number(first(d.viewerCount, d.totalUser, d.total));
      if (Number.isFinite(n)) this.emit('viewers', n);
    });

    conn.on('streamEnd', () => {
      if (this.conn !== conn) return;
      this.lastError = 'The LIVE has ended.';
      this._setState('ended');
    });

    conn.on('disconnected', () => {
      if (this.conn !== conn || this.manualStop) return;
      console.log('[tiktok] disconnected, will retry');
      this._setState('disconnected');
      this._scheduleReconnect();
    });

    conn.on('error', (err) => {
      this.lastError = friendlyError(err);
    });
  }

  /**
   * Streak gifts fire on every tap. Count each streak once: when it ends, or if
   * no "end" ever arrives, 3 seconds after the last tap.
   */
  _onGift(d) {
    const g = giftInfo(d);
    const user = toUser(d);
    const key = `${user.id}:${g.id}`;
    const flush = (info) => {
      this.streaks.delete(key);
      // if TikTok sent no coin value, still paint the gift (as 1 coin) instead of dropping it
      const per = info.perGift > 0 ? info.perGift : 1;
      if (info.perGift <= 0) console.log(`[tiktok] gift without a coin value, counted as 1 coin. Fields received: ${Object.keys(d).join(', ')}`);
      const coins = per * info.repeat;
      this.counts.gift++;
      console.log(`[tiktok] gift: @${user.handle} ${info.name} x${info.repeat} = ${coins} coins`);
      this.emit('event', { type: 'gift', user, coins, repeat: info.repeat, giftName: info.name });
    };
    const pending = this.streaks.get(key);
    if (pending) clearTimeout(pending.timer);
    // a finished streak, or a gift that can't be streaked, counts right away
    if (g.repeatEnd || (g.type !== undefined && g.type !== 1)) return flush(g);
    this.streaks.set(key, { timer: setTimeout(() => flush(g), 3000) });
  }

  _scheduleReconnect() {
    if (this.manualStop || this.state === 'ended') return;
    clearTimeout(this.reconnectTimer);
    const delay = Math.min(60000, 5000 * Math.pow(1.6, this.retries++));
    this.reconnectTimer = setTimeout(() => {
      this._open().catch(() => {});
    }, delay);
  }

  disconnect() {
    this.manualStop = true;
    clearTimeout(this.reconnectTimer);
    for (const s of this.streaks.values()) clearTimeout(s.timer);
    this.streaks.clear();
    if (this.conn) {
      try { this.conn.disconnect(); } catch (e) { /* already closed */ }
      this.conn.removeAllListeners();
      this.conn = null;
    }
    if (this.state !== 'disconnected') this._setState('disconnected');
  }
}

module.exports = { TikTokBridge, toUser, giftInfo };
