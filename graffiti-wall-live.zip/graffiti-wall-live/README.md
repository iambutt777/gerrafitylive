# Graffiti Wall LIVE

A 3D TikTok LIVE game. A graffiti artist walks along an endless concrete wall and paints your viewers onto it: names for likes and shares, sprayed profile pictures for gifts, and a full ladder-climbing golden piece for big gifters. Nothing is ever erased.

## Quick start

**Windows:** double-click `start.bat`. It checks Node.js, installs everything on the first run, starts the game and opens the control panel in your browser, where you connect your TikTok LIVE. Keep its window open while streaming.

**Other systems / manual start:**

You need [Node.js 18 or newer](https://nodejs.org).

```bash
npm install --ignore-scripts
npm start
```

(`--ignore-scripts` skips an optional native speed-up that needs build tools; it is not needed.)

Open **http://localhost:3000**. Press the buttons in the control panel to test every event with the simulator. The control panel sits on the left of the window with the game centred. Press **S**, the Hide button or the small half-transparent gear to hide or show it. The gear can be dragged anywhere on screen (it remembers its place) and the **Up / down** slider at the top of the panel slides the panel lower so you can see the game above it. On phones the panel starts hidden: tap the gear.

To connect a real LIVE, type your TikTok username in the panel and press **Connect** (you must be live at the time). Or connect on startup:

```bash
npm start -- yourtiktokname
```

## Streaming setup (OBS or TikTok LIVE Studio)

1. Add a **Browser source**.
2. URL: `http://localhost:3000/?clean=1` (`clean=1` hides the control panel and the sound prompt).
3. Width **1080**, height **1920**.
4. Tick **Control audio via OBS** so the sound effects go into your stream.
5. Keep a normal browser tab open at `http://localhost:3000` as your private control panel. Both pages share the same wall and events.

Refreshing the browser source does not erase the wall. Finished artwork is saved to `data/wall.json` and redrawn instantly on load.

## What viewers trigger

| Event | What happens |
| --- | --- |
| Viewer joins the LIVE | Their name is sprayed once; nobody is skipped. When several are waiting, up to 4 names are painted together in one welcome piece |
| Like | The viewer's name is sprayed every time they like. Likes that arrive while their name is still waiting merge into it, so the queue never fills with copies. Change to every 10, 20, 40 or 100 likes under "Paint name on" |
| Share | Username with a SHARE badge |
| Gift, 1–4 coins | Sprayed profile picture with the name underneath |
| Gift, 5–19 coins | Three glowing paint bombs splat on the wall, then a neon piece with a BIG GIFTER ribbon |
| Gift, 20–29 coins | Profile picture with angel wings and a halo, chrome letters, VIP GIFTER ribbon, then three fireworks |
| Gift, 30–99 coins | The ladder routine and THE GREAT GIFTER piece, about twice as fast as the original |
| Gift, 100+ coins | A 4x4 pickup and a boom lift drive in while the artist starts the LEGENDARY GIFTER banner. Two helpers ride the lift up and spray a golden glowing picture and name, then fireworks; the crew packs up and drives off in the background while the artist carries on |

**Only one screen saves the wall.** The OBS source (`?clean=1`) saves finished pieces; if it isn't open, the control-panel tab does. Earlier versions saved from both, so a refresh could show pieces twice; use Clear wall once to remove those duplicates.

**What to spray.** In the control panel choose @username or display name; it applies to the wall and every list, in OBS too. Nothing is painted below the artist's shoulder height. "Busy LIVE: likes only as popups" is off by default, so 40 likes always print the name.

**Repeat gifts.** Several gifts from one viewer while they wait merge into one piece (×N), and upgrade to a bigger effect when their total crosses 5, 20, 30 or 100 coins. Once a viewer's picture is on the wall, their later 1–4 coin gifts show as popups instead of being painted again; after 5 more coins they unlock a new piece.

**Speed.** The "Speed" slider in the control panel (0.25x to 3x) changes how fast the artist walks and paints, including the ladder, helpers and spray. It is saved on the server and applies in OBS too.

**Sound.** In the control panel, the effects volume slider also sets the volume in OBS. If you hear every effect twice, untick "Play effects in this tab too".

**Top gifters.** A board shows the 3 viewers who have sent the most coins in total, with gold, silver and bronze ranks. It is saved on the server, so it survives restarts; reset it from the control panel. It can be moved and resized like the other overlay pieces.

**Overlay lists.** Now spraying, Next up, Top gifters and the popups all share one style: a navy board with a bold title, a column heading and ranked rows with a blue value box. Each of the three lists can be switched off under "Overlay lists" in the control panel; this also applies in OBS.

**Moving the overlay.** Drag the "Now painting" banner, the "Next up" list or the popups with the mouse or a finger. Scroll the mouse wheel or pinch on one to resize it, from very small to four times its size; it never gets smaller than about 1 cm and can't be pushed fully off screen, so you can always find it again. Double-click one to reset it. "Show to arrange" in the control panel shows all three even when they are empty. The layout is saved on the server, so arranging it in your browser also moves it in OBS straight away.

**When no one is sending anything**, the artist keeps walking right and spraying short street-art words (LIVE, TAP TAP, FOLLOW…), so the stream never stands still. As soon as a real like, share or gift arrives, he finishes the current letter and paints that viewer next. To change the words, edit `FILLER_WORDS` at the top of `public/js/game.js` (up to 40 characters each; an empty list makes him stand still when idle). To change how fast spray strokes run, edit `SPRAY_SPEED` in `public/js/animations.js` (default 2, meaning twice the base speed).

The artist keeps his paint bucket in his left hand the whole time and walks straight along the wall from one piece to the next. He only steps back and faces the camera when nobody is waiting. Each piece gets its own stretch of wall with 1 m of bare concrete between neighbours; change `ART_GAP` in `public/js/wall.js` to adjust.

Gifts of 2–5 coins count as regular gifts, because the brief only defines tiers for 1, over 5 and over 30. To change any threshold, edit `tierForCoins()` in `public/js/queue.js`. The likes-per-paint number is `LIKES_PER_PAINT` in the same file.

## Running online

See `DEPLOY.md`. Set `ADMIN_PASSWORD` on the server so only you can use the control panel. `TIKTOK_USERNAME` connects automatically (again after every LIVE) and `DATA_DIR` chooses where the wall is saved. For OBS use `/?clean=1&key=YOUR_PASSWORD`.

## URL options

| Option | Effect |
| --- | --- |
| `?clean=1` | Hide the control panel and sound prompt (use on stream) |
| `?hud=0` | Hide the whole overlay, leaving only the 3D scene |
| `?demo=1` | Start the auto demo (random events every few seconds) |
| `?q=low` | Lighter rendering (no shadows, lower resolution). Turned on automatically on phones; use `?q=high` to force full quality |
| `?filler=0` | Stand still when idle instead of spraying street-art words |
| `?debug=1` | Show FPS, texture count and queue length |

## How it is built

```
server.js        Express + Socket.IO; profile-picture proxy; saves the wall
tiktok.js        TikTok LIVE connection (tiktok-live-connector), normalizes events
public/
  index.html     page shell; loads Three.js r160 from jsDelivr
  style.css      overlay styles
  js/game.js         boot, lighting, camera rig, render loop, director
  js/queue.js        event queue: like banking, merging, priorities
  js/animations.js   task scheduler, artist actions, per-event choreography
  js/character.js    articulated artist, two-bone IK, tools, bucket, ladder
  js/art.js          designs each piece and the strokes that reveal it
  js/wall.js         concrete panels, old graffiti, street, painting, baking
  js/effects.js      spray mist, splashes, gold sparks, light pulses
  js/audio.js        all sounds, synthesized live (no audio files)
  js/hud.js          overlay: status, now painting, up next, announcement
  js/net.js          socket client and the event simulator
```

**The TikTok connection stays separate from the game.** `tiktok.js` turns TikTok's raw data into three simple events (`like`, `share`, `gift`) and the server relays them over Socket.IO. The simulator in `net.js` produces exactly the same events, so anything that works in the simulator works live.

**How the event queue works.** Every event goes into `queue.js`. The director in `game.js` takes one job at a time and awaits its whole animation, so animations can never overlap or be interrupted. Special gifts go first, then big gifts, regular gifts, shares and likes. Waiting jobs slowly gain priority, so likes are never starved during a gift storm. When the queue gets long, the artist walks and paints faster (up to about 2.4×) to keep up. Streak gifts are counted once, when the streak ends, so coins are never double counted.

**How painting works.** For each event, the finished artwork is drawn first onto an offscreen canvas. The artist's tool then follows stroke paths over the wall. Each step reveals the finished artwork through a soft brush or spray mask, so the paint appears exactly where the tool passes. Spray strokes also leave overspray speckles on the concrete. When a piece is done, drips run down and splashes land. Then the piece is baked permanently into the wall texture.

**How the movement works.** The walk cycle is procedural. Two-bone inverse kinematics place the painting hand on the wall, the other hand on ladder rails, and the feet on the ground or on ladder rungs. While writing long names, the artist sidesteps along the text and crouches for low letters.

**Profile pictures.** TikTok's image servers do not allow pictures to be used as WebGL textures directly, so `/avatar` on the local server fetches them first. It only accepts TikTok's own image hosts. If a picture fails to load, the viewer gets a generated avatar showing their initial.

## Performance

- Panels are created ahead of the artist, one per frame, so there are no stutters.
- A piece being painted lives on its own small texture. Only that texture is re-uploaded while painting, never the whole wall.
- Wall sections far behind the camera are compressed and released from the GPU, so memory stays flat over a multi-hour LIVE.
- Particles use fixed ring buffers, so nothing is allocated per frame.

Use `?debug=1` to watch FPS and texture count during a long test. The **Busy burst** button fires 30 mixed events in 4 seconds as a stress test.

## Assets

No downloads are needed. The artist, tools, ladder, wall, street and skyline are all built in code. The textures are generated procedurally, and the sounds are synthesized with the Web Audio API. Fonts (Bungee, Permanent Marker, Barlow Condensed) and Three.js load from public CDNs, so the PC running the stream needs internet access, as it does for TikTok anyway.

**Using a professional character model instead.** You can swap in a rigged GLB (for example from Mixamo) in `character.js`. Keep the same joint names (`hips`, `shR`, `elR`, `handR`, `thighL`, `kneeL`, …) mapped to the model's bones, and the existing animation and IK code will drive it.

## Troubleshooting

- **TikTok won't connect**: you must already be live, and the username is the part after the @ (for `tiktok.com/@neon.kai`, type `neon.kai`). The control panel shows the exact reason under the Connect button. Once connected, "Last event" shows each like, share or gift as it arrives, and the terminal prints a `[tiktok]` line for each one.
- The game uses tiktok-live-connector 2.x, which needs a third-party signing service called Euler Stream to connect to TikTok. Without a key you share an anonymous allowance with other users. If the panel says the service refused the request, create a **free** account at eulerstream.com, copy your key from **Dashboard → API Keys**, paste it into the "Euler API key" field in the panel and press Connect. It is saved in `data/config.json`, so you only enter it once.
- Some Euler features need its paid Business plan. The game deliberately avoids them: it doesn't download the gift catalogue (coin values come with each gift) and it doesn't look up rooms through Euler.
- If TikTok changes something again, run `npm install tiktok-live-connector@latest --ignore-scripts`.
- **No sound in OBS**: tick "Control audio via OBS" on the browser source. In a normal browser, click once on the page.
- **Low FPS**: add `&q=low` to the URL, or lower the browser source FPS to 30.
- **Clear the wall**: use **Clear wall** in the control panel, or delete `data/wall.json` while the server is stopped.
