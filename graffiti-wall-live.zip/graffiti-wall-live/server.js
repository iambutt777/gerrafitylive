// server.js — serves the game, relays TikTok LIVE events over Socket.IO,
// proxies profile pictures (TikTok's CDN blocks direct WebGL texture use),
// and saves the finished wall so a browser-source refresh never erases it.
//
// Usage:
//   npm start                      → open http://localhost:3000 and connect from the panel
//   npm start -- yourtiktokname    → connects to that LIVE on startup
//   npm run sim                    → simulator only

const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const { TikTokBridge } = require('./tiktok');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const WALL_FILE = path.join(DATA_DIR, 'wall.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const BOARD_FILE = path.join(DATA_DIR, 'leaderboard.json');
const args = process.argv.slice(2);
const noTikTok = args.includes('--no-tiktok');
const startUser = args.find((a) => !a.startsWith('--')) || process.env.TIKTOK_USERNAME || '';

// Online use: set ADMIN_PASSWORD so only you can use the control panel (connect, clear wall,
// settings, test events) and so only your screens save the wall. Viewers can still watch.
const ADMIN_PASSWORD = String(process.env.ADMIN_PASSWORD || '');
const sha = (v) => crypto.createHash('sha256').update(String(v)).digest();
const passwordOk = (k) => crypto.timingSafeEqual(sha(k), sha(ADMIN_PASSWORD));

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 256 * 1024 });
const bridge = new TikTokBridge();

// local settings: optional Euler Stream API key and the overlay layout
let config = {};
try {
  config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) || {};
  if (config.eulerApiKey && !process.env.EULER_API_KEY) bridge.setApiKey(config.eulerApiKey);
} catch { config = {}; }
function saveConfig() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config));
  } catch (err) {
    console.error('Could not save settings:', err.message);
  }
}
function saveApiKey(key) {
  config.eulerApiKey = key;
  saveConfig();
}
function cleanLayout(l) {
  const out = {};
  if (!l || typeof l !== 'object') return out;
  const lim = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  for (const key of ['now', 'queue', 'popups', 'top']) {
    const v = l[key];
    if (v && [v.x, v.y, v.s].every(Number.isFinite)) {
      out[key] = { x: lim(v.x, -1.5, 1.5), y: lim(v.y, -1.5, 1.5), s: lim(v.s, 0.02, 4) };
    }
  }
  return out;
}
let lastViewers = null;
// the account to keep connecting to, e.g. every time you go live again (running online 24/7)
let autoUser = noTikTok ? '' : startUser;

// ---------- top gifters (total coins per viewer, kept across restarts) ----------
let board = {};
try {
  board = JSON.parse(fs.readFileSync(BOARD_FILE, 'utf8')) || {};
} catch { board = {}; }
let boardTimer = null;
function saveBoard() {
  clearTimeout(boardTimer);
  boardTimer = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(BOARD_FILE, JSON.stringify(board));
    } catch (err) {
      console.error('Could not save top gifters:', err.message);
    }
  }, 500);
}
function boardTop(n = 3) {
  return Object.values(board).sort((a, b) => b.coins - a.coins).slice(0, n);
}
function addToBoard(e) {
  if (e.type !== 'gift') return;
  const u = e.user || {};
  const id = String(u.id || u.handle || '');
  const coins = Math.max(0, Math.floor(Number(e.coins) || 0));
  if (!id || !coins) return;
  const avatar = /^https?:/.test(String(u.avatar || '')) ? String(u.avatar) : '';
  const entry = board[id] || (board[id] = { user: { id, handle: String(u.handle || ''), name: String(u.name || '') }, coins: 0 });
  entry.coins += coins;
  entry.user.avatar = avatar || entry.user.avatar || '';
  saveBoard();
  io.emit('leaderboard', boardTop());
}

/** Every LIVE event (real or simulated) goes through here, so all screens stay in sync. */
function handleLive(e) {
  io.emit('live', e);
  addToBoard(e);
}

function cleanSimEvent(e) {
  if (!e || typeof e !== 'object' || !['like', 'share', 'gift', 'join'].includes(e.type)) return null;
  const u = e.user && typeof e.user === 'object' ? e.user : null;
  if (!u) return null;
  const user = {
    id: String(u.id || u.handle || '').slice(0, 40),
    handle: String(u.handle || '').slice(0, 40),
    name: String(u.name || '').slice(0, 60),
    avatar: String(u.avatar || '').slice(0, 200000),
  };
  if (!user.id) return null;
  return {
    type: e.type,
    user,
    count: Math.max(0, Math.min(10000, Math.floor(Number(e.count) || 0))),
    coins: Math.max(0, Math.min(100000, Math.floor(Number(e.coins) || 0))),
    giftName: String(e.giftName || 'Gift').slice(0, 40),
  };
}

app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0 }));

// ---------- profile picture proxy ----------
const ALLOWED_HOSTS = [
  /(^|\.)tiktokcdn\.com$/i,
  /(^|\.)tiktokcdn-us\.com$/i,
  /(^|\.)tiktokcdn-eu\.com$/i,
  /(^|\.)ibyteimg\.com$/i,
  /(^|\.)byteimg\.com$/i,
  /(^|\.)muscdn\.com$/i,
  /(^|\.)tiktokv\.com$/i,
];
const avatarCache = new Map(); // url → { type, buf }
const AVATAR_CACHE_MAX = 400;

app.get('/avatar', async (req, res) => {
  let url;
  try {
    url = new URL(String(req.query.url || ''));
  } catch {
    return res.status(400).end();
  }
  if (url.protocol !== 'https:' || !ALLOWED_HOSTS.some((r) => r.test(url.hostname))) {
    return res.status(403).end();
  }
  const key = url.toString();
  const hit = avatarCache.get(key);
  if (hit) {
    avatarCache.delete(key);
    avatarCache.set(key, hit);
    return res.set('Content-Type', hit.type).set('Cache-Control', 'public, max-age=86400').send(hit.buf);
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const r = await fetch(key, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://www.tiktok.com/' },
    });
    if (!r.ok) return res.status(502).end();
    const type = r.headers.get('content-type') || '';
    if (!type.startsWith('image/')) return res.status(415).end();
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length > 3 * 1024 * 1024) return res.status(413).end();
    avatarCache.set(key, { type, buf });
    if (avatarCache.size > AVATAR_CACHE_MAX) avatarCache.delete(avatarCache.keys().next().value);
    res.set('Content-Type', type).set('Cache-Control', 'public, max-age=86400').send(buf);
  } catch {
    res.status(504).end();
  } finally {
    clearTimeout(timer);
  }
});

// ---------- wall persistence ----------
let wall = [];
try {
  wall = JSON.parse(fs.readFileSync(WALL_FILE, 'utf8'));
  if (!Array.isArray(wall)) wall = [];
} catch {
  wall = [];
}

let saveTimer = null;
function saveWall() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = WALL_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(wall));
      fs.renameSync(tmp, WALL_FILE);
    } catch (err) {
      console.error('Could not save the wall:', err.message);
    }
  }, 500);
}

function validRecord(r) {
  return r && typeof r === 'object' && typeof r.kind === 'string' &&
    Number.isFinite(r.x0) && Number.isFinite(r.y0) && r.user && typeof r.user === 'object' &&
    JSON.stringify(r).length < 16384;
}

// ---------- sockets ----------
// ---------- one screen saves the wall ----------
// The control-panel tab and the OBS source both run the game. Only one of them may
// save finished pieces, otherwise every piece is stored twice. The OBS source
// (?clean=1) is preferred; otherwise the first screen that connected saves.
const screens = new Map(); // socket.id → { clean, at }
let recorderId = null;
function updateRecorder() {
  const list = [...screens.entries()].filter(([, v]) => v.admin);
  const clean = list.filter(([, v]) => v.clean).sort((a, b) => b[1].at - a[1].at);
  const any = list.sort((a, b) => a[1].at - b[1].at);
  const next = (clean[0] || any[0] || [null])[0];
  if (next === recorderId) return;
  recorderId = next;
  for (const [id] of screens) io.to(id).emit('role', { recorder: id === recorderId });
}

io.on('connection', (socket) => {
  screens.set(socket.id, { clean: false, at: Date.now(), admin: !ADMIN_PASSWORD });
  const isAdmin = () => !ADMIN_PASSWORD || (screens.get(socket.id) || {}).admin === true;
  let failedLogins = 0;
  updateRecorder();
  socket.on('hello', (info) => {
    const key = info && typeof info.key === 'string' ? info.key.slice(0, 200) : '';
    let ok = !ADMIN_PASSWORD;
    if (ADMIN_PASSWORD && key) {
      ok = passwordOk(key);
      if (!ok && ++failedLogins >= 5) return socket.disconnect(true);
    }
    screens.set(socket.id, { clean: Boolean(info && info.clean), at: Date.now(), admin: ok });
    updateRecorder();
    socket.emit('role', { recorder: socket.id === recorderId });
    socket.emit('auth', { required: Boolean(ADMIN_PASSWORD), admin: ok, wrong: Boolean(ADMIN_PASSWORD && key && !ok) });
  });
  socket.on('disconnect', () => {
    screens.delete(socket.id);
    updateRecorder();
  });

  socket.emit('status', { ...bridge.status(), available: bridge.available && !noTikTok });
  socket.emit('history', wall);
  socket.emit('leaderboard', boardTop());
  if (config.prefs) socket.emit('prefs', config.prefs);

  // effects volume set in the control panel applies to every screen (including OBS)
  // control-panel settings that apply to every screen: effects volume and which lists are shown
  socket.on('prefs:set', (p) => {
    if (!isAdmin()) return;
    if (!p || typeof p !== 'object') return;
    const prefs = config.prefs || {};
    const volume = Number(p.volume);
    if (Number.isFinite(volume)) prefs.volume = Math.max(0, Math.min(1, volume));
    const speed = Number(p.speed);
    if (Number.isFinite(speed)) prefs.speed = Math.max(0.25, Math.min(3, speed));
    if (p.nameMode === 'name' || p.nameMode === 'handle') prefs.nameMode = p.nameMode;
    if (typeof p.joins === 'boolean') prefs.joins = p.joins;
    if (typeof p.likePopups === 'boolean') prefs.likePopups = p.likePopups;
    if ([1, 10, 20, 40, 100].includes(Number(p.likeEvery))) prefs.likeEvery = Number(p.likeEvery);
    if (p.show && typeof p.show === 'object') {
      prefs.show = { now: p.show.now !== false, queue: p.show.queue !== false, top: p.show.top !== false };
    }
    config.prefs = prefs;
    saveConfig();
    socket.broadcast.emit('prefs', prefs);
  });

  // test events from the control panel are relayed to every screen (including OBS)
  socket.on('sim:event', (e) => {
    if (!isAdmin()) return;
    const clean = cleanSimEvent(e);
    if (clean) handleLive(clean);
  });

  socket.on('leaderboard:reset', () => {
    if (!isAdmin()) return;
    board = {};
    saveBoard();
    io.emit('leaderboard', []);
  });
  if (config.layout) socket.emit('layout', config.layout);
  if (lastViewers != null) socket.emit('viewers', lastViewers);

  // arranging the overlay in one browser moves it everywhere (e.g. the OBS source) live
  socket.on('layout:set', (layout) => {
    if (!isAdmin()) return;
    config.layout = cleanLayout(layout);
    saveConfig();
    socket.broadcast.emit('layout', config.layout);
  });

  socket.on('tiktok:connect', async (payload, ack) => {
    const reply = typeof ack === 'function' ? ack : () => {};
    if (!isAdmin()) return reply({ ok: false, error: 'Not logged in as admin. Reload the page and enter the admin password.' });
    if (noTikTok) return reply({ ok: false, error: 'Server started in simulator-only mode.' });
    const username = typeof payload === 'string' ? payload : payload && payload.username;
    const apiKey = payload && typeof payload === 'object' ? String(payload.apiKey || '').trim() : '';
    if (apiKey) {
      bridge.setApiKey(apiKey);
      saveApiKey(apiKey);
    }
    try {
      await bridge.connect(username);
      autoUser = bridge.username || autoUser;
      reply({ ok: true });
    } catch (err) {
      reply({ ok: false, error: (err && err.message) || String(err) });
    }
  });

  socket.on('tiktok:disconnect', (ack) => {
    if (!isAdmin()) return;
    autoUser = '';
    bridge.disconnect();
    if (typeof ack === 'function') ack({ ok: true });
  });

  socket.on('art:done', (record) => {
    if (socket.id !== recorderId || !validRecord(record)) return;
    wall.push(record);
    saveWall();
  });

  socket.on('wall:reset', (ack) => {
    if (!isAdmin()) return typeof ack === 'function' && ack({ ok: false });
    wall = [];
    saveWall();
    io.emit('wall:cleared');
    if (typeof ack === 'function') ack({ ok: true });
  });
});

bridge.on('event', (e) => {
  handleLive(e);
  if (e.type === 'share') console.log(`[tiktok] share: @${e.user.handle}`);
  if (e.type === 'like') console.log(`[tiktok] likes: @${e.user.handle} +${e.count}`);
});
bridge.on('viewers', (n) => {
  lastViewers = n;
  io.emit('viewers', n);
});
bridge.on('status', (s) => io.emit('status', { ...s, available: bridge.available && !noTikTok }));

server.listen(PORT, () => {
  console.log(`Graffiti Wall LIVE running at http://localhost:${PORT}`);
  console.log('Add that address as a 1080 x 1920 browser source in OBS / TikTok LIVE Studio.');
  if (startUser && !noTikTok) {
    bridge.connect(startUser)
      .then(() => console.log(`Connected to @${bridge.username}'s LIVE`))
      .catch((err) => console.log(`Could not connect to @${startUser}: ${err.message} (retrying)`));
  }
});

// when a LIVE ends the connection stops; this connects again for your next LIVE
setInterval(() => {
  if (!autoUser || bridge.state !== 'ended') return;
  console.log(`[tiktok] LIVE ended, waiting for the next one from @${autoUser}`);
  bridge.connect(autoUser).catch(() => {});
}, 60000);

process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => {
  bridge.disconnect();
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(WALL_FILE, JSON.stringify(wall)); } catch {}
  process.exit(0);
});
