// hud.js — the 2D overlay on top of the 3D scene: connection status,
// "now painting" card, the up-next queue, the great-gifter announcement
// and the control panel used to connect TikTok or simulate events.

import { avatarDataURL, avatarSrc, displayName } from './art.js';

const el = (tag, cls, parent, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  if (parent) parent.appendChild(n);
  return n;
};

const ICON = { join: '✋', like: '♥', share: '↗', gift: '★', big: '★★', vip: '✦', special: '♛', legendary: '♛♛' };
const DEFAULT_SPOT = { x: 0, y: 0, s: 1 };
const MIN_VISIBLE_PX = 38; // about 1 cm on a normal screen: never smaller, never fully off screen
const SCALE_MIN = 0.02, SCALE_MAX = 4;
const clampNum = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

export class Hud {
  constructor(root, { useProxy, clean }) {
    this.root = root;
    this.useProxy = useProxy;
    this.avatarCache = new Map();
    root.classList.toggle('clean', Boolean(clean));


    // movable, resizable overlay pieces (drag; wheel or pinch to resize; double-click to reset)
    this.layout = {};
    this.movers = {};
    this.onLayout = null;
    const nowWrap = this._mover('now-wrap', 'now');
    const queueWrap = this._mover('queue-wrap', 'queue');
    const popWrap = this._mover('pop-wrap', 'popups');
    const topWrap = this._mover('top-wrap', 'top');
    this.topBox = el('div', 'top-gifters', topWrap);
    el('div', 'top-title', this.topBox, 'Top gifters');
    this.topList = el('ol', 'top-list', this.topBox);
    this._topIds = '';

    this.now = el('div', 'now tape', nowWrap);
    this.nowImg = el('img', 'av', this.now);
    this.nowImg.alt = '';
    const nowText = el('div', 'now-text', this.now);
    this.nowName = el('div', 'name', nowText);
    this.nowWhat = el('div', 'what', nowText);

    this.queueBox = el('div', 'queue', queueWrap);
    el('div', 'queue-title', this.queueBox, 'Next up');
    this.queueList = el('ol', 'queue-list', this.queueBox);
    this.queueMore = el('div', 'queue-more', this.queueBox);

    this.ann = el('div', 'announce', root);
    this.ann.setAttribute('aria-live', 'polite');
    el('div', 'burst', this.ann);
    this.annImg = el('img', 'ann-av', this.ann);
    this.annImg.alt = '';
    this.annTitle = el('div', 'ann-title', this.ann, 'The Great Gifter');
    this.annName = el('div', 'ann-name', this.ann);
    this.annGift = el('div', 'ann-gift', this.ann);

    this.popBox = el('div', 'popups', popWrap);
    this.popBox.setAttribute('aria-live', 'polite');

    this.flashEl = el('div', 'flash', root);
    this.soundChip = el('button', 'sound-chip', root, 'Tap to turn on sound');
    this.soundChip.type = 'button';
    this.soundChip.hidden = true;
  }

  avatarFor(user) {
    const src = avatarSrc(user, this.useProxy);
    if (src) return src;
    const key = user.id || user.handle;
    if (!this.avatarCache.has(key)) {
      this.avatarCache.set(key, avatarDataURL(user));
      if (this.avatarCache.size > 200) this.avatarCache.delete(this.avatarCache.keys().next().value);
    }
    return this.avatarCache.get(key);
  }

  describe(job) {
    if (job.kind === 'join') return 'joined the LIVE';
    if (job.kind === 'joins') return `+${job.users.length - 1} more new viewers`;
    if (job.kind === 'like') return job.likes > 1 ? `${job.likes} likes` : 'liked the LIVE';
    if (job.kind === 'share') return job.count > 1 ? `shared the LIVE ${job.count} times` : 'shared the LIVE';
    const coins = `${job.coins} coin${job.coins === 1 ? '' : 's'}`;
    const times = job.count > 1 ? ` ×${job.count}` : '';
    return `${job.giftName || 'Gift'}${times}, ${coins}`;
  }

  /** Connection status now only appears in the control panel, never on the stream. */
  setStatus(text, tone = 'sim') {
    this.status = { text, tone };
  }

  setQueue(jobs, total) {
    this.queueList.replaceChildren();
    if (!jobs.length) el('li', 'q-item tape q-empty', this.queueList, 'No one waiting');
    for (const job of jobs) {
      const li = el('li', `q-item tape k-${job.kind}`, this.queueList);
      const img = el('img', 'av', li);
      img.alt = '';
      img.src = this.avatarFor(job.user);
      el('span', 'q-name', li, displayName(job.user));
      el('span', 'q-icon', li, ICON[job.kind] + (job.count > 1 ? ` ×${job.count}` : ''));
    }
    const more = total - jobs.length;
    this.queueMore.textContent = more > 0 ? `+${more} more waiting` : '';
  }

  nowPainting(job) {
    this.currentJob = job;
    this.nowImg.src = this.avatarFor(job.user);
    this.nowName.textContent = displayName(job.user);
    this.nowWhat.textContent = this.describe(job);
    this.now.className = `now tape show k-${job.kind}`;
  }

  giftCard(job) {
    this.now.classList.remove('pop');
    void this.now.offsetWidth;
    this.now.classList.add('pop');
  }

  clearNow() {
    this.currentJob = null;
    if (this.arranging) return;
    this.now.classList.remove('show', 'pop');
  }

  /** Full-screen announcement; resolves when it has finished. */
  announce(job, title = 'The Great Gifter', ms = 3200) {
    this.annTitle.textContent = title;
    this.ann.style.setProperty('--ann-ms', `${ms}ms`);
    this.ann.classList.toggle('legend', job.kind === 'legendary');
    this.annImg.src = this.avatarFor(job.user);
    this.annName.textContent = displayName(job.user);
    this.annGift.textContent = this.describe(job);
    this.ann.classList.remove('show');
    void this.ann.offsetWidth;
    this.ann.classList.add('show');
    this.flash('white');
    return new Promise((resolve) => {
      setTimeout(() => {
        this.ann.classList.remove('show');
        resolve();
      }, ms);
    });
  }

  flash(kind = 'white') {
    this.flashEl.className = 'flash';
    void this.flashEl.offsetWidth;
    this.flashEl.className = `flash go ${kind}`;
  }

  showSoundChip(show, onClick) {
    this.soundChip.hidden = !show;
    this.soundChip.onclick = onClick;
  }

  /** Control panel, docked on the left of the window (outside the 9:16 game). */
  buildPanel({ online, onConnect, onDisconnect, onSim, onReset, onAuto, onResetBoard, audio, onLists, options, onOptions, speed, onSpeed }) {
    const panel = el('aside', 'panel', document.body);
    panel.setAttribute('aria-label', 'Control panel');
    const head = el('div', 'panel-head', panel);
    el('h2', '', head, 'Control panel');
    const hide = el('button', 'ghost', head, 'Hide');
    hide.type = 'button';
    hide.title = 'Hide (S)';

    el('h3', '', panel, 'TikTok LIVE');
    const live = el('div', 'panel-row', panel);
    this.panelStatus = el('p', 'panel-status', live, 'Not connected');
    if (online) {
      const form = el('form', 'connect', live);
      const input = el('input', '', form);
      input.placeholder = 'your TikTok username';
      input.autocomplete = 'off';
      input.autocapitalize = 'off';
      input.spellcheck = false;
      input.setAttribute('aria-label', 'TikTok username');
      try { input.value = localStorage.getItem('gw-username') || ''; } catch {}
      const key = el('input', '', form);
      key.type = 'password';
      key.placeholder = 'Euler API key (optional, free)';
      key.autocomplete = 'off';
      key.setAttribute('aria-label', 'Euler Stream API key');
      this.keyInput = key;
      const buttons = el('div', 'connect-buttons', form);
      const go = el('button', 'primary', buttons, 'Connect');
      go.type = 'submit';
      const stop = el('button', '', buttons, 'Disconnect');
      stop.type = 'button';
      this.connectMsg = el('p', 'msg', live);
      el('p', 'hint', live, 'You must already be live. Use the name after the @, e.g. for tiktok.com/@neon.kai type neon.kai.');
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = input.value.trim();
        if (!name) return;
        try { localStorage.setItem('gw-username', name); } catch {}
        onConnect(name, key.value.trim());
        key.value = '';
      });
      stop.addEventListener('click', onDisconnect);
    } else {
      el('p', 'msg', live, 'Open this page through "npm start" (http://localhost:3000) to connect a real LIVE. The simulator below works either way.');
    }
    this.lastEventEl = el('p', 'last-event', live, 'No LIVE events received yet.');

    if (onSpeed) this._buildSpeed(panel, speed, onSpeed);
    if (options) this._buildOptions(panel, options, onOptions);
    if (audio) this._buildAudio(panel, audio);

    el('h3', '', panel, 'Test events');
    const sim = el('div', 'panel-grid', panel);
    const simButtons = [
      ['Like', 'like'],
      ['Share', 'share'],
      ['Viewer joins', 'join'],
      ['Rose (1 coin)', 'gift1'],
      ['5 Roses, one by one', 'roses'],
      ['5 coins: paint bombs', 'gift5'],
      ['20 coins: VIP wings', 'gift20'],
      ['30 coins: ladder', 'gift30'],
      ['100 coins: legendary', 'gift100'],
      ['Busy burst', 'burst'],
      ['Viewers: real', 'viewers'],
    ];
    for (const [label, kind] of simButtons) {
      const b = el('button', kind === 'gift100' || kind === 'gift30' ? 'gold' : '', sim, label);
      if (kind === 'viewers') this.viewersBtn = b;
      b.type = 'button';
      b.addEventListener('click', () => onSim(kind));
    }

    const foot = el('div', 'panel-row split', panel);
    const autoLabel = el('label', 'check', foot);
    const auto = el('input', '', autoLabel);
    auto.type = 'checkbox';
    el('span', '', autoLabel, 'Auto demo');
    auto.addEventListener('change', () => onAuto(auto.checked));
    const resetBoard = el('button', 'danger', foot, 'Reset top gifters');
    resetBoard.type = 'button';
    resetBoard.addEventListener('click', () => {
      if (confirm('Reset the top gifters board to zero?')) onResetBoard();
    });
    if (online) {
      const reset = el('button', 'danger', foot, 'Clear wall');
      reset.type = 'button';
      reset.addEventListener('click', () => {
        if (confirm('Erase every name and picture on the wall? This cannot be undone.')) onReset();
      });
    }

    el('h3', '', panel, 'Overlay lists');
    const listBox = el('div', 'panel-row', panel);
    this.listChecks = {};
    for (const [key, label] of [['now', 'Now spraying'], ['queue', 'Next up'], ['top', 'Top gifters']]) {
      const lab = el('label', 'check', listBox);
      const box = el('input', '', lab);
      box.type = 'checkbox';
      box.checked = !this.lists || this.lists[key] !== false;
      el('span', '', lab, `Show ${label}`);
      box.addEventListener('change', () => {
        const next = { ...(this.lists || {}), [key]: box.checked };
        this.setLists(next);
        if (onLists) onLists(this.lists);
      });
      this.listChecks[key] = box;
    }

    el('h3', '', panel, 'Overlay layout');
    el('p', 'hint', panel, 'Drag the "Now painting" banner, the "Next up" list and the popups. Scroll or pinch on them to resize; double-click one to reset it.');
    const lay = el('div', 'panel-grid', panel);
    const arrange = el('button', '', lay, 'Show to arrange');
    arrange.type = 'button';
    arrange.addEventListener('click', () => {
      this.setArrange(!this.arranging);
      arrange.textContent = this.arranging ? 'Done arranging' : 'Show to arrange';
    });
    const resetLayout = el('button', '', lay, 'Reset layout');
    resetLayout.type = 'button';
    resetLayout.addEventListener('click', () => {
      for (const key of Object.keys(this.movers)) this.layout[key] = { ...DEFAULT_SPOT };
      this.relayout();
      this._saveLayout();
    });

    // ---- slide the panel up / down: moves its top edge, so all content stays reachable by scrolling ----
    const slide = el('label', 'audio-row panel-slide', head.parentNode);
    head.after(slide);
    el('span', '', slide, 'Up / down');
    const slideInput = el('input', '', slide);
    slideInput.type = 'range';
    slideInput.min = '0';
    slideInput.max = '100';
    slideInput.setAttribute('aria-label', 'Slide the control panel up or down');
    const slideOut = el('output', '', slide);
    const readNum = (k, d) => { try { const v = Number(localStorage.getItem(k)); return Number.isFinite(v) && localStorage.getItem(k) !== null ? v : d; } catch { return d; } };
    const applySlide = () => {
      const v = Number(slideInput.value) / 100;
      const room = Math.max(0, window.innerHeight - 16 - 150);
      panel.style.top = `${Math.round(16 + v * room)}px`;
      slideOut.textContent = `${slideInput.value}%`;
    };
    slideInput.value = String(Math.max(0, Math.min(100, readNum('gw-panel-slide', 0))));
    slideInput.addEventListener('input', () => {
      applySlide();
      try { localStorage.setItem('gw-panel-slide', slideInput.value); } catch { /* private mode */ }
    });
    window.addEventListener('resize', applySlide);
    applySlide();

    // ---- small draggable gear: always on screen, half transparent, tap to open / close the panel ----
    const tab = el('button', 'panel-tab', document.body);
    tab.type = 'button';
    tab.setAttribute('aria-label', 'Control panel');
    tab.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
    const SIZE = 44, EDGE = 6;
    let gx = window.innerWidth - SIZE - 12, gy = 12;
    try {
      const saved = JSON.parse(localStorage.getItem('gw-gear') || 'null');
      if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) { gx = saved.x; gy = saved.y; }
    } catch { /* default spot */ }
    const placeGear = () => {
      gx = Math.max(EDGE, Math.min(window.innerWidth - SIZE - EDGE, gx));
      gy = Math.max(EDGE, Math.min(window.innerHeight - SIZE - EDGE, gy));
      tab.style.left = `${gx}px`;
      tab.style.top = `${gy}px`;
    };
    placeGear();
    window.addEventListener('resize', placeGear);
    let drag = null;
    tab.addEventListener('pointerdown', (e) => {
      drag = { id: e.pointerId, sx: e.clientX, sy: e.clientY, ox: gx, oy: gy, moved: false };
      tab.setPointerCapture(e.pointerId);
    });
    tab.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
      if (!drag.moved && Math.hypot(dx, dy) < 8) return;
      drag.moved = true;
      tab.classList.add('dragging');
      gx = drag.ox + dx;
      gy = drag.oy + dy;
      placeGear();
    });
    const endDrag = (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const moved = drag.moved;
      drag = null;
      tab.classList.remove('dragging');
      if (moved) {
        try { localStorage.setItem('gw-gear', JSON.stringify({ x: gx, y: gy })); } catch { /* private mode */ }
      } else if (e.type === 'pointerup') {
        setOpen(panel.classList.contains('hidden'));
      }
    };
    tab.addEventListener('pointerup', endDrag);
    tab.addEventListener('pointercancel', endDrag);

    const setOpen = (open) => {
      panel.classList.toggle('hidden', !open);
    };
    // on narrow screens (phones) the panel would cover the game, so start closed
    setOpen(window.innerWidth >= 900);
    hide.addEventListener('click', () => setOpen(false));
    window.addEventListener('keydown', (e) => {
      if (e.target && e.target.tagName === 'INPUT') return;
      if (e.key === 's' || e.key === 'S') setOpen(panel.classList.contains('hidden'));
    });
    this.panel = panel;
    return panel;
  }

  setConnectMessage(text, tone = '') {
    if (!this.connectMsg) return;
    this.connectMsg.textContent = text;
    this.connectMsg.dataset.tone = tone;
  }

  setHasKey(has) {
    if (this.keyInput) this.keyInput.placeholder = has ? 'Euler API key saved (type to replace)' : 'Euler API key (optional, free)';
  }

  setPanelStatus(text, tone) {
    if (!this.panelStatus) return;
    this.panelStatus.textContent = text;
    this.panelStatus.dataset.tone = tone;
  }

  /** Shows the most recent real LIVE event, so you can see TikTok is getting through. */
  noteEvent(e) {
    if (!this.lastEventEl) return;
    const who = displayName(e.user || {});
    const coins = Number(e.coins);
    const what = e.type === 'like' ? `sent ${e.count} likes`
      : e.type === 'share' ? 'shared the LIVE'
      : e.type === 'join' ? 'joined the LIVE'
      : `sent ${e.giftName || 'a gift'} (${Number.isFinite(coins) ? coins : 0} coins)`;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    this.lastEventEl.textContent = `Last event ${time}: ${who} ${what}`;
    this.lastEventEl.dataset.tone = 'ok';
  }

  _slider(parent, label, value, onInput) {
    const row = el('label', 'audio-row', parent);
    el('span', '', row, label);
    const input = el('input', '', row);
    input.type = 'range';
    input.min = '0';
    input.max = '100';
    input.value = String(Math.round(value * 100));
    input.setAttribute('aria-label', `${label} volume`);
    const out = el('output', '', row, `${input.value}%`);
    input.addEventListener('input', () => {
      out.textContent = `${input.value}%`;
      onInput(Number(input.value) / 100);
    });
    return { input, out };
  }

  /** Speed of the artist: walking, painting, ladder and helpers. 1x is the normal pace. */
  _buildSpeed(panel, value, onSpeed) {
    el('h3', '', panel, 'Speed');
    const box = el('div', 'panel-row', panel);
    const row = el('label', 'audio-row', box);
    el('span', '', row, 'Paint & walk');
    const input = el('input', '', row);
    input.type = 'range';
    input.min = '25';
    input.max = '300';
    input.step = '5';
    input.setAttribute('aria-label', 'Painting and walking speed');
    const out = el('output', '', row);
    const show = (v) => { input.value = String(Math.round(v * 100)); out.textContent = `${(Number(input.value) / 100).toFixed(2).replace(/0$/, '')}x`; };
    show(value || 1);
    input.addEventListener('input', () => {
      show(Number(input.value) / 100);
      onSpeed(Number(input.value) / 100);
    });
    const reset = el('button', '', box, 'Reset to 1x');
    reset.type = 'button';
    reset.addEventListener('click', () => { show(1); onSpeed(1); });
    el('p', 'hint', box, 'Slower or faster artist. Also applies in OBS.');
    this._speedUI = { show };
  }

  setSpeed(v) {
    if (this._speedUI) this._speedUI.show(v);
  }

  _buildAudio(panel, a) {
    el('h3', '', panel, 'Sound');
    const box = el('div', 'panel-row', panel);
    this.fxSlider = this._slider(box, 'Effects', a.effectsVolume, a.onEffectsVolume);
    const tabLabel = el('label', 'check', box);
    const tabCheck = el('input', '', tabLabel);
    tabCheck.type = 'checkbox';
    tabCheck.checked = a.tabSound;
    el('span', '', tabLabel, 'Play effects in this tab too');
    tabCheck.addEventListener('change', () => a.onTabSound(tabCheck.checked));
    el('p', 'hint', box, 'The effects volume also controls OBS. Untick the box if you hear every effect twice on stream.');
  }

  /** Wall options: what name to spray, greeting new viewers, likes as popups when busy. */
  _buildOptions(panel, opts, onOptions) {
    el('h3', '', panel, 'What to spray');
    const box = el('div', 'panel-row', panel);
    const modes = el('div', 'connect-buttons', box);
    const handleBtn = el('button', '', modes, '@username');
    const nameBtn = el('button', '', modes, 'Display name');
    handleBtn.type = nameBtn.type = 'button';
    const joinLabel = el('label', 'check', box);
    const joinBox = el('input', '', joinLabel);
    joinBox.type = 'checkbox';
    el('span', '', joinLabel, "Spray new viewers' names when they join");
    const perRow = el('label', 'audio-row', box);
    el('span', '', perRow, 'Paint name on');
    const perSel = el('select', 'per-like', perRow);
    for (const n of [1, 10, 20, 40, 100]) {
      const o = el('option', '', perSel, n === 1 ? 'every like' : `every ${n} likes`);
      o.value = String(n);
    }
    const popLabel = el('label', 'check', box);
    const popBox = el('input', '', popLabel);
    popBox.type = 'checkbox';
    el('span', '', popLabel, 'Busy LIVE (over 10 viewers): likes only as popups');
    this._opts = { ...opts };
    const send = () => onOptions && onOptions({ ...this._opts });
    handleBtn.addEventListener('click', () => { this._opts.nameMode = 'handle'; this.setOptions(this._opts); send(); });
    nameBtn.addEventListener('click', () => { this._opts.nameMode = 'name'; this.setOptions(this._opts); send(); });
    joinBox.addEventListener('change', () => { this._opts.joins = joinBox.checked; send(); });
    perSel.addEventListener('change', () => { this._opts.likeEvery = Number(perSel.value); send(); });
    popBox.addEventListener('change', () => { this._opts.likePopups = popBox.checked; send(); });
    this._optUI = { handleBtn, nameBtn, joinBox, popBox, perSel };
    this.setOptions(this._opts);
  }

  setOptions(opts) {
    const prevMode = this._opts && this._opts.nameMode;
    this._opts = { ...(this._opts || {}), ...opts };
    // switching @username / display name redraws the lists straight away
    if (prevMode && prevMode !== this._opts.nameMode) {
      if (this._topData) {
        this._topIds = '';
        this.setTopGifters(this._topData);
      }
      if (this.currentJob) this.nowPainting(this.currentJob);
    }
    const ui = this._optUI;
    if (!ui) return;
    ui.handleBtn.setAttribute('aria-pressed', String(this._opts.nameMode !== 'name'));
    ui.nameBtn.setAttribute('aria-pressed', String(this._opts.nameMode === 'name'));
    ui.joinBox.checked = this._opts.joins !== false;
    ui.popBox.checked = Boolean(this._opts.likePopups);
    ui.perSel.value = String(this._opts.likeEvery || 1);
  }

  setEffectsVolume(v) {
    if (!this.fxSlider) return;
    this.fxSlider.input.value = String(Math.round(v * 100));
    this.fxSlider.out.textContent = `${this.fxSlider.input.value}%`;
  }

  /** Top 3 gifters by total coins: [{ user, coins }]. */
  setTopGifters(list) {
    this._topData = list;
    const ids = list.map((e) => `${e.user.id}:${e.coins}`).join('|');
    if (ids === this._topIds) return;
    const leaderChanged = (list[0]?.user.id || '') !== (this._topIds.split(':')[0] || '');
    this._topIds = ids;
    this.topList.replaceChildren();
    if (!list.length) {
      el('li', 'top-empty', this.topList, 'Send a gift to take first place');
      return;
    }
    list.forEach((e, i) => {
      const li = el('li', `top-item r${i + 1}`, this.topList);
      el('span', 'rank', li, String(i + 1));
      const img = el('img', 'av', li);
      img.alt = '';
      img.src = this.avatarFor(e.user);
      el('span', 'top-name', li, displayName(e.user));
      el('span', 'top-coins', li, `${e.coins.toLocaleString()} coins`);
    });
    if (leaderChanged) {
      this.topBox.classList.remove('bump');
      void this.topBox.offsetWidth;
      this.topBox.classList.add('bump');
    }
  }

  setViewersLabel(text) {
    if (this.viewersBtn) this.viewersBtn.textContent = text;
  }

  // ---------- popups (likes when the LIVE is busy, repeat gifts) ----------
  popup(p) {
    const item = el('div', `pop-item tape p-${p.type}`, this.popBox);
    const img = el('img', 'av', item);
    img.alt = '';
    img.src = this.avatarFor(p.user);
    const text = el('div', 'pop-text', item);
    el('span', 'pop-name', text, displayName(p.user));
    let what;
    if (p.type === 'like') what = `♥ ${p.count} likes`;
    else if (p.upgrade) what = `${p.giftName} again: unlocked a new piece!`;
    else what = `${p.giftName} again +${p.coins} (${p.bank}/5 to a new piece)`;
    el('span', 'pop-what', text, what);
    while (this.popBox.children.length > 5) this.popBox.firstElementChild.remove();
    setTimeout(() => item.classList.add('out'), 3200);
    setTimeout(() => item.remove(), 3700);
  }

  // ---------- movable overlay pieces ----------
  _mover(cls, key) {
    const w = el('div', `mover ${cls}`, this.root);
    w.dataset.key = key;
    this.movers[key] = w;
    this.layout[key] = { ...DEFAULT_SPOT };
    const pts = new Map();
    let base = null;
    const center = () => {
      const arr = [...pts.values()];
      return {
        arr,
        cx: arr.reduce((a, p) => a + p.x, 0) / arr.length,
        cy: arr.reduce((a, p) => a + p.y, 0) / arr.length,
        dist: arr.length > 1 ? Math.hypot(arr[0].x - arr[1].x, arr[0].y - arr[1].y) : 0,
      };
    };
    const begin = () => {
      if (!pts.size) return;
      const c = center();
      base = { st: { ...this.layout[key] }, cx: c.cx, cy: c.cy, dist: c.dist };
    };
    w.addEventListener('pointerdown', (e) => {
      w.setPointerCapture(e.pointerId);
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      w.classList.add('dragging');
      begin();
      e.preventDefault();
    });
    w.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId) || !base) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const c = center();
      const rect = this.root.getBoundingClientRect();
      const st = this.layout[key];
      st.x = clampNum(base.st.x + (c.cx - base.cx) / rect.width, -1.5, 1.5);
      st.y = clampNum(base.st.y + (c.cy - base.cy) / rect.height, -1.5, 1.5);
      if (c.arr.length > 1 && base.dist > 0) st.s = clampNum((base.st.s * c.dist) / base.dist, SCALE_MIN, SCALE_MAX);
      this._applyMover(key);
    });
    const end = (e) => {
      if (!pts.has(e.pointerId)) return;
      pts.delete(e.pointerId);
      if (pts.size) {
        begin();
      } else {
        base = null;
        w.classList.remove('dragging');
        this._saveLayout();
      }
    };
    w.addEventListener('pointerup', end);
    w.addEventListener('pointercancel', end);
    w.addEventListener('wheel', (e) => {
      e.preventDefault();
      const st = this.layout[key];
      st.s = clampNum(st.s * Math.exp(-e.deltaY * 0.0015), SCALE_MIN, SCALE_MAX);
      this._applyMover(key);
      clearTimeout(this._wheelSave);
      this._wheelSave = setTimeout(() => this._saveLayout(), 400);
    }, { passive: false });
    w.addEventListener('dblclick', () => {
      this.layout[key] = { ...DEFAULT_SPOT };
      this._applyMover(key);
      this._saveLayout();
    });
    return w;
  }

  _applyMover(key) {
    const w = this.movers[key];
    const st = this.layout[key] || (this.layout[key] = { ...DEFAULT_SPOT });
    const rect = this.root.getBoundingClientRect();
    if (!rect.width || w.classList.contains('off')) return;
    // as small as you like, but the longest side never drops below ~1 cm
    const base = Math.max(w.offsetWidth, w.offsetHeight, 1);
    st.s = clampNum(st.s, Math.min(1, MIN_VISIBLE_PX / base), SCALE_MAX);
    const set = () => {
      w.style.setProperty('--dx', `${st.x * rect.width}px`);
      w.style.setProperty('--dy', `${st.y * rect.height}px`);
      w.style.setProperty('--sc', String(st.s));
    };
    set();
    // keep at least ~1 cm of it on screen so it can always be found again
    const r = w.getBoundingClientRect();
    let dx = 0, dy = 0;
    if (r.right < rect.left + MIN_VISIBLE_PX) dx = rect.left + MIN_VISIBLE_PX - r.right;
    if (r.left > rect.right - MIN_VISIBLE_PX) dx = rect.right - MIN_VISIBLE_PX - r.left;
    if (r.bottom < rect.top + MIN_VISIBLE_PX) dy = rect.top + MIN_VISIBLE_PX - r.bottom;
    if (r.top > rect.bottom - MIN_VISIBLE_PX) dy = rect.bottom - MIN_VISIBLE_PX - r.top;
    if (dx || dy) {
      st.x += dx / rect.width;
      st.y += dy / rect.height;
      set();
    }
  }

  /** Turns the three lists on or off: { now, queue, top }. */
  setLists(show = {}) {
    this.lists = { now: show.now !== false, queue: show.queue !== false, top: show.top !== false };
    for (const key of ['now', 'queue', 'top']) {
      this.movers[key].classList.toggle('off', !this.lists[key]);
      if (this.listChecks && this.listChecks[key]) this.listChecks[key].checked = this.lists[key];
    }
    this.relayout();
  }

  relayout() {
    for (const key of Object.keys(this.movers)) this._applyMover(key);
  }

  /** Applies a saved layout: { now, queue, popups } each { x, y, s }, x/y as fractions of the screen. */
  applyLayout(layout) {
    if (!layout || typeof layout !== 'object') return;
    for (const key of Object.keys(this.movers)) {
      const v = layout[key];
      if (v && Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.s)) {
        this.layout[key] = { x: clampNum(v.x, -1.5, 1.5), y: clampNum(v.y, -1.5, 1.5), s: clampNum(v.s, SCALE_MIN, SCALE_MAX) };
      }
    }
    this.relayout();
  }

  _saveLayout() {
    try { localStorage.setItem('gw-layout', JSON.stringify(this.layout)); } catch {}
    if (this.onLayout) this.onLayout(this.layout);
  }

  loadLocalLayout() {
    try { this.applyLayout(JSON.parse(localStorage.getItem('gw-layout') || 'null')); } catch {}
  }

  /** Shows every movable piece with sample content so it can be placed while nothing is happening. */
  setArrange(on) {
    this.arranging = on;
    this.root.classList.toggle('arrange', on);
    if (on) {
      if (!this.currentJob) {
        this.nowImg.src = this.avatarFor({ id: 'sample', handle: 'your.viewer' });
        this.nowName.textContent = '@your.viewer';
        this.nowWhat.textContent = 'Now painting';
        this.now.className = 'now tape show';
      }
      this._samplePop = el('div', 'pop-item tape sample', this.popBox);
      el('span', 'pop-name', this._samplePop, 'Popups appear here');
    } else {
      if (this._samplePop) this._samplePop.remove();
      if (!this.currentJob) this.now.classList.remove('show', 'pop');
    }
  }
}
