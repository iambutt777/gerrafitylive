// audio.js — every sound is synthesized with the Web Audio API, so the game
// ships with no audio files and nothing can fail to load during a stream.

export class Sound {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.noise = null;
    this.volume = 0.8;
  }

  /** Creates / resumes the audio context. Call from a user gesture where possible. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 4;
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(comp).connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 2;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  get ready() {
    return Boolean(this.ctx) && this.ctx.state === 'running';
  }

  setVolume(v) {
    this.volume = v;
    if (this.master) this.master.gain.value = v;
  }

  _noiseSrc(loop = true) {
    const s = this.ctx.createBufferSource();
    s.buffer = this.noise;
    s.loop = loop;
    return s;
  }

  _env(param, t, attack, peak, decay) {
    param.cancelScheduledValues(t);
    param.setValueAtTime(0.0001, t);
    param.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + attack);
    param.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  _tone(type, freq, t, attack, peak, decay, dest = this.master, freqEnd = null) {
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, t + attack + decay);
    this._env(g.gain, t, attack, peak, decay);
    o.connect(g).connect(dest);
    o.start(t);
    o.stop(t + attack + decay + 0.05);
    return o;
  }

  _burst(t, dur, freq, q, peak, type = 'bandpass') {
    const s = this._noiseSrc(false);
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = this.ctx.createGain();
    this._env(g.gain, t, 0.004, peak, dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t, Math.random() * 1.5);
    s.stop(t + dur + 0.05);
  }

  footstep(k = 1) {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._burst(t, 0.09, 380 + Math.random() * 120, 0.8, 0.22 * k, 'lowpass');
    this._burst(t + 0.01, 0.05, 2400, 1.2, 0.03 * k);
    this._tone('sine', 95, t, 0.004, 0.12 * k, 0.08, this.master, 50);
  }

  /** Looping aerosol hiss. Returns a handle with stop(). */
  sprayStart() {
    if (!this.ready) return { stop() {} };
    const t = this.ctx.currentTime;
    const src = this._noiseSrc();
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1800;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 5200;
    bp.Q.value = 0.6;
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.value = 7 + Math.random() * 4;
    lfoGain.gain.value = 600;
    lfo.connect(lfoGain).connect(bp.frequency);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.2, t + 0.04);
    src.connect(hp).connect(bp).connect(g).connect(this.master);
    src.start(t, Math.random() * 1.5);
    lfo.start(t);
    const ctx = this.ctx;
    return {
      stop() {
        const now = ctx.currentTime;
        g.gain.cancelScheduledValues(now);
        g.gain.setValueAtTime(Math.max(0.0001, g.gain.value), now);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
        src.stop(now + 0.1);
        lfo.stop(now + 0.1);
      },
    };
  }

  /** Looping bristle scrape whose loudness follows brush speed. */
  brushStart() {
    if (!this.ready) return { setSpeed() {}, stop() {} };
    const t = this.ctx.currentTime;
    const src = this._noiseSrc();
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1100;
    bp.Q.value = 0.9;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    src.connect(bp).connect(g).connect(this.master);
    src.start(t, Math.random() * 1.5);
    const ctx = this.ctx;
    return {
      setSpeed(v) {
        g.gain.setTargetAtTime(Math.min(0.2, 0.02 + v * 0.1), ctx.currentTime, 0.03);
        bp.frequency.setTargetAtTime(900 + v * 500, ctx.currentTime, 0.05);
      },
      stop() {
        const now = ctx.currentTime;
        g.gain.setTargetAtTime(0.0001, now, 0.03);
        src.stop(now + 0.15);
      },
    };
  }

  shake() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    for (let i = 0; i < 8; i++) {
      this._burst(t + i * 0.105, 0.05, 3200, 3, 0.28);
      this._tone('square', 1700 + Math.random() * 300, t + i * 0.105 + 0.01, 0.002, 0.03, 0.02);
    }
  }

  clink() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._tone('sine', 1480, t, 0.003, 0.08, 0.18);
    this._tone('sine', 2310, t, 0.003, 0.05, 0.12);
  }

  thunk() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._burst(t, 0.12, 300, 0.7, 0.3, 'lowpass');
    this._tone('sine', 130, t, 0.003, 0.18, 0.12, this.master, 70);
  }

  ladderPlace() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    [180, 263, 410, 618, 940, 1330].forEach((f, i) => this._tone('sine', f, t, 0.003, 0.14 / (i * 0.6 + 1), 0.5 + Math.random() * 0.7));
    this._burst(t, 0.18, 250, 0.7, 0.4, 'lowpass');
  }

  ladderStep() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    [520, 790, 1190].forEach((f, i) => this._tone('sine', f * (0.97 + Math.random() * 0.06), t, 0.002, 0.05 / (i + 1), 0.22));
    this._burst(t, 0.05, 500, 1, 0.08, 'lowpass');
  }

  pop() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._tone('sine', 520, t, 0.004, 0.12, 0.12, this.master, 1100);
    this._burst(t, 0.03, 4000, 1, 0.05);
  }

  announce() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    // riser
    const src = this._noiseSrc(false);
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.Q.value = 2;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(5000, t + 0.75);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.18, t + 0.7);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.85);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + 0.9);
    // boom
    this._tone('sine', 80, t + 0.78, 0.005, 0.6, 0.9, this.master, 32);
    // brass stabs
    const bus = this.ctx.createBiquadFilter();
    bus.type = 'lowpass';
    bus.frequency.setValueAtTime(900, t + 0.8);
    bus.frequency.exponentialRampToValueAtTime(3200, t + 1.6);
    bus.connect(this.master);
    const chord = (notes, at, len) => notes.forEach((n) => {
      this._tone('sawtooth', n, at, 0.02, 0.06, len, bus);
      this._tone('sawtooth', n * 1.005, at, 0.02, 0.04, len, bus);
    });
    chord([261.6, 329.6, 392.0], t + 0.8, 0.22);
    chord([293.7, 370.0, 440.0], t + 1.08, 0.22);
    chord([392.0, 523.3, 659.3, 784.0], t + 1.36, 1.5);
  }

  /** Diesel engine rumble; returns a handle with stop(). */
  engine() {
    if (!this.ready) return { stop() {} };
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.value = 42;
    const lfo = this.ctx.createOscillator();
    const lg = this.ctx.createGain();
    lfo.frequency.value = 11;
    lg.gain.value = 6;
    lfo.connect(lg).connect(o.frequency);
    const f = this.ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 260;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.16, t + 0.6);
    o.connect(f).connect(g).connect(this.master);
    o.start(t);
    lfo.start(t);
    const ctx = this.ctx;
    return {
      stop() {
        const now = ctx.currentTime;
        g.gain.cancelScheduledValues(now);
        g.gain.setValueAtTime(Math.max(0.0001, g.gain.value), now);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);
        o.stop(now + 0.85);
        lfo.stop(now + 0.85);
      },
    };
  }

  /** Hydraulic boom whine; returns a handle with stop(). */
  hydraulic() {
    if (!this.ready) return { stop() {} };
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(110, t);
    o.frequency.linearRampToValueAtTime(150, t + 2);
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 420;
    f.Q.value = 3;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.07, t + 0.2);
    o.connect(f).connect(g).connect(this.master);
    o.start(t);
    const ctx = this.ctx;
    return {
      stop() {
        const now = ctx.currentTime;
        g.gain.setTargetAtTime(0.0001, now, 0.08);
        o.stop(now + 0.4);
      },
    };
  }

  horn() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    for (const [at, len] of [[0, 0.22], [0.3, 0.5]]) {
      this._tone('square', 392, t + at, 0.01, 0.07, len);
      this._tone('square', 494, t + at, 0.01, 0.06, len);
    }
  }

  doorClunk() {
    this.thunk();
  }

  splat() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._burst(t, 0.18, 700, 0.8, 0.45, 'lowpass');
    this._tone('sine', 180, t, 0.003, 0.2, 0.15, this.master, 60);
  }

  whistle() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._tone('sine', 900, t, 0.02, 0.05, 0.85, this.master, 2400);
    this._burst(t, 0.8, 3000, 2, 0.05);
  }

  bang() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this._burst(t, 0.5, 900, 0.5, 0.6, 'lowpass');
    this._tone('sine', 70, t, 0.004, 0.45, 0.5, this.master, 35);
    for (let i = 0; i < 6; i++) this._burst(t + 0.15 + Math.random() * 0.5, 0.04, 5000, 2, 0.06);
  }

  legendary() {
    this.announce();
    if (!this.ready) return;
    const t = this.ctx.currentTime + 1.4;
    [523.3, 659.3, 784, 1046.5, 1318.5].forEach((n, i) => this._tone('triangle', n, t + i * 0.09, 0.01, 0.06, 1.6));
  }

  golden() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    [1046.5, 1318.5, 1568, 2093, 2637, 3136].forEach((n, i) => {
      this._tone('sine', n, t + i * 0.075, 0.004, 0.11, 1.4);
      this._tone('triangle', n * 2, t + i * 0.075, 0.004, 0.03, 0.8);
    });
    this._burst(t, 1.6, 8000, 0.5, 0.05, 'highpass');
  }
}
