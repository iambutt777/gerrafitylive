// queue.js — turns a firehose of LIVE events into an ordered list of paint jobs.
//
// Rules:
//  • likes are banked per viewer; every 40 likes becomes one "like" job,
//    or only a popup when more than LIKE_POPUP_VIEWERS people are watching
//  • a viewer who already has a like (or share) job waiting gets it merged (×2, ×3…)
//  • gift tiers: 1–4 coins gift · 5–19 big · 20–29 vip · 30–99 special (ladder) · 100+ legendary
//  • several gifts from one viewer while they wait merge into ONE piece (×N),
//    upgrading to a bigger tier when their total crosses a threshold
//  • once a viewer's profile has been sprayed, their later small gifts become
//    popups; those coins are banked and turn into a new piece at 5 coins
//  • higher tiers are painted first; waiting jobs slowly gain priority
//  • nothing is ever dropped, and only one job runs at a time

export const LIKES_PER_PAINT = 40;
export const LIKE_POPUP_VIEWERS = 10;
export const REPEAT_BANK_COINS = 5;

const BASE_PRIORITY = { legendary: 200, special: 100, vip: 70, big: 50, gift: 20, share: 6, like: 4, join: 2 };
const RANK = { gift: 1, big: 2, vip: 3, special: 4, legendary: 5 };
export const GIFT_KINDS = new Set(Object.keys(RANK));
const AGING_PER_SECOND = 0.5;
const ACTIVE_WINDOW_MS = 120000;

function cleanUser(u = {}) {
  const handle = String(u.handle || u.id || u.name || 'viewer').slice(0, 40);
  return {
    id: String(u.id || handle),
    handle,
    name: String(u.name || handle).slice(0, 60),
    avatar: String(u.avatar || ''),
  };
}

export function tierForCoins(coins) {
  if (coins >= 100) return 'legendary';
  if (coins >= 30) return 'special';
  if (coins >= 20) return 'vip';
  if (coins >= 5) return 'big';
  return 'gift';
}

export class EventQueue {
  constructor({ likesPerPaint = LIKES_PER_PAINT, likePopupViewers = LIKE_POPUP_VIEWERS } = {}) {
    this.likesPerPaint = likesPerPaint;
    this.likePopupViewers = likePopupViewers;
    this.likeBank = new Map();
    this.giftPainted = new Map(); // viewer id → coins banked from repeat small gifts
    this.recent = new Map(); // viewer id → last activity time (fallback viewer count)
    this.viewerCount = null; // TikTok's live viewer count, when known
    this.likePopupsEnabled = false; // control panel: likes only as popups on busy LIVEs
    this.joinsEnabled = true; // control panel: spray new viewers' names
    this.joined = new Set(); // viewers already greeted this session
    this.likeEvery = 1; // control panel: paint the name on every like (1) or every 10/20/40/100 likes
    this.items = [];
    this.seq = 0;
    this.listeners = new Set();
    this.popupListeners = new Set();
    this.stats = { received: 0, painted: 0 };
  }

  get size() {
    return this.items.length;
  }

  onChange(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  onPopup(fn) {
    this.popupListeners.add(fn);
    return () => this.popupListeners.delete(fn);
  }

  _emit() {
    for (const fn of this.listeners) fn(this);
  }

  _popup(p) {
    for (const fn of this.popupListeners) fn(p);
  }

  setViewerCount(n) {
    this.viewerCount = Number.isFinite(n) && n >= 0 ? n : null;
    this._applyLikeMode();
    this._emit();
  }

  /** Viewers right now: TikTok's count if known, otherwise people active in the last 2 minutes. */
  activeUsers() {
    if (this.viewerCount != null) return this.viewerCount;
    const cutoff = performance.now() - ACTIVE_WINDOW_MS;
    for (const [id, t] of this.recent) {
      if (t >= cutoff) break;
      this.recent.delete(id);
    }
    return this.recent.size;
  }

  get likesAsPopups() {
    return this.likePopupsEnabled && this.activeUsers() > this.likePopupViewers;
  }

  setOptions({ likePopups, joins, likeEvery } = {}) {
    if (typeof likePopups === 'boolean') this.likePopupsEnabled = likePopups;
    if (Number.isFinite(likeEvery) && likeEvery >= 1) this.likeEvery = Math.floor(likeEvery);
    if (typeof joins === 'boolean') {
      this.joinsEnabled = joins;
      if (!joins) this.items = this.items.filter((j) => j.kind !== 'join');
    }
    this._applyLikeMode();
    this._emit();
  }

  _applyLikeMode() {
    if (!this.likesAsPopups) return;
    const likes = this.items.filter((j) => j.kind === 'like');
    if (!likes.length) return;
    this.items = this.items.filter((j) => j.kind !== 'like');
    for (const j of likes) this._popup({ type: 'like', user: j.user, count: j.likes || j.count });
  }

  ingest(raw) {
    if (!raw || !raw.user) return;
    this.stats.received++;
    const user = cleanUser(raw.user);
    this.recent.delete(user.id);
    this.recent.set(user.id, performance.now());

    if (raw.type === 'like') {
      const n = Math.max(0, Math.floor(Number(raw.count) || 0));
      if (n <= 0) return;
      if (this.likeEvery <= 1) {
        // every like paints the name; likes arriving while the name is still waiting merge into it
        if (this.likesAsPopups) this._popup({ type: 'like', user, count: n });
        else this._pushOrMerge('like', user, 1, n);
      } else {
        const banked = (this.likeBank.get(user.id) || 0) + n;
        const rounds = Math.floor(banked / this.likeEvery);
        this.likeBank.delete(user.id);
        this.likeBank.set(user.id, banked - rounds * this.likeEvery);
        if (this.likeBank.size > 20000) this.likeBank.delete(this.likeBank.keys().next().value);
        if (rounds > 0) {
          if (this.likesAsPopups) this._popup({ type: 'like', user, count: rounds * this.likeEvery });
          else this._pushOrMerge('like', user, rounds, rounds * this.likeEvery);
        }
      }
    } else if (raw.type === 'share') {
      this._pushOrMerge('share', user, 1);
    } else if (raw.type === 'join') {
      // greet each viewer once; on busy LIVEs only a few names wait at a time
      if (!this.joinsEnabled || this.joined.has(user.id)) return;
      this.joined.add(user.id);
      if (this.joined.size > 50000) this.joined.delete(this.joined.values().next().value);
      this._push({ kind: 'join', user, count: 1, coins: 0 });
    } else if (raw.type === 'gift') {
      const coins = Math.max(0, Math.floor(Number(raw.coins) || 0));
      if (coins < 1) return;
      const giftName = String(raw.giftName || 'Gift');
      // 1) merge into this viewer's waiting gift piece
      const waiting = this.items.find((j) => GIFT_KINDS.has(j.kind) && j.user.id === user.id);
      if (waiting) {
        waiting.coins += coins;
        waiting.count += 1;
        if (user.avatar) waiting.user.avatar = user.avatar;
        const t = tierForCoins(waiting.coins);
        if (RANK[t] > RANK[waiting.kind]) waiting.kind = t;
        this._emit();
        return;
      }
      // 2) small repeat gift from someone already on the wall: popup + bank
      if (tierForCoins(coins) === 'gift' && this.giftPainted.has(user.id)) {
        const bank = this.giftPainted.get(user.id) + coins;
        const upgrade = bank >= REPEAT_BANK_COINS;
        this.giftPainted.set(user.id, upgrade ? 0 : bank);
        this._popup({ type: 'gift', user, coins, giftName, bank: upgrade ? 0 : bank, upgrade });
        if (upgrade) this._push({ kind: tierForCoins(bank), user, coins: bank, giftName, count: 1 });
        this._emit();
        return;
      }
      // 3) a new piece
      this._push({ kind: tierForCoins(coins), user, coins, giftName, count: 1 });
    } else {
      return;
    }
    this._emit();
  }

  _pushOrMerge(kind, user, n, likes = 0) {
    const waiting = this.items.find((j) => j.kind === kind && j.user.id === user.id);
    if (waiting) {
      waiting.count += n;
      waiting.likes = (waiting.likes || 0) + likes;
      if (user.avatar) waiting.user.avatar = user.avatar;
      return;
    }
    this._push({ kind, user, count: n, coins: 0, likes });
  }

  _push(job) {
    job.id = ++this.seq;
    job.t = performance.now();
    this.items.push(job);
  }

  _score(job, now) {
    return BASE_PRIORITY[job.kind] + ((now - job.t) / 1000) * AGING_PER_SECOND;
  }

  /** Returns the next job to paint, or null. */
  next() {
    if (!this.items.length) return null;
    const now = performance.now();
    let best = 0;
    let bestScore = -Infinity;
    for (let i = 0; i < this.items.length; i++) {
      const s = this._score(this.items[i], now);
      if (s > bestScore + 1e-9 || (Math.abs(s - bestScore) <= 1e-9 && this.items[i].id < this.items[best].id)) {
        best = i;
        bestScore = s;
      }
    }
    const [job] = this.items.splice(best, 1);
    if (GIFT_KINDS.has(job.kind) && !this.giftPainted.has(job.user.id)) {
      this.giftPainted.set(job.user.id, 0);
      if (this.giftPainted.size > 5000) this.giftPainted.delete(this.giftPainted.keys().next().value);
    }
    this.stats.painted++;
    this._emit();
    return job;
  }

  /** Removes and returns up to n waiting new-viewer jobs (oldest first), to paint them together. */
  takeJoins(n) {
    const joins = this.items.filter((j) => j.kind === 'join').slice(0, n);
    if (!joins.length) return [];
    const ids = new Set(joins.map((j) => j.id));
    this.items = this.items.filter((j) => !ids.has(j.id));
    this._emit();
    return joins;
  }

  /** Upcoming jobs in the order they will most likely be painted. */
  upcoming(limit = 5) {
    const now = performance.now();
    return [...this.items]
      .sort((a, b) => this._score(b, now) - this._score(a, now) || a.id - b.id)
      .slice(0, limit);
  }
}
