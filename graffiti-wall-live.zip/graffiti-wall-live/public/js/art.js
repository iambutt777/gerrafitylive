// art.js — designs every graffiti piece.
// For each job it draws the *finished* artwork onto an offscreen canvas and
// produces the stroke paths the 3D artist follows. During painting, the wall
// reveals the finished artwork only where the brush / spray has passed, so the
// piece appears gradually, exactly along the artist's movements.
//
// Coordinates in strokes are world units (metres) relative to the bottom-left
// of the padded art rectangle.

export const ART_PPU = 128; // canvas pixels per metre (matches the wall panels)
const PPU = ART_PPU;

export const NEON = ['#ff2e88', '#19e3ff', '#b6ff3b', '#ffd23f', '#a66bff', '#ff6b1a', '#00f5a0', '#ff4d6d'];
export const INK = '#17131c';
export const GOLD = ['#fff6c2', '#ffd84d', '#f0a81c', '#a86a00'];
export const FONT_BRUSH = '"Permanent Marker", "Marker Felt", cursive';
export const FONT_BLOCK = '"Bungee", Impact, "Arial Black", sans-serif';

// ---------- small utilities ----------
export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashStr(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const pick = (rng, arr) => arr[Math.floor(rng() * arr.length) % arr.length];
const rnd = (rng, a, b) => a + rng() * (b - a);

function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  const f = (c) => Math.max(0, Math.min(255, Math.round(amt < 0 ? c * (1 + amt) : c + (255 - c) * amt)));
  const r = f((n >> 16) & 255), g = f((n >> 8) & 255), b = f(n & 255);
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

let NAME_MODE = 'handle'; // 'handle' = @username, 'name' = TikTok display name

/** Chooses what gets sprayed and listed: 'handle' (@username) or 'name' (display name). */
export function setNameMode(mode) {
  NAME_MODE = mode === 'name' ? 'name' : 'handle';
}

export function displayName(user) {
  const raw = NAME_MODE === 'name' ? user?.name || user?.handle : user?.handle || user?.name;
  let n = String(raw || 'viewer').replace(/[\u0000-\u001f\u007f]/g, '').trim() || 'viewer';
  const chars = Array.from(n);
  if (chars.length > 16) n = chars.slice(0, 15).join('') + '…';
  return NAME_MODE === 'name' ? n : '@' + n;
}

const measureCtx = document.createElement('canvas').getContext('2d');
function textWidth(text, family, px) {
  measureCtx.font = `${px}px ${family}`;
  return measureCtx.measureText(text).width;
}

let grain = null;
function grainTile() {
  if (grain) return grain;
  grain = document.createElement('canvas');
  grain.width = grain.height = 128;
  const g = grain.getContext('2d');
  const d = g.createImageData(128, 128);
  for (let i = 0; i < 128 * 128; i++) {
    const v = 128 + (Math.random() - 0.5) * 140;
    d.data[i * 4] = d.data[i * 4 + 1] = d.data[i * 4 + 2] = v;
    d.data[i * 4 + 3] = 255;
  }
  g.putImageData(d, 0, 0);
  return grain;
}

// ---------- profile pictures ----------
export function avatarSrc(user, useProxy) {
  const u = String(user?.avatar || '');
  if (!u) return '';
  if (u.startsWith('data:') || u.startsWith('blob:')) return u;
  if (/^https?:\/\//i.test(u)) return useProxy ? '/avatar?url=' + encodeURIComponent(u) : u;
  return '';
}

const avatarCache = new Map();
export function loadAvatar(user, useProxy) {
  const src = avatarSrc(user, useProxy);
  const key = src || 'default:' + (user?.id || user?.handle || '');
  if (avatarCache.has(key)) return avatarCache.get(key);
  const p = !src
    ? Promise.resolve(defaultAvatar(user))
    : new Promise((resolve) => {
        const img = new Image();
        if (!src.startsWith('data:')) img.crossOrigin = 'anonymous';
        let settled = false;
        const finish = (v) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          resolve(v);
        };
        const timer = setTimeout(() => finish(defaultAvatar(user)), 4000);
        img.onload = () => finish(img.naturalWidth ? img : defaultAvatar(user));
        img.onerror = () => finish(defaultAvatar(user));
        img.src = src;
      });
  avatarCache.set(key, p);
  if (avatarCache.size > 300) avatarCache.delete(avatarCache.keys().next().value);
  return p;
}

/** Fallback picture: a spray-painted initial on a colour derived from the name. */
export function defaultAvatar(user) {
  const name = String(user?.handle || user?.name || '?');
  const h = hashStr(name);
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  const hue = h % 360;
  const bg = g.createRadialGradient(90, 80, 20, 128, 128, 190);
  bg.addColorStop(0, `hsl(${hue} 90% 62%)`);
  bg.addColorStop(1, `hsl(${(hue + 50) % 360} 80% 32%)`);
  g.fillStyle = bg;
  g.fillRect(0, 0, 256, 256);
  const rng = mulberry32(h);
  for (let i = 0; i < 26; i++) {
    g.globalAlpha = 0.25;
    g.fillStyle = `hsl(${(hue + 180) % 360} 90% 70%)`;
    g.beginPath();
    g.arc(rng() * 256, rng() * 256, 2 + rng() * 10, 0, Math.PI * 2);
    g.fill();
  }
  g.globalAlpha = 1;
  const letter = (Array.from(name.replace(/^@/, ''))[0] || '?').toUpperCase();
  g.font = `150px ${FONT_BLOCK}`;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.lineWidth = 16;
  g.lineJoin = 'round';
  g.strokeStyle = INK;
  g.strokeText(letter, 128, 140);
  g.fillStyle = '#ffffff';
  g.fillText(letter, 128, 140);
  return c;
}

export function avatarDataURL(user) {
  return defaultAvatar(user).toDataURL('image/png');
}

// ---------- drawing primitives ----------
function fitFont(ctx, text, family, px, maxW) {
  ctx.font = `${px}px ${family}`;
  let w = ctx.measureText(text).width;
  if (w > maxW) {
    px = Math.max(14, (px * maxW) / w);
    ctx.font = `${px}px ${family}`;
    w = ctx.measureText(text).width;
  }
  return { px, w };
}

function charBoxes(ctx, text, startX, baseline, grow = 0) {
  const boxes = [];
  let acc = '';
  for (const ch of Array.from(text)) {
    const x0 = startX + ctx.measureText(acc).width;
    acc += ch;
    const x1 = startX + ctx.measureText(acc).width;
    if (!ch.trim() || x1 <= x0) continue;
    const m = ctx.measureText(ch);
    const asc = m.actualBoundingBoxAscent || ctx.measureText('M').actualBoundingBoxAscent || 20;
    const desc = m.actualBoundingBoxDescent || 0;
    boxes.push({ x0: x0 - grow, x1: x1 + grow, top: baseline - asc - grow, bottom: baseline + desc + grow });
  }
  return boxes;
}

function textMetrics(ctx, text) {
  const m = ctx.measureText(text);
  return { asc: m.actualBoundingBoxAscent || 0, desc: m.actualBoundingBoxDescent || 0 };
}

/** Hand-painted brush lettering (likes / shares). */
function paintBrushText(ctx, text, cx, cy, px, maxW, color, rng) {
  const f = fitFont(ctx, text, FONT_BRUSH, px, maxW);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  const { asc, desc } = textMetrics(ctx, text);
  const sx = cx - f.w / 2;
  const by = cy + (asc - desc) / 2;
  ctx.fillStyle = 'rgba(15,10,20,0.45)';
  ctx.fillText(text, sx + f.px * 0.035, by + f.px * 0.05);
  ctx.fillStyle = color;
  ctx.fillText(text, sx, by);
  ctx.save();
  ctx.globalCompositeOperation = 'source-atop';
  for (let i = 0; i < 22; i++) {
    const y = by - asc + rng() * (asc + desc);
    ctx.fillStyle = rng() < 0.5 ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.16)';
    ctx.fillRect(sx, y, f.w, 1 + rng() * 2.5);
  }
  ctx.restore();
  return charBoxes(ctx, text, sx, by, 2);
}

/** Spray "tag" lettering with outline (1-coin gifts). */
function paintTagText(ctx, text, cx, cy, px, maxW, color, rng) {
  const f = fitFont(ctx, text, FONT_BRUSH, px, maxW - px * 0.15);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  const { asc, desc } = textMetrics(ctx, text);
  const sx = cx - f.w / 2;
  const by = cy + (asc - desc) / 2;
  const ow = f.px * 0.13;
  ctx.lineJoin = 'round';
  ctx.lineWidth = ow * 1.9;
  ctx.strokeStyle = '#ffffff';
  ctx.strokeText(text, sx, by);
  ctx.lineWidth = ow;
  ctx.strokeStyle = INK;
  ctx.strokeText(text, sx, by);
  const g = ctx.createLinearGradient(0, by - asc, 0, by + desc);
  g.addColorStop(0, shade(color, 0.35));
  g.addColorStop(1, shade(color, -0.25));
  ctx.fillStyle = g;
  ctx.fillText(text, sx, by);
  ctx.save();
  ctx.globalCompositeOperation = 'source-atop';
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  ctx.fillRect(sx - ow, by - asc - ow, f.w + ow * 2, asc * 0.3);
  ctx.restore();
  return charBoxes(ctx, text, sx, by, ow * 1.2);
}

/** Big 3D block letters (big gifter / great gifter). */
function paintBlockText(ctx, text, cx, cy, px, maxW, style) {
  const f = fitFont(ctx, text, FONT_BLOCK, px, maxW - px * 0.3);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  const { asc, desc } = textMetrics(ctx, text);
  const sx = cx - f.w / 2;
  const by = cy + (asc - desc) / 2;
  const ow = f.px * (style.outlineW ?? 0.14);
  const depth = style.depth ?? Math.max(3, Math.round(f.px * 0.08));
  ctx.lineJoin = 'round';
  ctx.miterLimit = 2;

  ctx.fillStyle = style.shadow;
  ctx.strokeStyle = style.shadow;
  ctx.lineWidth = ow;
  for (let i = depth; i >= 1; i--) {
    ctx.strokeText(text, sx + i * 0.7, by + i);
    ctx.fillText(text, sx + i * 0.7, by + i);
  }
  if (style.outline2) {
    ctx.lineWidth = ow * 1.9;
    ctx.strokeStyle = style.outline2;
    ctx.strokeText(text, sx, by);
  }
  ctx.save();
  if (style.glow) {
    ctx.shadowColor = style.glow;
    ctx.shadowBlur = f.px * 0.5;
  }
  ctx.lineWidth = ow;
  ctx.strokeStyle = style.outline;
  ctx.strokeText(text, sx, by);
  ctx.restore();

  const g = ctx.createLinearGradient(0, by - asc, 0, by + desc);
  style.fill.forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c));
  ctx.fillStyle = g;
  ctx.fillText(text, sx, by);

  ctx.save();
  ctx.globalCompositeOperation = 'source-atop';
  ctx.fillStyle = 'rgba(255,255,255,0.32)';
  ctx.fillRect(sx - ow, by - asc - ow, f.w + ow * 2, asc * 0.26);
  ctx.restore();

  const boxes = charBoxes(ctx, text, sx, by, ow * 1.1);
  for (const b of boxes) {
    // little "bubble shine" on each letter
    ctx.save();
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.beginPath();
    ctx.ellipse(b.x0 + (b.x1 - b.x0) * 0.32, b.top + (b.bottom - b.top) * 0.28, f.px * 0.05, f.px * 0.028, -0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    b.bottom += depth;
    b.x1 += depth * 0.7;
  }
  return boxes;
}

function goldGradient(ctx, x0, y0, x1, y1) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  const stops = [GOLD[0], GOLD[1], GOLD[2], GOLD[1], GOLD[3], GOLD[1], GOLD[0]];
  stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c));
  return g;
}

function circle(ctx, x, y, r) {
  ctx.beginPath();
  ctx.arc(x, y, Math.max(0.1, r), 0, Math.PI * 2);
}

/** A profile picture sprayed inside a ring, with overspray halo. */
function paintAvatarDisc(ctx, img, cx, cy, r, ringColor, rng, opts = {}) {
  const ringW = r * (opts.ringW ?? 0.12);
  ctx.save();
  for (let i = 0; i < 520; i++) {
    const a = rng() * Math.PI * 2;
    const d = r + ringW + Math.pow(rng(), 2) * r * 0.32;
    ctx.globalAlpha = 0.12 + rng() * 0.3;
    ctx.fillStyle = opts.haloColor || ringColor;
    circle(ctx, cx + Math.cos(a) * d, cy + Math.sin(a) * d, 0.6 + rng() * 1.9);
    ctx.fill();
  }
  ctx.restore();

  ctx.save();
  if (opts.glow) {
    ctx.shadowColor = opts.glow;
    ctx.shadowBlur = r * 0.4;
  }
  ctx.fillStyle = opts.gold ? goldGradient(ctx, cx - r, cy - r, cx + r, cy + r) : ringColor;
  circle(ctx, cx, cy, r + ringW);
  ctx.fill();
  ctx.restore();
  ctx.lineWidth = Math.max(3, r * 0.035);
  ctx.strokeStyle = INK;
  circle(ctx, cx, cy, r + ringW);
  ctx.stroke();

  if (opts.innerRing) {
    ctx.fillStyle = opts.innerRing;
    circle(ctx, cx, cy, r + ringW * 0.25);
    ctx.fill();
  }
  ctx.fillStyle = INK;
  circle(ctx, cx, cy, r);
  ctx.fill();

  ctx.save();
  circle(ctx, cx, cy, r * 0.93);
  ctx.clip();
  const iw = img.naturalWidth || img.width || 1;
  const ih = img.naturalHeight || img.height || 1;
  const s = Math.max((2 * r) / iw, (2 * r) / ih);
  ctx.drawImage(img, cx - (iw * s) / 2, cy - (ih * s) / 2, iw * s, ih * s);
  // make the photo read as paint: tint, contrast and grain
  ctx.globalCompositeOperation = 'soft-light';
  ctx.globalAlpha = 0.35;
  ctx.fillStyle = ringColor;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.globalCompositeOperation = 'overlay';
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = ctx.createPattern(grainTile(), 'repeat');
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.restore();

  ctx.strokeStyle = 'rgba(255,255,255,0.6)';
  ctx.lineWidth = Math.max(2, r * 0.03);
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.88, Math.PI * 1.08, Math.PI * 1.42);
  ctx.stroke();

  // rough spray edge
  for (let i = 0; i < 160; i++) {
    const a = rng() * Math.PI * 2;
    const d = r + ringW + rnd(rng, -2, 3);
    ctx.fillStyle = opts.gold ? GOLD[1] : ringColor;
    circle(ctx, cx + Math.cos(a) * d, cy + Math.sin(a) * d, 1 + rng() * 2.4);
    ctx.fill();
  }
}

function drawRays(ctx, cx, cy, r0, r1, n, colA, colB) {
  for (let i = 0; i < n; i++) {
    const a0 = (i / n) * Math.PI * 2;
    const a1 = a0 + (Math.PI / n) * 0.95;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a0) * r0, cy + Math.sin(a0) * r0);
    ctx.lineTo(cx + Math.cos(a0) * r1, cy + Math.sin(a0) * r1);
    ctx.lineTo(cx + Math.cos(a1) * r1, cy + Math.sin(a1) * r1);
    ctx.lineTo(cx + Math.cos(a1) * r0, cy + Math.sin(a1) * r0);
    ctx.closePath();
    ctx.fillStyle = i % 2 ? colA : colB;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(23,19,28,0.6)';
    ctx.stroke();
  }
}

function drawCrown(ctx, cx, by, w, h, gem) {
  const xs = [-0.5, -0.375, -0.25, -0.125, 0, 0.125, 0.25, 0.375, 0.5];
  ctx.beginPath();
  ctx.moveTo(cx - w / 2, by);
  xs.forEach((x, i) => ctx.lineTo(cx + x * w, by - (i % 2 === 0 ? h : h * 0.42)));
  ctx.lineTo(cx + w / 2, by);
  ctx.closePath();
  ctx.fillStyle = goldGradient(ctx, cx - w / 2, by - h, cx + w / 2, by);
  ctx.fill();
  ctx.lineWidth = w * 0.035;
  ctx.lineJoin = 'round';
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = shade(GOLD[2], -0.2);
  ctx.fillRect(cx - w / 2, by - h * 0.24, w, h * 0.24);
  ctx.strokeRect(cx - w / 2, by - h * 0.24, w, h * 0.24);
  for (let i = 0; i < 5; i++) {
    const x = cx + (-0.5 + i * 0.25) * w;
    ctx.fillStyle = GOLD[0];
    circle(ctx, x, by - h - w * 0.03, w * 0.045);
    ctx.fill();
    ctx.stroke();
  }
  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = i === 1 ? gem : '#ffffff';
    circle(ctx, cx + (i - 1) * w * 0.28, by - h * 0.12, w * 0.05);
    ctx.fill();
    ctx.stroke();
  }
}

function drawWings(ctx, cx, cy, r, color) {
  // feathers fan outwards and upwards from behind the picture (canvas y points down)
  for (const side of [-1, 1]) {
    for (let i = 5; i >= 0; i--) {
      const lift = 0.12 + i * 0.2;
      const theta = side > 0 ? -lift : Math.PI + lift;
      const len = r * (1.2 - i * 0.09);
      const d = r * 0.8 + len * 0.45;
      ctx.save();
      ctx.translate(cx + Math.cos(theta) * d, cy + Math.sin(theta) * d + r * 0.1);
      ctx.rotate(theta);
      const g = ctx.createLinearGradient(-len / 2, 0, len / 2, 0);
      g.addColorStop(0, color);
      g.addColorStop(1, '#ffffff');
      ctx.fillStyle = g;
      ctx.strokeStyle = INK;
      ctx.lineWidth = Math.max(2, r * 0.035);
      ctx.beginPath();
      ctx.ellipse(0, 0, len / 2, r * 0.17, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }
}

function drawCountBadge(ctx, cx, cy, r, color, count) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = r * 0.6;
  circle(ctx, cx, cy, r);
  ctx.fill();
  ctx.restore();
  ctx.lineWidth = r * 0.14;
  ctx.strokeStyle = INK;
  circle(ctx, cx, cy, r);
  ctx.stroke();
  const label = '×' + count;
  const f = fitFont(ctx, label, FONT_BLOCK, r * 0.9, r * 1.7);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = f.px * 0.22;
  ctx.strokeStyle = INK;
  ctx.strokeText(label, cx, cy + f.px * 0.05);
  ctx.fillStyle = '#ffffff';
  ctx.fillText(label, cx, cy + f.px * 0.05);
}

function drawHeart(ctx, cx, cy, size, color) {
  ctx.save();
  ctx.translate(cx, cy + size * 0.05);
  ctx.scale(size / 100, size / 100);
  ctx.beginPath();
  ctx.moveTo(0, 38);
  ctx.bezierCurveTo(-58, 0, -52, -46, -22, -46);
  ctx.bezierCurveTo(-8, -46, 0, -36, 0, -24);
  ctx.bezierCurveTo(0, -36, 8, -46, 22, -46);
  ctx.bezierCurveTo(52, -46, 58, 0, 0, 38);
  ctx.closePath();
  ctx.lineWidth = 10;
  ctx.lineJoin = 'round';
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  ctx.beginPath();
  ctx.ellipse(-24, -26, 10, 6, -0.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** "New viewer" badge: a speech bubble saying HI. */
function drawJoinBadge(ctx, cx, cy, r, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = r * 0.5;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(cx, cy, r * 1.15, r * 0.9, 0, 0, Math.PI * 2);
  ctx.moveTo(cx - r * 0.5, cy + r * 0.7);
  ctx.lineTo(cx - r * 0.85, cy + r * 1.3);
  ctx.lineTo(cx - r * 0.05, cy + r * 0.85);
  ctx.fill();
  ctx.restore();
  ctx.lineWidth = r * 0.12;
  ctx.strokeStyle = INK;
  ctx.beginPath();
  ctx.ellipse(cx, cy, r * 1.15, r * 0.9, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.font = `${r * 0.85}px ${FONT_BLOCK}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = r * 0.18;
  ctx.lineJoin = 'round';
  ctx.strokeStyle = INK;
  ctx.strokeText('HI!', cx, cy + r * 0.05);
  ctx.fillStyle = '#ffffff';
  ctx.fillText('HI!', cx, cy + r * 0.05);
}

function drawShareBadge(ctx, cx, cy, r, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = r * 0.5;
  ctx.fillStyle = color;
  circle(ctx, cx, cy, r);
  ctx.fill();
  ctx.restore();
  ctx.lineWidth = r * 0.12;
  ctx.strokeStyle = INK;
  circle(ctx, cx, cy, r);
  ctx.stroke();
  // curved share arrow
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = r * 0.16;
  ctx.beginPath();
  ctx.moveTo(cx - r * 0.5, cy + r * 0.35);
  ctx.quadraticCurveTo(cx - r * 0.4, cy - r * 0.25, cx + r * 0.25, cy - r * 0.2);
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(cx + r * 0.55, cy - r * 0.2);
  ctx.lineTo(cx + r * 0.12, cy - r * 0.52);
  ctx.lineTo(cx + r * 0.12, cy + r * 0.12);
  ctx.closePath();
  ctx.fill();
  // label
  ctx.font = `${r * 0.5}px ${FONT_BLOCK}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = r * 0.14;
  ctx.strokeStyle = INK;
  ctx.strokeText('SHARE', cx, cy + r * 1.32);
  ctx.fillStyle = '#ffffff';
  ctx.fillText('SHARE', cx, cy + r * 1.32);
}

function drawRibbon(ctx, cx, cy, w, h, colors, text, textFill = '#ffffff') {
  const notch = h * 0.35;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - w / 2, cy - h / 2);
  ctx.lineTo(cx + w / 2, cy - h / 2);
  ctx.lineTo(cx + w / 2 - notch, cy);
  ctx.lineTo(cx + w / 2, cy + h / 2);
  ctx.lineTo(cx - w / 2, cy + h / 2);
  ctx.lineTo(cx - w / 2 + notch, cy);
  ctx.closePath();
  const g = ctx.createLinearGradient(cx - w / 2, 0, cx + w / 2, 0);
  colors.forEach((c, i, a) => g.addColorStop(i / Math.max(1, a.length - 1), c));
  ctx.shadowColor = colors[0];
  ctx.shadowBlur = h * 0.6;
  ctx.fillStyle = g;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = h * 0.09;
  ctx.lineJoin = 'round';
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.restore();
  const f = fitFont(ctx, text, FONT_BLOCK, h * 0.52, w - notch * 2.4);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = f.px * 0.2;
  ctx.lineJoin = 'round';
  ctx.strokeStyle = INK;
  ctx.strokeText(text, cx, cy + f.px * 0.04);
  ctx.fillStyle = textFill;
  ctx.fillText(text, cx, cy + f.px * 0.04);
  return { x0: cx - w / 2, x1: cx + w / 2, top: cy - h / 2, bottom: cy + h / 2 };
}

export function drawSplash(ctx, X, Y, s, color, rng, glow) {
  ctx.save();
  if (glow) {
    ctx.shadowColor = color;
    ctx.shadowBlur = s * 0.6;
  }
  ctx.fillStyle = color;
  circle(ctx, X, Y, s * 0.32);
  ctx.fill();
  const lobes = 6 + Math.floor(rng() * 6);
  for (let i = 0; i < lobes; i++) {
    const a = rng() * Math.PI * 2;
    const d = s * rnd(rng, 0.2, 0.42);
    circle(ctx, X + Math.cos(a) * d, Y + Math.sin(a) * d, s * rnd(rng, 0.09, 0.2));
    ctx.fill();
  }
  const drops = 8 + Math.floor(rng() * 10);
  for (let i = 0; i < drops; i++) {
    const a = rng() * Math.PI * 2;
    const d = s * rnd(rng, 0.55, 1.5);
    const x = X + Math.cos(a) * d, y = Y + Math.sin(a) * d;
    if (rng() < 0.4) {
      ctx.strokeStyle = color;
      ctx.lineWidth = s * 0.04;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(X + Math.cos(a) * s * 0.35, Y + Math.sin(a) * s * 0.35);
      ctx.lineTo(x, y);
      ctx.stroke();
    }
    circle(ctx, x, y, s * rnd(rng, 0.025, 0.09));
    ctx.fill();
  }
  ctx.restore();
}

export function drawSparkle(ctx, X, Y, s, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = s * 0.8;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(X, Y - s);
  ctx.quadraticCurveTo(X, Y, X + s, Y);
  ctx.quadraticCurveTo(X, Y, X, Y + s);
  ctx.quadraticCurveTo(X, Y, X - s, Y);
  ctx.quadraticCurveTo(X, Y, X, Y - s);
  ctx.fill();
  ctx.fillStyle = color;
  circle(ctx, X, Y, s * 0.18);
  ctx.fill();
  ctx.restore();
}

/** Draws a drip from its start down to `progress` px, used live and when restoring. */
export function drawDripSegment(ctx, d, fromPx, toPx) {
  const w = d.w * (1 - 0.35 * (toPx / d.lenPx));
  ctx.fillStyle = d.color;
  ctx.fillRect(d.X - w / 2, d.Y + fromPx - 1, w, toPx - fromPx + 1.5);
}
export function drawDripEnd(ctx, d) {
  ctx.fillStyle = d.color;
  ctx.beginPath();
  ctx.ellipse(d.X, d.Y + d.lenPx, d.w * 0.62, d.w * 0.8, 0, 0, Math.PI * 2);
  ctx.fill();
}

// ---------- stroke paths ----------
function letterStrokes(boxes, H, r, speed, alpha) {
  const strokes = [];
  for (const b of boxes) {
    const x0 = b.x0 / PPU, x1 = b.x1 / PPU;
    const yT = H - b.top / PPU, yB = H - b.bottom / PPU;
    let hi = yT - r * 0.35, lo = yB + r * 0.35;
    if (hi < lo) hi = lo = (yT + yB) / 2;
    const pts = [];
    const step = r * 1.05;
    let x = x0 + r * 0.45;
    let down = true;
    for (let guard = 0; guard < 200; guard++) {
      const xx = Math.min(x, x1 - r * 0.3);
      pts.push({ x: xx, y: down ? hi : lo }, { x: xx, y: down ? lo : hi });
      down = !down;
      if (x >= x1 - r * 0.3) break;
      x += step;
    }
    strokes.push({ pts, radius: r, speed, alpha });
  }
  return strokes;
}

function rasterRect(x0, x1, yTop, yBot, step, startTop = true) {
  const pts = [];
  let flip = false;
  const ys = [];
  for (let y = yTop - step * 0.45; y > yBot; y -= step) ys.push(y);
  if (!ys.length) ys.push((yTop + yBot) / 2);
  if (!startTop) ys.reverse();
  for (const y of ys) {
    const a = { x: x0, y }, b = { x: x1, y };
    if (flip) pts.push(b, a);
    else pts.push(a, b);
    flip = !flip;
  }
  return pts;
}

function rectStrokes(boxPx, H, r, speed) {
  const x0 = boxPx.x0 / PPU + r * 0.4, x1 = boxPx.x1 / PPU - r * 0.4;
  const yT = H - boxPx.top / PPU, yB = H - boxPx.bottom / PPU;
  return [
    { pts: rasterRect(x0, x1, yT, yB, r * 1.15, true), radius: r, speed, alpha: 0.6 },
    { pts: rasterRect(x0, x1, yT, yB, r * 1.15, false), radius: r, speed: speed * 1.2, alpha: 0.9 },
  ];
}

function rasterDisc(cx, cy, R, step, topDown, offset = 0) {
  const ys = [];
  for (let y = cy + R - step * 0.45 - offset; y >= cy - R; y -= step) ys.push(y);
  if (!topDown) ys.reverse();
  const pts = [];
  let flip = false;
  for (const y of ys) {
    const half = Math.sqrt(Math.max(0, R * R - (y - cy) * (y - cy)));
    const a = { x: cx - half, y }, b = { x: cx + half, y };
    if (flip) pts.push(b, a);
    else pts.push(a, b);
    flip = !flip;
  }
  return pts;
}

function discStrokes(cx, cy, ringR, fillR, r, speed) {
  const ring = [];
  for (let i = 0; i <= 56; i++) {
    const a = Math.PI / 2 - (i / 56) * Math.PI * 2;
    ring.push({ x: cx + Math.cos(a) * ringR, y: cy + Math.sin(a) * ringR });
  }
  return [
    { pts: ring, radius: r * 0.9, speed: speed * 1.35, alpha: 0.85 },
    { pts: rasterDisc(cx, cy, fillR, r * 1.15, true), radius: r, speed, alpha: 0.55 },
    { pts: rasterDisc(cx, cy, fillR, r * 1.15, false, r * 0.55), radius: r, speed: speed * 1.2, alpha: 0.9 },
  ];
}

// ---------- extras: drips, splashes, sparkles ----------
function addDrips(art, img, regionPx, n, color, rng, lenMin, lenMax, delayBase = 0) {
  const { width, height, data } = img;
  for (let k = 0; k < n; k++) {
    for (let tries = 0; tries < 8; tries++) {
      const X = Math.round(rnd(rng, regionPx.x0, regionPx.x1));
      if (X < 2 || X >= width - 2) continue;
      let found = -1;
      const yStart = Math.min(height - 1, Math.round(regionPx.bottom));
      const yEnd = Math.max(0, Math.round(regionPx.top));
      for (let Y = yStart; Y >= yEnd; Y--) {
        if (data[(Y * width + X) * 4 + 3] > 170) {
          found = Y;
          break;
        }
      }
      if (found < 0) continue;
      const room = height - 6 - found;
      const lenPx = Math.min(room, rnd(rng, lenMin, lenMax) * PPU);
      if (lenPx < 10) break;
      art.extras.push({ type: 'drip', X, Y: found - 2, lenPx, w: rnd(rng, 3, 7), color, delay: delayBase + rng() * 0.9 });
      break;
    }
  }
}

function addSplashes(art, n, colors, rng, sizeMin, sizeMax, glow) {
  const W = art.W * PPU, H = art.H * PPU;
  for (let i = 0; i < n; i++) {
    const edge = rng();
    let X, Y;
    if (edge < 0.5) {
      X = rng() < 0.5 ? rnd(rng, W * 0.03, W * 0.2) : rnd(rng, W * 0.8, W * 0.97);
      Y = rnd(rng, H * 0.15, H * 0.75);
    } else {
      X = rnd(rng, W * 0.1, W * 0.9);
      Y = rng() < 0.5 ? rnd(rng, H * 0.05, H * 0.18) : rnd(rng, H * 0.6, H * 0.8);
    }
    art.extras.push({
      type: 'splash', X, Y, s: rnd(rng, sizeMin, sizeMax) * PPU, color: pick(rng, colors), glow: Boolean(glow),
      seed: Math.floor(rng() * 1e9), delay: rng() * 0.6,
    });
  }
}

function addSparkles(art, n, rng, color, regionPx) {
  for (let i = 0; i < n; i++) {
    art.extras.push({
      type: 'sparkle', X: rnd(rng, regionPx.x0, regionPx.x1), Y: rnd(rng, regionPx.top, regionPx.bottom),
      s: rnd(rng, 0.08, 0.2) * PPU, color, delay: 0.2 + i * 0.18,
    });
  }
}

export function drawExtraFull(ctx, e) {
  if (e.type === 'drip') {
    drawDripSegment(ctx, e, 0, e.lenPx);
    drawDripEnd(ctx, e);
  } else if (e.type === 'splash') {
    drawSplash(ctx, e.X, e.Y, e.s, e.color, mulberry32(e.seed), e.glow);
  } else if (e.type === 'sparkle') {
    drawSparkle(ctx, e.X, e.Y, e.s, e.color);
  }
}

// ---------- sizes ----------
const PADS = {
  like: { l: 0.15, r: 0.15, b: 0.55, t: 0.15 },
  share: { l: 0.15, r: 0.15, b: 0.55, t: 0.15 },
  gift: { l: 0.28, r: 0.28, b: 0.62, t: 0.3 },
  big: { l: 0.36, r: 0.36, b: 0.62, t: 0.36 },
  special: { l: 0.45, r: 0.45, b: 0.75, t: 0.45 },
  vip: { l: 0.4, r: 0.4, b: 0.65, t: 0.4 },
  legendary: { l: 0.5, r: 0.5, b: 0.8, t: 0.5 },
  filler: { l: 0.22, r: 0.22, b: 0.6, t: 0.25 },
};

/** Size of a piece before it is painted (used to reserve wall space). */
export function measureArt(job) {
  const name = displayName(job.user);
  const kind = job.kind;
  if (kind === 'filler') {
    const word = String(job.word || 'LIVE').slice(0, 40);
    const h = 1.15;
    const w = Math.min(6, Math.max(1.5, textWidth(word, FONT_BLOCK, 0.78 * PPU) / PPU + 0.45));
    return { kind, name: word, word, w, h, pad: PADS.filler };
  }
  if (kind === 'joins') {
    // several new viewers painted together, one big name per line
    const names = (job.users || [job.user]).map((u) => displayName(u));
    const lineH = 0.66;
    const widest = Math.max(...names.map((n) => textWidth(n, FONT_BLOCK, 0.56 * PPU) / PPU));
    const textW = Math.min(widest, 3.3);
    const badge = 0.78;
    return { kind, name: names[0], names, lineH, h: names.length * lineH + 0.2, w: Math.max(1.8, textW + badge + 0.35), textW, badge, pad: PADS.filler };
  }
  if (kind === 'like' || kind === 'share' || kind === 'join') {
    // same lettering size as the other graffiti pieces
    const h = 1.15;
    const textW = Math.min(textWidth(name, FONT_BLOCK, 0.75 * PPU) / PPU, 3.4);
    const badge = 0.78;
    return { kind, name, h, w: Math.max(1.8, textW + badge + 0.35), textW, badge, pad: PADS.filler };
  }
  const size = { gift: [2.1, 2.3], big: [2.9, 3.05], vip: [3.4, 3.2], special: [4.6, 6.1], legendary: [5.4, 6.6] }[kind];
  return { kind, name, w: size[0], h: size[1], pad: PADS[kind] };
}

/** Draws the finished artwork and returns it with its paint layers. */
export function composeArt(job, m, avatar, seed) {
  const rng = mulberry32(seed);
  const pad = m.pad;
  const W = m.w + pad.l + pad.r;
  const H = m.h + pad.b + pad.t;
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(W * PPU);
  canvas.height = Math.ceil(H * PPU);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const X = (x) => (x + pad.l) * PPU; // core metres → canvas px
  const Y = (y) => (H - (y + pad.b)) * PPU;
  const L = (x, y) => ({ x: x + pad.l, y: y + pad.b }); // core metres → padded local metres
  const art = { kind: m.kind, W, H, pad, core: { w: m.w, h: m.h }, canvas, layers: [], extras: [], glow: false, gold: false, color: '#ffffff', seed };

  const textRegions = [];

  if (m.kind === 'filler') {
    const c1 = pick(rng, NEON);
    const c2 = pick(rng, NEON.filter((c) => c !== c1));
    art.color = c1;
    const boxes = paintBlockText(ctx, m.word, X(m.w / 2), Y(m.h * 0.5), 0.78 * PPU, (m.w + 0.3) * PPU, {
      fill: [shade(c1, 0.45), c1, shade(c1, -0.4)], outline: INK, outline2: rng() < 0.5 ? '#ffffff' : c2,
      shadow: '#1d1028', glow: rng() < 0.4 ? c1 : null,
    });
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.4, overspray: c1, strokes: letterStrokes(boxes, H, 0.14, 2.4, 0.92) });
    if (rng() < 0.6) drawSparkle(ctx, X(m.w - 0.1), Y(m.h - 0.05), 0.14 * PPU, c2);
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.2), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(m.h * 0.6), bottom: Y(0.02) }, 2 + Math.floor(rng() * 3), c1, rng, 0.12, 0.45);
    addSplashes(art, 1 + Math.floor(rng() * 2), [c1, c2], rng, 0.12, 0.24, false);
  } else if (m.kind === 'joins') {
    const palette = NEON.slice();
    art.color = palette[0];
    const allBoxes = [];
    m.names.forEach((name, i) => {
      const c = palette[(i * 3 + Math.floor(rng() * 8)) % palette.length];
      const cy = m.h - 0.12 - m.lineH * (i + 0.5);
      const boxes = paintBlockText(ctx, name, X(0.15 + m.textW / 2), Y(cy), 0.56 * PPU, (m.textW + 0.1) * PPU, {
        fill: [shade(c, 0.45), c, shade(c, -0.4)], outline: INK, outline2: '#ffffff', shadow: '#1d1028', glow: null,
      });
      art.layers.push({ tool: 'spray', color: c, hardness: 0.4, overspray: c, strokes: letterStrokes(boxes, H, 0.11, 2.6, 0.92) });
      allBoxes.push(...boxes);
    });
    const bx = m.w - m.badge / 2 - 0.05, by = m.h - 0.45;
    drawJoinBadge(ctx, X(bx), Y(by), 0.3 * PPU, '#19e3ff');
    art.layers.push({ tool: 'spray', color: '#19e3ff', hardness: 0.4, overspray: '#19e3ff',
      strokes: rectStrokes({ x0: X(bx - 0.38), x1: X(bx + 0.38), top: Y(by + 0.38), bottom: Y(by - 0.5) }, H, 0.12, 2.6) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: allBoxes[0]?.x0 ?? X(0.2), x1: X(0.15 + m.textW), top: Y(m.lineH), bottom: Y(0.02) }, 2, palette[1], rng, 0.12, 0.4);
  } else if (m.kind === 'like' || m.kind === 'share' || m.kind === 'join') {
    const c1 = pick(rng, NEON);
    const c2 = pick(rng, NEON.filter((c) => c !== c1));
    art.color = c1;
    const boxes = paintBlockText(ctx, m.name, X(0.15 + m.textW / 2), Y(m.h * 0.48), 0.75 * PPU, (m.textW + 0.1) * PPU, {
      fill: [shade(c1, 0.45), c1, shade(c1, -0.4)], outline: INK, outline2: rng() < 0.5 ? '#ffffff' : c2,
      shadow: '#1d1028', glow: null,
    });
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.4, overspray: c1, strokes: letterStrokes(boxes, H, 0.13, 2.4, 0.92) });
    const bx = m.w - m.badge / 2 - 0.05, by = m.h * 0.6;
    if (m.kind === 'like') {
      drawHeart(ctx, X(bx), Y(by), 0.56 * PPU, c2);
      if (job.count > 1) drawCountBadge(ctx, X(bx + 0.22), Y(by - 0.3), 0.17 * PPU, '#ffffff', job.count);
    } else if (m.kind === 'share') {
      drawShareBadge(ctx, X(bx), Y(by + 0.05), 0.27 * PPU, c2);
    } else {
      drawJoinBadge(ctx, X(bx), Y(by), 0.3 * PPU, c2);
    }
    const badgeBox = { x0: X(bx - 0.38), x1: X(bx + 0.38), top: Y(by + 0.38), bottom: Y(by - 0.5) };
    art.layers.push({ tool: 'spray', color: c2, hardness: 0.4, overspray: c2, strokes: rectStrokes(badgeBox, H, 0.12, 2.6) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.2), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(m.h * 0.6), bottom: Y(0.02) }, 2 + Math.floor(rng() * 2), c1, rng, 0.12, 0.4);
    addSplashes(art, 1, [c2], rng, 0.12, 0.22, false);
  } else if (m.kind === 'gift') {
    const c1 = pick(rng, NEON);
    const c2 = pick(rng, NEON.filter((c) => c !== c1));
    art.color = c1;
    const R = 0.6, pc = { x: m.w / 2, y: 1.58 };
    paintAvatarDisc(ctx, avatar, X(pc.x), Y(pc.y), R * PPU, c1, rng, { ringW: 0.13 });
    drawSparkle(ctx, X(pc.x - R - 0.12), Y(pc.y - R * 0.4), 0.09 * PPU, c2);
    if (job.count > 1) drawCountBadge(ctx, X(pc.x + R * 0.82), Y(pc.y + R * 0.78), 0.24 * PPU, c2, job.count);
    else drawSparkle(ctx, X(pc.x + R + 0.16), Y(pc.y + R * 0.7), 0.13 * PPU, c2);
    const boxes = paintTagText(ctx, m.name, X(m.w / 2), Y(0.42), 0.5 * PPU, (m.w + 0.3) * PPU, c2, rng);
    const lc = L(pc.x, pc.y);
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.35, overspray: c1, strokes: discStrokes(lc.x, lc.y, R * 1.1, R * 1.2, 0.15, 2.3) });
    art.layers.push({ tool: 'spray', color: c2, hardness: 0.4, overspray: c2, strokes: letterStrokes(boxes, H, 0.1, 2.2, 0.92) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.2), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(0.75), bottom: Y(0.05) }, 3, c2, rng, 0.12, 0.45);
    addDrips(art, img, { x0: X(pc.x - 0.3), x1: X(pc.x + 0.3), top: Y(pc.y), bottom: Y(pc.y - R - 0.12) }, 1, c1, rng, 0.1, 0.3);
    addSplashes(art, 2, [c1, c2], rng, 0.14, 0.26, false);
  } else if (m.kind === 'big') {
    const c1 = pick(rng, NEON);
    const c2 = pick(rng, NEON.filter((c) => c !== c1));
    art.color = c1;
    art.glow = true;
    const R = 0.78, pc = { x: m.w / 2, y: 2.17 };
    drawRays(ctx, X(pc.x), Y(pc.y), R * PPU, 1.32 * PPU, 18, shade(c2, 0.1), shade(c1, 0.2));
    paintAvatarDisc(ctx, avatar, X(pc.x), Y(pc.y), R * PPU, c1, rng, { ringW: 0.15, innerRing: c2, glow: c1 });
    const boxes = paintBlockText(ctx, m.name, X(m.w / 2), Y(0.98), 0.6 * PPU, (m.w + 0.5) * PPU, {
      fill: ['#ffffff', shade(c1, 0.2), shade(c1, -0.35)], outline: INK, outline2: c2, shadow: '#1d1028', glow: c1,
    });
    const rib = drawRibbon(ctx, X(m.w / 2), Y(0.3), 2.2 * PPU, 0.36 * PPU, ['#ff2e88', '#ff6b1a', '#ffd23f'], 'BIG GIFTER');
    const lc = L(pc.x, pc.y);
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.35, overspray: c1, strokes: discStrokes(lc.x, lc.y, R * 1.12, 1.34, 0.18, 2.6) });
    art.layers.push({ tool: 'spray', color: c2, hardness: 0.4, overspray: c2, strokes: letterStrokes(boxes, H, 0.12, 2.4, 0.92) });
    art.layers.push({ tool: 'spray', color: '#ff6b1a', hardness: 0.4, overspray: '#ff2e88', strokes: rectStrokes(rib, H, 0.1, 2.6) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.2), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(1.3), bottom: Y(0.55) }, 4, c1, rng, 0.15, 0.5);
    addSplashes(art, 4, [c1, c2, '#ffffff'], rng, 0.18, 0.34, true);
    addSparkles(art, 3, rng, c2, { x0: X(0.1), x1: X(m.w - 0.1), top: Y(m.h - 0.1), bottom: Y(1.5) });
  } else if (m.kind === 'vip') {
    // 20 coins — winged VIP piece with chrome letters
    const c1 = pick(rng, ['#a66bff', '#19e3ff', '#ff2e88']);
    const c2 = pick(rng, NEON.filter((c) => c !== c1));
    art.color = c1;
    art.glow = true;
    const R = 0.78, pc = { x: m.w / 2, y: 2.2 };
    drawWings(ctx, X(pc.x), Y(pc.y), R * PPU, c1);
    ctx.save();
    ctx.shadowColor = GOLD[1];
    ctx.shadowBlur = 24;
    ctx.strokeStyle = GOLD[1];
    ctx.lineWidth = 0.07 * PPU;
    ctx.beginPath();
    ctx.ellipse(X(pc.x), Y(pc.y + R + 0.2), 0.48 * PPU, 0.11 * PPU, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    paintAvatarDisc(ctx, avatar, X(pc.x), Y(pc.y), R * PPU, c1, rng, { ringW: 0.15, innerRing: '#ffffff', glow: c1 });
    const boxes = paintBlockText(ctx, m.name, X(m.w / 2), Y(0.98), 0.58 * PPU, (m.w + 0.4) * PPU, {
      fill: ['#ffffff', '#cdd8ff', '#6b7bb8', '#e9eeff'], outline: INK, outline2: c1, shadow: '#141028', glow: c1,
    });
    const rib = drawRibbon(ctx, X(m.w / 2), Y(0.3), 2.4 * PPU, 0.36 * PPU, [c1, '#19e3ff', c1], 'VIP GIFTER');
    const lc = L(pc.x, pc.y);
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.35, overspray: c1, strokes: discStrokes(lc.x, lc.y + 0.1, R * 1.12, 1.62, 0.18, 2.6) });
    art.layers.push({ tool: 'spray', color: c2, hardness: 0.4, overspray: c1, strokes: letterStrokes(boxes, H, 0.12, 2.4, 0.92) });
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.4, overspray: c1, strokes: rectStrokes(rib, H, 0.1, 2.6) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.2), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(1.3), bottom: Y(0.55) }, 3, c1, rng, 0.15, 0.5);
    addSplashes(art, 3, [c1, c2, '#ffffff'], rng, 0.18, 0.32, true);
    addSparkles(art, 4, rng, '#ffffff', { x0: X(0.1), x1: X(m.w - 0.1), top: Y(m.h - 0.1), bottom: Y(1.6) });
  } else {
    // special (THE GREAT GIFTER) and legendary (LEGENDARY GIFTER)
    const legend = m.kind === 'legendary';
    const c1 = pick(rng, ['#ff2e88', '#19e3ff', '#a66bff']);
    art.color = GOLD[1];
    art.glow = true;
    art.gold = true;
    const R = legend ? 1.45 : 1.3, pc = { x: m.w / 2, y: legend ? 4.45 : 4.15 };
    const rayR = R * (2.0 / 1.3);
    const halo = ctx.createRadialGradient(X(pc.x), Y(pc.y), R * PPU, X(pc.x), Y(pc.y), (rayR + 0.15) * PPU);
    halo.addColorStop(0, 'rgba(255,216,77,0.65)');
    halo.addColorStop(1, 'rgba(255,216,77,0)');
    ctx.fillStyle = halo;
    ctx.fillRect(0, 0, canvas.width, canvas.height * 0.75);
    drawRays(ctx, X(pc.x), Y(pc.y), R * PPU, rayR * PPU, legend ? 32 : 24, GOLD[1], shade(c1, 0.15));
    if (legend) {
      for (let i = 0; i < 3; i++) {
        ctx.save();
        ctx.globalAlpha = 0.55;
        ctx.strokeStyle = NEON[(i * 3) % NEON.length];
        ctx.shadowColor = ctx.strokeStyle;
        ctx.shadowBlur = 18;
        ctx.lineWidth = 0.05 * PPU;
        ctx.beginPath();
        ctx.arc(X(pc.x), Y(pc.y), (rayR + 0.08 + i * 0.09) * PPU, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }
    paintAvatarDisc(ctx, avatar, X(pc.x), Y(pc.y), R * PPU, c1, rng, { ringW: 0.14, gold: true, glow: GOLD[1], innerRing: c1, haloColor: GOLD[1] });
    drawCrown(ctx, X(pc.x), Y(pc.y + R + 0.12), 1.3 * PPU, 0.66 * PPU, c1);
    const boxes = paintBlockText(ctx, m.name, X(m.w / 2), Y(legend ? 2.1 : 1.85), (legend ? 1.1 : 1.0) * PPU, (m.w + 0.6) * PPU, {
      fill: GOLD, outline: '#2a1600', outline2: c1, shadow: '#3a1d00', glow: '#ffcf40', depth: 10,
    });
    const ban = drawRibbon(ctx, X(m.w / 2), Y(0.6), (legend ? 5.0 : 4.2) * PPU, (legend ? 0.7 : 0.62) * PPU, ['#2a1600', '#5c3600', '#2a1600'], legend ? 'LEGENDARY GIFTER' : 'THE GREAT GIFTER', GOLD[1]);
    ctx.lineWidth = 6;
    ctx.strokeStyle = GOLD[1];
    ctx.strokeRect(ban.x0 + 0.3 * PPU, ban.top + 8, ban.x1 - ban.x0 - 0.6 * PPU, ban.bottom - ban.top - 16);
    const lc = L(pc.x, pc.y + 0.15);
    art.layers.push({ tool: 'spray', color: GOLD[1], hardness: 0.35, overspray: GOLD[1], strokes: discStrokes(lc.x, lc.y - 0.15, R * 1.12, rayR + 0.1, 0.3, 3.1) });
    art.layers.push({ tool: 'spray', color: GOLD[2], hardness: 0.4, overspray: GOLD[1], strokes: letterStrokes(boxes, H, 0.2, 2.9, 0.92) });
    art.layers.push({ tool: 'spray', color: c1, hardness: 0.4, overspray: GOLD[1], strokes: rectStrokes(ban, H, 0.15, 3.2) });
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    addDrips(art, img, { x0: boxes[0]?.x0 ?? X(0.3), x1: boxes.at(-1)?.x1 ?? X(m.w), top: Y(2.5), bottom: Y(1.1) }, 6, GOLD[1], rng, 0.2, 0.6);
    addDrips(art, img, { x0: X(pc.x - 1.0), x1: X(pc.x + 1.0), top: Y(pc.y), bottom: Y(pc.y - rayR - 0.05) }, 3, GOLD[2], rng, 0.15, 0.4);
    addSplashes(art, 5, [GOLD[1], GOLD[0], c1], rng, 0.2, 0.42, true);
    addSparkles(art, 9, rng, GOLD[1], { x0: X(0.1), x1: X(m.w - 0.1), top: Y(m.h), bottom: Y(2.4) });
  }

  // spray grain over everything so it reads as paint on rough concrete
  ctx.save();
  ctx.globalCompositeOperation = 'source-atop';
  ctx.globalAlpha = 0.07;
  ctx.fillStyle = ctx.createPattern(grainTile(), 'repeat');
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
  return art;
}

/** The finished piece with drips/splashes applied (used when restoring the wall). */
export function finalCanvas(art) {
  const c = document.createElement('canvas');
  c.width = art.canvas.width;
  c.height = art.canvas.height;
  const ctx = c.getContext('2d');
  ctx.drawImage(art.canvas, 0, 0);
  for (const e of art.extras) drawExtraFull(ctx, e);
  return c;
}
