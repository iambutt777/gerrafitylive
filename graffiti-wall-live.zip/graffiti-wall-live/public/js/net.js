// net.js — connection to the Node server (real TikTok events + wall saving)
// and a simulator that produces the exact same event shapes.

import { avatarDataURL } from './art.js';

export function createNet({ onLive, onStatus, onHistory, onViewers = () => {}, onLayout = () => {}, onLeaderboard = () => {}, onPrefs = () => {}, onAuth = () => {}, clean = false, key = '' }) {
  const api = {
    online: false,
    connect: () => Promise.resolve({ ok: false, error: 'Server not available.' }),
    disconnect: () => {},
    saveArt: () => {},
    resetWall: () => {},
    saveLayout: () => {},
    sendSim: () => {},
    resetLeaderboard: () => {},
    savePrefs: () => {},
    login: () => {},
  };
  if (typeof window.io !== 'function') return api;

  const socket = window.io({ transports: ['websocket', 'polling'] });
  let gotHistory = false;
  api.online = true;
  socket.on('live', (e) => onLive(e));
  socket.on('status', (s) => onStatus(s));
  socket.on('history', (records) => {
    // restore once per page load; phones reconnect often and that must never reset anything
    if (gotHistory) return;
    gotHistory = true;
    onHistory(Array.isArray(records) ? records : [], false);
  });
  socket.on('wall:cleared', () => onHistory([], true));
  socket.on('viewers', (n) => onViewers(Number(n)));
  socket.on('layout', (l) => onLayout(l));
  socket.on('leaderboard', (list) => onLeaderboard(Array.isArray(list) ? list : []));
  socket.on('prefs', (p) => onPrefs(p || {}));
  socket.on('disconnect', () => onStatus({ state: 'server-offline' }));
  // tell the server whether this is the OBS source, so only one screen saves the wall
  let recorder = false;
  let adminKey = key;
  socket.on('connect', () => socket.emit('hello', { clean, key: adminKey }));
  socket.on('auth', (a) => onAuth(a || {}));
  api.login = (k) => { adminKey = k; socket.emit('hello', { clean, key: adminKey }); };
  socket.on('role', (r) => { recorder = Boolean(r && r.recorder); });

  api.connect = (username, apiKey) => new Promise((resolve) => socket.emit('tiktok:connect', { username, apiKey }, resolve));
  api.disconnect = () => socket.emit('tiktok:disconnect');
  api.saveArt = (record) => { if (recorder) socket.emit('art:done', record); };
  api.resetWall = () => socket.emit('wall:reset');
  api.saveLayout = (layout) => socket.emit('layout:set', layout);
  api.sendSim = (e) => socket.emit('sim:event', e);
  api.resetLeaderboard = () => socket.emit('leaderboard:reset');
  api.savePrefs = (p) => socket.emit('prefs:set', p);
  return api;
}

const SIM_NAMES = [
  'neon.kai', 'spraygod_77', 'luna.vibes', 'mr.drip', 'tagqueen', 'zoe_paints', 'urban.rex',
  'pixelpanda', 'kaito.live', 'mia.colors', 'djsplash', 'graff.addict', 'skyler88', 'nova.cans',
  'bolt.writer', 'aya_streets', 'theo.wav', 'carla.mp4',
];

export class Simulator {
  constructor(ingest) {
    this.ingest = ingest;
    this.users = SIM_NAMES.map((n) => {
      const u = { id: n, handle: n, name: n.replace(/[._]/g, ' '), avatar: '' };
      u.avatar = avatarDataURL(u);
      return u;
    });
    this.autoTimer = null;
  }

  user() {
    return this.users[Math.floor(Math.random() * this.users.length)];
  }

  like(user = this.user(), count = 40) {
    this.ingest({ type: 'like', user, count });
  }

  share(user = this.user()) {
    this.ingest({ type: 'share', user });
  }

  gift(coins, giftName, user = this.user()) {
    this.ingest({ type: 'gift', user, coins, giftName });
  }

  run(kind) {
    if (kind === 'like') this.like();
    else if (kind === 'share') this.share();
    else if (kind === 'join') this.ingest({ type: 'join', user: this.user() });
    else if (kind === 'gift1') this.gift(1, 'Rose');
    else if (kind === 'roses') {
      const u = this.user();
      for (let i = 0; i < 5; i++) setTimeout(() => this.gift(1, 'Rose', u), i * 400);
    } else if (kind === 'gift5') this.gift(5, 'Sim gift');
    else if (kind === 'gift20') this.gift(20, 'Sim gift');
    else if (kind === 'gift30') this.gift(30, 'Sim gift');
    else if (kind === 'gift100') this.gift(100, 'Sim gift');
    else if (kind === 'burst') this.burst(30);
  }

  /** Many mixed events in a few seconds, including likes trickling in from the same viewers. */
  burst(n) {
    for (let i = 0; i < n; i++) {
      setTimeout(() => {
        const r = Math.random();
        if (r < 0.55) this.like(this.users[i % 6], 10 + Math.floor(Math.random() * 30));
        else if (r < 0.75) this.share(this.users[i % 9]);
        else if (r < 0.9) this.gift(1, 'Rose');
        else if (r < 0.95) this.gift(5, 'Sim gift');
        else if (r < 0.98) this.gift(20, 'Sim gift');
        else this.gift(30, 'Sim gift');
      }, Math.random() * 4000);
    }
  }

  setAuto(on) {
    clearTimeout(this.autoTimer);
    if (!on) return;
    const tick = () => {
      const r = Math.random();
      if (r < 0.5) this.like();
      else if (r < 0.72) this.share();
      else if (r < 0.88) this.gift(1, 'Rose');
      else if (r < 0.95) this.gift(5, 'Sim gift');
      else if (r < 0.985) this.gift(20, 'Sim gift');
      else this.gift(30, 'Sim gift');
      this.autoTimer = setTimeout(tick, 2500 + Math.random() * 5000);
    };
    tick();
  }
}
