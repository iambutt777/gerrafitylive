// animations.js — everything the artist does, as awaitable actions.
//
//   Tasks         a frame-driven scheduler (wait / tween / per-frame steps)
//   Actor         the artist's actions: walk, turn, set down / pick up the
//                 bucket, take tools, shake, paint along strokes, fetch / carry /
//                 place / climb / remove the ladder
//   Choreographer one async routine per event type, built from those actions:
//                 walk right → stop → turn to the wall → paint → step back.

import * as THREE from 'three';
import { DIM, LADDER } from './character.js';
import { loadAvatar, measureArt, composeArt, hashStr, GOLD, NEON } from './art.js';
import { spinWheels } from './vehicles.js';

const V3 = THREE.Vector3;
const clamp = THREE.MathUtils.clamp;
const damp = THREE.MathUtils.damp;
export const LANE_Z = 1.75;
/** Spray strokes (gifts) run this many times faster than their base speed. */
export const SPRAY_SPEED = 3.5;
/** Brush strokes (likes and shares) run this many times faster than their base speed. */
export const BRUSH_SPEED = 2.2;
const TAU = Math.PI * 2;

export const ease = {
  inOut: (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2),
  out: (k) => 1 - (1 - k) * (1 - k),
  linear: (k) => k,
};

function angleDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

const smooth = (k) => k * k * (3 - 2 * k);
/** Discrete rung stepping for climbing: holds on every other rung, moves in the second half. */
function stepFn(c, off) {
  const k = (c + off) / 2;
  const i = Math.floor(k);
  const f = k - i;
  return Math.max(-1, (i + smooth(clamp((f - 0.5) / 0.5, 0, 1))) * 2 - off);
}

// ---------- scheduler ----------
export class Tasks {
  constructor() {
    this.items = [];
    this.time = 0;
  }

  update(dt) {
    this.time += dt;
    const list = this.items;
    this.items = [];
    for (const it of list) {
      let done = false;
      try {
        done = it.step(dt);
      } catch (err) {
        console.error(err);
        done = true;
      }
      if (done) it.resolve();
      else this.items.push(it);
    }
  }

  frame(step) {
    return new Promise((resolve) => this.items.push({ step, resolve }));
  }

  wait(sec) {
    let t = 0;
    return this.frame((dt) => (t += dt) >= sec);
  }

  tween(sec, fn, easing = ease.inOut) {
    let t = 0;
    fn(0);
    return this.frame((dt) => {
      t += dt;
      const k = Math.min(1, t / sec);
      fn(easing(k));
      return k >= 1;
    });
  }
}

// ---------- ladder poses ----------
const LEAN_Q = new THREE.Quaternion().setFromEuler(new THREE.Euler(-LADDER.LEAN, 0, 0));
const LYING_Q = new THREE.Quaternion().setFromRotationMatrix(
  new THREE.Matrix4().makeBasis(new V3(0, 0, 1), new V3(1, 0, 0), new V3(0, 1, 0)),
);
const CARRY_LOCAL_Q = new THREE.Quaternion().setFromRotationMatrix(
  new THREE.Matrix4().makeBasis(new V3(0, -1, 0), new V3(0, 0, 1), new V3(-1, 0, 0)),
);
const CARRY_LOCAL_P = new V3(-0.2, 0.62, -3.35);
const LADDER_U = new V3(0, Math.cos(LADDER.LEAN), -Math.sin(LADDER.LEAN));
const LADDER_N = new V3(0, Math.sin(LADDER.LEAN), Math.cos(LADDER.LEAN));

const _a = new V3(), _b = new V3(), _c = new V3(), _d = new V3(), _e = new V3(), _tip = new V3();
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _s = new V3();
const _eul = new THREE.Euler();
const _p2 = new V3();
const _dir = new V3();
const BOMB_GEO = new THREE.SphereGeometry(0.08, 14, 10);
const NEON_BOMBS = ['#ff2e88', '#19e3ff', '#b6ff3b', '#ffd23f', '#a66bff'];

// ---------- the artist ----------
export class Actor {
  constructor({ character, tasks, sound, fx, scene, ladder, bucket, camera }) {
    this.ch = character;
    this.tasks = tasks;
    this.sound = sound;
    this.fx = fx;
    this.scene = scene;
    this.ladder = ladder;
    this.bucket = bucket;
    this.camera = camera;
    this.pos = new V3(1.2, 0, LANE_Z);
    this.yaw = Math.PI / 2;
    this.speedMul = 1;
    this.s = {
      walkPhase: 0, walkBlend: 0, sideMode: 0, crouch: 0, tiptoe: 0, lean: 0,
      holdBucket: true, legW: 1, footL: null, footR: null, look: null,
      armR: { w: 0, target: new V3(), aim: new V3(0, 0, -1), up: new V3(0, 1, 0) },
      armL: { w: 0, target: new V3(), aim: new V3(0, 0, -1), up: new V3(0, 1, 0) },
    };
    this.goal = { crouch: 0, lean: 0, tiptoe: 0, armR: 0, armL: 0, sideMode: 0 };
    this.locoSpeed = 0;
    this.paint = { active: false, tool: null, target: new V3(), spraying: false, color: '#ffffff', standZ: 0.8, follow: true, lift: 0, intensity: 1 };
    this.armROverride = null;
    this.armLOverride = null;
    this.climb = null; // { c, x }
    this.ladderState = { mode: 'lying', x: -6 }; // lying | carried | leaning | moving
    this.bucketHeld = Boolean(bucket);
    this.platform = null; // { obj, offset, ground, enter } while riding the boom-lift basket
    this.footL = new V3();
    this.footR = new V3();
    this._prevPhase = 0;
    this._lookPt = new V3();
    this.idleLookCamera = false;
    character.root.position.copy(this.pos);
    scene.add(character.root);
    if (ladder) this.setLadderPose(this.lyingPose(this.ladderState.x));
  }

  // ----- helpers -----
  forward(out = new V3()) {
    return out.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
  }
  left(out = new V3()) {
    return out.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
  }
  chestFront(out, dist = 0.34, h = 1.22) {
    this.forward(_e);
    return out.copy(this.pos).addScaledVector(_e, dist).setY(h - this.s.crouch * 0.4);
  }

  leaningPose(x) {
    return { p: new V3(x, 0, LADDER.BASE_Z), q: LEAN_Q.clone() };
  }
  lyingPose(cx) {
    return { p: new V3(cx - LADDER.LEN / 2, 0.038, LADDER.LIE_Z), q: LYING_Q.clone() };
  }
  carriedPose() {
    const chest = this.ch.j.chest;
    chest.updateWorldMatrix(true, false);
    _m.compose(CARRY_LOCAL_P, CARRY_LOCAL_Q, _s.set(1, 1, 1)).premultiply(chest.matrixWorld);
    const p = new V3(), q = new THREE.Quaternion();
    _m.decompose(p, q, _s);
    return { p, q };
  }
  setLadderPose(pose) {
    this.ladder.position.copy(pose.p);
    this.ladder.quaternion.copy(pose.q);
  }
  ladderPoint(x, along, out) {
    this.ladder.updateMatrixWorld(true);
    return this.ladder.localToWorld(out.set(x, along, 0.03));
  }

  // ----- per-frame -----
  update(dt) {
    const s = this.s;
    const ch = this.ch;
    s.crouch = damp(s.crouch, this.goal.crouch, 6, dt);
    s.lean = damp(s.lean, this.goal.lean, 5, dt);
    s.tiptoe = damp(s.tiptoe, this.goal.tiptoe, 5, dt);
    s.sideMode = damp(s.sideMode, this.goal.sideMode, 6, dt);

    if (this.paint.active && this.paint.follow && !this.climb) this._followPaint(dt);

    s.walkBlend = damp(s.walkBlend, clamp(this.locoSpeed / 1.1, 0, 1), 7, dt);
    if (!this.climb && s.walkBlend > 0.25 && Math.floor(s.walkPhase / Math.PI) !== Math.floor(this._prevPhase / Math.PI)) {
      this.sound.footstep(Math.min(1, s.walkBlend + 0.2));
    }
    this._prevPhase = s.walkPhase;
    this.locoSpeed = 0;

    const root = ch.root;
    if (this.climb) {
      this._climbPose();
    } else if (this.platform) {
      const p = this.platform;
      p.obj.updateMatrixWorld(true);
      const onBasket = p.obj.localToWorld(_p2.copy(p.offset));
      _dir.set(1, 0, 0).transformDirection(p.obj.matrixWorld);
      this.yaw = Math.atan2(_dir.x, _dir.z);
      const k = p.enter;
      root.position.lerpVectors(p.ground, onBasket, k);
      root.position.y += Math.sin(k * Math.PI) * 0.35;
      root.rotation.set(0, this.yaw, 0, 'YXZ');
      this.pos.set(root.position.x, 0, root.position.z);
      s.footL = s.footR = null;
      s.legW = 1;
      s.walkBlend = 0;
    } else {
      root.position.copy(this.pos);
      root.rotation.set(0, this.yaw, 0, 'YXZ');
      s.footL = s.footR = null;
      s.legW = 1 - s.walkBlend;
    }
    root.updateMatrixWorld(true);

    if (this.paint.active) {
      this._paintArm();
      this.goal.armR = 1;
      s.look = this.paint.target;
    } else if (!this.climb) {
      s.look = this.idleLookCamera ? this.camera.position : null;
    }
    if (this.armROverride) this.armROverride(s.armR, dt);
    if (this.armLOverride) this.armLOverride(s.armL, dt);
    s.armR.w = damp(s.armR.w, this.goal.armR, 9, dt);
    s.armL.w = damp(s.armL.w, this.goal.armL, 9, dt);
    s.holdBucket = this.bucketHeld;

    ch.applyPose(s, dt);

    if (this.ladderState.mode === 'carried') this.setLadderPose(this.carriedPose());
    if (this.bucketHeld) {
      ch.gripWorld('L', _a);
      this.bucket.position.set(_a.x, _a.y - this.bucket.userData.handleTop, _a.z);
      this.bucket.quaternion.setFromEuler(_eul.set(0, this.yaw, 0));
    }
    if (this.paint.active && this.paint.spraying) {
      ch.toolTipWorld(_tip);
      this.fx.spray(_tip, this.paint.target, this.paint.color, dt, this.paint.intensity);
    }
  }

  _followPaint(dt) {
    const t = this.paint.target;
    // body stays a little left of the hand (right hand paints, camera sits on the right)
    const desiredX = t.x - 0.24;
    const v = clamp((desiredX - this.pos.x) * 4, -1.1, 1.1) * this.speedMul;
    const step = v * dt;
    this.pos.x += step;
    this.pos.z = damp(this.pos.z, this.paint.standZ, 4, dt);
    this.yaw += angleDiff(this.yaw, Math.PI) * Math.min(1, dt * 6);
    this.s.walkPhase += (Math.abs(step) / 0.6) * Math.PI;
    this.locoSpeed = Math.max(this.locoSpeed, Math.abs(v) * 0.6);
    this.goal.sideMode = 1;
    const y = t.y;
    if (this.paint.tool === 'brush') {
      this.goal.crouch = clamp((1.22 - y) / 0.65, 0, 0.85);
      this.goal.tiptoe = clamp((y - 1.95) / 0.35, 0, 1);
      this.goal.lean = 0.08;
    } else {
      this.goal.crouch = clamp((1.05 - y) / 0.7, 0, 0.75);
      this.goal.tiptoe = clamp((y - 2.6) / 0.6, 0, 1);
      this.goal.lean = 0.03;
    }
  }

  _paintArm() {
    const p = this.paint;
    const sh = this.ch.j.shR.getWorldPosition(_a);
    const tgt = p.target;
    const tipLen = DIM.grip + (p.tool === 'brush' ? 0.3 : 0.18);
    const aim = _b;
    if (p.tool === 'brush') aim.set((tgt.x - sh.x) * 0.25, (tgt.y - sh.y) * 0.35, -1).normalize();
    else aim.subVectors(tgt, sh).normalize().add(_c.set(0, 0, -0.7)).normalize();
    const back = tipLen + (p.tool === 'brush' ? 0 : 0.26) + p.lift;
    const wrist = _c.copy(tgt).addScaledVector(aim, -back);
    const off = _d.subVectors(wrist, sh);
    const reach = (DIM.upper + DIM.fore) * 0.96;
    if (off.length() > reach) {
      wrist.copy(sh).addScaledVector(off.normalize(), reach);
      aim.subVectors(tgt, wrist).normalize();
    }
    this.s.armR.target.copy(wrist);
    this.s.armR.aim.copy(aim);
    this.s.armR.up.set(0, 1, 0);
  }

  _rungPoint(idx, side, out, lift = 0.12) {
    const i = clamp(idx, -1, LADDER.RUNGS - 1);
    const f = i - Math.floor(i);
    const along = (i + 1) * LADDER.SP;
    const base = this.climb.x;
    return out.set(base, 0, LADDER.BASE_Z)
      .addScaledVector(LADDER_U, along)
      .addScaledVector(LADDER_N, 0.05 + Math.sin(f * Math.PI) * lift)
      .add(_e.set(side, 0, 0));
  }

  _climbPose() {
    const s = this.s;
    const c = this.climb.c;
    const root = this.ch.root;
    root.position.set(this.climb.x, 0, LADDER.BASE_Z)
      .addScaledVector(LADDER_U, (c + 1) * LADDER.SP)
      .addScaledVector(LADDER_N, 0.3);
    root.rotation.set(LADDER.LEAN * 0.9, Math.PI, 0, 'YXZ');
    // facing the wall, the artist's left side is world -x
    s.footL = this._rungPoint(stepFn(c, 0), -0.11, this.footL, 0.14).addScaledVector(LADDER_U, 0.06);
    s.footR = this._rungPoint(stepFn(c, 1), 0.11, this.footR, 0.14).addScaledVector(LADDER_U, 0.06);
    s.legW = 1;
    s.walkBlend = 0;
    this.goal.armL = 1;
    this.armLOverride = (arm) => {
      this._rungPoint(Math.min(LADDER.RUNGS - 1, stepFn(c, 1) + 5), -LADDER.RAIL, arm.target, 0.08);
      arm.aim.set(0, 0, -1);
      arm.up.copy(LADDER_U);
    };
    if (!this.paint.active) {
      this.goal.armR = 1;
      this.armROverride = (arm) => {
        this._rungPoint(Math.min(LADDER.RUNGS - 1, stepFn(c, 0) + 5), LADDER.RAIL, arm.target, 0.08);
        arm.aim.set(0, 0, -1);
        arm.up.copy(LADDER_U);
      };
    } else {
      this.armROverride = null;
    }
    s.look = this.paint.active ? this.paint.target : _c.copy(root.position).addScaledVector(LADDER_U, 2.5).add(_d.set(0, 0, -0.2));
  }

  // ----- locomotion -----
  async walkTo(x, z, speed = 1.45) {
    const target = new V3(x, 0, z);
    this.goal.sideMode = 0;
    this.idleLookCamera = false;
    await this.tasks.frame((dt) => {
      const d = _a.subVectors(target, this.pos);
      d.y = 0;
      const dist = d.length();
      if (dist < 0.03) {
        this.pos.x = x;
        this.pos.z = z;
        return true;
      }
      const want = Math.atan2(d.x, d.z);
      const diff = angleDiff(this.yaw, want);
      this.yaw += clamp(diff, -7 * dt, 7 * dt);
      const face = Math.max(0, Math.cos(diff));
      const v = Math.min(speed * this.speedMul, dist * 2.2 + 0.25) * face * face;
      const step = Math.min(dist, v * dt);
      this.pos.addScaledVector(d.normalize(), step);
      this.s.walkPhase += (step / 1.35) * TAU;
      this.locoSpeed = Math.max(v, 0.25);
      if (face < 0.5) {
        this.s.walkPhase += dt * 5;
        this.locoSpeed = 0.45;
      }
      return false;
    });
  }

  async turnTo(yaw) {
    await this.tasks.frame((dt) => {
      const d = angleDiff(this.yaw, yaw);
      this.yaw += clamp(d, -5 * dt, 5 * dt);
      if (Math.abs(d) > 0.05) {
        this.s.walkPhase += dt * 6;
        this.locoSpeed = 0.4;
      }
      return Math.abs(d) < 0.02;
    });
  }

  // ----- bucket & tools -----
  bucketSpot() {
    return this.pos.clone().addScaledVector(this.left(_a), 0.42).addScaledVector(this.forward(_b), 0.1).setY(0);
  }

  async setDownBucket() {
    if (!this.bucketHeld) return;
    this.goal.crouch = 0.8;
    this.goal.lean = 0.25;
    await this.tasks.wait(0.36);
    const from = this.bucket.position.clone();
    const fq = this.bucket.quaternion.clone();
    const spot = this.bucketSpot();
    const toQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, this.yaw, 0));
    this.bucketHeld = false;
    await this.tasks.tween(0.22, (k) => {
      this.bucket.position.lerpVectors(from, spot, k);
      this.bucket.quaternion.slerpQuaternions(fq, toQ, k);
    });
    this.sound.thunk();
    this.goal.crouch = 0;
    this.goal.lean = 0;
    await this.tasks.wait(0.2);
  }

  async pickUpBucket() {
    if (this.bucketHeld) return;
    await this.walkTo(this.bucket.position.x - this.left(_a).x * 0.42, this.pos.z);
    this.goal.crouch = 0.8;
    this.goal.lean = 0.25;
    await this.tasks.wait(0.36);
    const from = this.bucket.position.clone();
    const fq = this.bucket.quaternion.clone();
    await this.tasks.tween(0.2, (k) => {
      this.ch.gripWorld('L', _a);
      _b.set(_a.x, _a.y - this.bucket.userData.handleTop, _a.z);
      this.bucket.position.lerpVectors(from, _b, k);
      this.bucket.quaternion.slerpQuaternions(fq, _q.setFromEuler(new THREE.Euler(0, this.yaw, 0)), k);
    });
    this.bucketHeld = true;
    this.goal.crouch = 0;
    this.goal.lean = 0;
    await this.tasks.wait(0.2);
  }

  async _reachBucket(onReach, dip = false) {
    const top = this.bucket.position.clone().add(new V3(0, 0.3, 0));
    const start = this.ch.gripWorld('R', new V3());
    const pt = start.clone();
    this.goal.crouch = 0.78;
    this.goal.lean = 0.22;
    this.goal.armR = 1;
    this.armROverride = (arm) => {
      arm.target.copy(pt);
      arm.aim.set(0, -1, 0.15).normalize();
      arm.up.set(0, 0, -1);
    };
    await this.tasks.tween(0.42, (k) => pt.lerpVectors(start, top, k));
    if (dip) {
      await this.tasks.tween(0.18, (k) => pt.copy(top).add(_a.set(0, -0.14 * Math.sin(k * Math.PI), 0)));
    }
    onReach();
    const front = this.chestFront(new V3());
    const from = pt.clone();
    await this.tasks.tween(0.32, (k) => pt.lerpVectors(from, front, k));
    this.goal.crouch = 0;
    this.goal.lean = 0;
    this.armROverride = null;
    this.goal.armR = 0;
  }

  async takeTool(name, color) {
    if (this.ch.heldName === name) return;
    if (color) {
      this.ch.setPaintColor(color);
      this.bucket.userData.paintMats[0].color.set(color);
    }
    const swap = () => {
      this.ch.setTool(name);
      this.sound.clink();
    };
    if (this.bucketHeld) await this._reachHeldBucket(swap);
    else await this._reachBucket(swap, name === 'brush');
  }

  /** Swaps tools from the bucket hanging in the left hand, without crouching. */
  async _reachHeldBucket(onReach) {
    const start = this.ch.gripWorld('R', new V3());
    const pt = start.clone();
    const top = () => _d.copy(this.bucket.position).add(_e.set(0, 0.34, 0));
    this.goal.armR = 1;
    this.goal.crouch = 0.15;
    this.armROverride = (arm) => {
      arm.target.copy(pt);
      arm.aim.set(0, -1, 0.2).normalize();
      arm.up.copy(this.forward(_c));
    };
    await this.tasks.tween(0.22, (k) => pt.lerpVectors(start, top(), k));
    onReach();
    const from = pt.clone();
    const front = this.chestFront(new V3());
    await this.tasks.tween(0.18, (k) => pt.lerpVectors(from, front, k));
    this.goal.crouch = 0;
    this.armROverride = null;
    this.goal.armR = 0;
  }

  /** Only when nobody is waiting: step back, face the camera for a moment. */
  async poseForCamera(shouldStop) {
    await this.walkTo(this.pos.x + 0.3, LANE_Z);
    if (shouldStop()) return;
    const cam = this.camera.position;
    await this.turnTo(Math.atan2(cam.x - this.pos.x, cam.z - this.pos.z));
    this.idleLookCamera = true;
    let t = 0;
    await this.tasks.frame((dt) => (t += dt) > 1.8 || shouldStop());
    this.idleLookCamera = false;
  }

  async stowTool() {
    if (!this.ch.heldName) return;
    await this._reachBucket(() => {
      this.ch.setTool(null);
      this.sound.clink();
    });
  }

  async shake() {
    let t = 0;
    const base = new V3();
    this.goal.armR = 1;
    this.armROverride = (arm, dt) => {
      t += dt;
      this.chestFront(base, 0.3, 1.25);
      base.addScaledVector(this.left(_a), -0.12);
      arm.target.copy(base).add(_b.set(0, Math.sin(t * 30) * 0.07, 0));
      arm.aim.set(0, 1, 0);
      arm.up.copy(this.forward(_c)).negate();
    };
    this.sound.shake();
    await this.tasks.wait(0.5);
    this.armROverride = null;
    this.goal.armR = 0;
  }

  // ----- painting -----
  beginPaint(tool, color, standZ) {
    this.paint.active = true;
    this.paint.tool = tool;
    this.paint.color = color;
    this.paint.standZ = standZ ?? (tool === 'brush' ? 0.7 : 0.92);
    this.paint.follow = !this.climb && !this.platform;
    this.paint.spraying = false;
    this.paint.lift = 0;
    this.ch.setPaintColor(color);
    this.armROverride = null;
    if (!this.paint.started) {
      this.ch.toolTipWorld(_a);
      this.paint.target.set(_a.x, _a.y, 0);
    }
  }

  endPaint() {
    this.paint.active = false;
    this.paint.spraying = false;
    this._stopSounds();
    this.goal.armR = 0;
    this.goal.crouch = 0;
    this.goal.tiptoe = 0;
    this.goal.lean = 0;
    this.goal.sideMode = 0;
  }

  _stopSounds() {
    if (this.sprayHandle) this.sprayHandle.stop();
    if (this.brushHandle) this.brushHandle.stop();
    this.sprayHandle = this.brushHandle = null;
  }

  async _glideTo(point, time) {
    const from = this.paint.target.clone();
    this.paint.spraying = false;
    await this.tasks.tween(time, (k) => {
      this.paint.target.lerpVectors(from, point, k);
      this.paint.lift = Math.sin(k * Math.PI) * 0.12;
    });
    this.paint.lift = 0;
  }

  /** Follows every stroke of a layer, revealing the artwork under the tool. */
  async paintLayer(aw, layer, speedMul = 1, shouldStop = null) {
    const tool = layer.tool;
    const rng = Math.random;
    const toolMul = tool === 'spray' ? SPRAY_SPEED : BRUSH_SPEED;
    for (const st of layer.strokes) {
      if (shouldStop && shouldStop()) return false;
      if (!st.pts.length) continue;
      const pts = st.pts;
      const startW = aw.toWorld(pts[0], new V3());
      await this._glideTo(startW, Math.max(0.12, Math.min(0.5, this.paint.target.distanceTo(startW) / 3)) / (speedMul * toolMul));
      const spacing = st.radius * 0.42;
      const last = { x: pts[0].x, y: pts[0].y };
      const pen = { x: pts[0].x, y: pts[0].y };
      aw.stamp(last.x, last.y, st.radius, st.alpha, layer.hardness, layer.overspray, rng);
      if (tool === 'spray') {
        this.paint.spraying = true;
        this.sprayHandle = this.sound.sprayStart();
      } else {
        this.brushHandle = this.sound.brushStart();
      }
      let seg = 0, segT = 0;
      const speed = st.speed * speedMul * toolMul;
      await this.tasks.frame((dt) => {
        let travel = speed * dt;
        while (travel > 0 && seg < pts.length - 1) {
          const a = pts[seg], b = pts[seg + 1];
          const L = Math.hypot(b.x - a.x, b.y - a.y);
          const step = Math.min(travel, L - segT);
          segT += step;
          travel -= step;
          const k = L > 1e-6 ? segT / L : 1;
          pen.x = a.x + (b.x - a.x) * k;
          pen.y = a.y + (b.y - a.y) * k;
          let dx = pen.x - last.x, dy = pen.y - last.y, d = Math.hypot(dx, dy);
          let guard = 0;
          while (d >= spacing && guard++ < 60) {
            last.x += (dx / d) * spacing;
            last.y += (dy / d) * spacing;
            aw.stamp(last.x, last.y, st.radius, st.alpha, layer.hardness, layer.overspray, rng);
            dx = pen.x - last.x;
            dy = pen.y - last.y;
            d = Math.hypot(dx, dy);
          }
          if (segT >= L - 1e-6) {
            seg++;
            segT = 0;
          }
        }
        aw.toWorld(pen, this.paint.target);
        if (this.brushHandle) this.brushHandle.setSpeed(speed);
        return seg >= pts.length - 1;
      });
      aw.stamp(pen.x, pen.y, st.radius, st.alpha, layer.hardness, layer.overspray, rng);
      this._stopSounds();
      this.paint.spraying = false;
      if (tool === 'brush' && Math.random() < 0.25) this.fx.flick(this.paint.target, layer.color, 5);
    }
  }

  // ----- ladder -----
  async fetchLadder() {
    const lx = this.ladderState.x;
    await this.walkTo(lx, LADDER.LIE_Z - 0.62);
    await this.turnTo(0);
    this.goal.crouch = 1.05;
    this.goal.lean = 0.4;
    const grabR = new V3(), grabL = new V3();
    this.goal.armR = this.goal.armL = 1;
    this.armROverride = (arm) => {
      this.ladderPoint(-LADDER.RAIL, LADDER.LEN / 2 + 0.28, grabR);
      arm.target.copy(grabR).add(_a.set(0, 0.06, 0));
      arm.aim.set(0, -0.6, 1).normalize();
      arm.up.set(0, 1, 0);
    };
    this.armLOverride = (arm) => {
      this.ladderPoint(-LADDER.RAIL, LADDER.LEN / 2 - 0.28, grabL);
      arm.target.copy(grabL).add(_a.set(0, 0.06, 0));
      arm.aim.set(0, -0.6, 1).normalize();
      arm.up.set(0, 1, 0);
    };
    await this.tasks.wait(0.5 / this.speedMul);
    const from = this.lyingPose(lx);
    this.ladderState.mode = 'moving';
    this.goal.crouch = 0;
    this.goal.lean = 0;
    await this.tasks.tween(0.9 / this.speedMul, (k) => {
      const to = this.carriedPose();
      this.ladder.position.lerpVectors(from.p, to.p, k);
      this.ladder.quaternion.slerpQuaternions(from.q, to.q, k);
    });
    this.ladderState.mode = 'carried';
    this.sound.ladderStep();
    this.armLOverride = null;
    this.goal.armL = 0;
    this.armROverride = (arm) => {
      this.ladderPoint(-LADDER.RAIL, LADDER.LEN / 2 + 0.6, arm.target);
      this.forward(arm.aim);
      arm.up.set(0, 1, 0);
    };
  }

  async placeLadder(x) {
    await this.walkTo(x - 0.75, 1.95);
    const from = this.carriedPose();
    const to = this.leaningPose(x);
    this.ladderState.mode = 'moving';
    this.armROverride = (arm) => {
      this.ladderPoint(-LADDER.RAIL, 2.0, arm.target);
      arm.aim.set(0, 0, -1);
      arm.up.set(0, 1, 0);
    };
    this.goal.armL = 1;
    this.armLOverride = (arm) => {
      this.ladderPoint(LADDER.RAIL, 1.5, arm.target);
      arm.aim.set(0, 0, -1);
      arm.up.set(0, 1, 0);
    };
    await this.tasks.tween(1.4 / this.speedMul, (k) => {
      this.ladder.position.lerpVectors(from.p, to.p, k);
      this.ladder.quaternion.slerpQuaternions(from.q, to.q, k);
      this.yaw += angleDiff(this.yaw, Math.PI * 0.75) * 0.08;
    });
    this.ladderState = { mode: 'leaning', x };
    this.sound.ladderPlace();
    this.fx.splash(new V3(x, 0.05, LADDER.BASE_Z), '#9b968e', 18);
    this.armROverride = this.armLOverride = null;
    this.goal.armR = this.goal.armL = 0;
    await this.tasks.wait(0.25);
  }

  climbHeightFor(feetY) {
    return feetY / Math.cos(LADDER.LEAN) / LADDER.SP - 1;
  }

  async mountLadder() {
    const x = this.ladderState.x;
    await this.walkTo(x, LADDER.BASE_Z + 0.32);
    await this.turnTo(Math.PI);
    this.climb = { c: -1, x };
  }

  async climbTo(c1, rate = 1.8) {
    if (!this.climb) return;
    const c0 = this.climb.c;
    const dir = Math.sign(c1 - c0);
    let lastRung = Math.floor(c0);
    await this.tasks.frame((dt) => {
      this.climb.c += dir * rate * this.speedMul * dt;
      if ((dir > 0 && this.climb.c >= c1) || (dir <= 0 && this.climb.c <= c1)) this.climb.c = c1;
      const r = Math.floor(this.climb.c);
      if (r !== lastRung) {
        lastRung = r;
        this.sound.ladderStep();
      }
      return this.climb.c === c1;
    });
  }

  async dismountLadder() {
    await this.climbTo(-1);
    const x = this.climb.x;
    this.climb = null;
    this.armROverride = this.armLOverride = null;
    this.goal.armR = this.goal.armL = 0;
    this.pos.set(x, 0, LADDER.BASE_Z + 0.32);
    this.yaw = Math.PI;
    this.sound.footstep(1);
    await this.tasks.wait(0.2);
  }

  async removeLadder() {
    const x = this.ladderState.x;
    await this.walkTo(x - 0.7, 2.0);
    await this.turnTo(Math.PI * 0.85);
    const from = this.leaningPose(x);
    const to = this.lyingPose(x);
    this.ladderState.mode = 'moving';
    this.goal.armR = this.goal.armL = 1;
    let hold = 1;
    this.armROverride = (arm) => {
      this.ladderPoint(-LADDER.RAIL, 1.7, _a);
      arm.target.lerpVectors(this.chestFront(_b), _a, hold);
      arm.aim.set(0, 0, -1);
      arm.up.set(0, 1, 0);
    };
    this.armLOverride = (arm) => {
      this.ladderPoint(LADDER.RAIL, 1.3, _a);
      arm.target.lerpVectors(this.chestFront(_b), _a, hold);
      arm.aim.set(0, 0, -1);
      arm.up.set(0, 1, 0);
    };
    await this.tasks.tween(1.3 / this.speedMul, (k) => {
      this.ladder.position.lerpVectors(from.p, to.p, k);
      this.ladder.quaternion.slerpQuaternions(from.q, to.q, k);
      hold = 1 - smooth(clamp((k - 0.45) / 0.4, 0, 1));
      if (k > 0.3) this.pos.z = damp(this.pos.z, 1.75, 3, 1 / 60);
    });
    this.ladderState = { mode: 'lying', x };
    this.sound.ladderPlace();
    this.armROverride = this.armLOverride = null;
    this.goal.armR = this.goal.armL = 0;
  }

  /** Steps up into the boom-lift basket and rides it. */
  async boardPlatform(obj, offset) {
    obj.updateMatrixWorld(true);
    const ground = obj.localToWorld(offset.clone().add(new V3(-1.0, 0, 0))).setY(0);
    await this.walkTo(ground.x, ground.z);
    this.platform = { obj, offset: offset.clone(), ground, enter: 0 };
    await this.tasks.tween(0.55 / this.speedMul, (k) => { this.platform.enter = k; });
    this.sound.ladderStep();
  }

  /** Steps down from the basket to the ground behind it. */
  async leavePlatform() {
    const p = this.platform;
    if (!p) return;
    p.obj.updateMatrixWorld(true);
    p.ground = p.obj.localToWorld(p.offset.clone().add(new V3(-1.0, 0, 0))).setY(0);
    await this.tasks.tween(0.55 / this.speedMul, (k) => { p.enter = 1 - k; });
    this.pos.copy(p.ground);
    this.platform = null;
    this.sound.footstep(1);
  }

  /** Throws a glowing paint bomb at a point on the wall; onHit runs when it splats. */
  async throwBomb(targetW, color, onHit) {
    const held = this.ch.held;
    if (held) held.visible = false;
    const pt = this.ch.gripWorld('R', new V3());
    this.goal.armR = 1;
    this.armROverride = (arm) => {
      arm.target.copy(pt);
      _c.subVectors(targetW, pt).normalize();
      arm.aim.copy(_c);
      arm.up.set(0, 1, 0);
    };
    const start = pt.clone();
    const back = this.chestFront(new V3(), -0.2, 1.75).addScaledVector(this.left(_a), -0.3);
    const fwd = this.chestFront(new V3(), 0.5, 1.65).addScaledVector(this.left(_a), -0.15);
    await this.tasks.tween(0.22 / this.speedMul, (k) => pt.lerpVectors(start, back, k));
    await this.tasks.tween(0.1 / this.speedMul, (k) => pt.lerpVectors(back, fwd, k), ease.linear);
    const ball = new THREE.Mesh(BOMB_GEO, new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.6, roughness: 0.3 }));
    ball.position.copy(this.ch.gripWorld('R', new V3()));
    ball.castShadow = true;
    this.scene.add(ball);
    const from = ball.position.clone();
    const flight = 0.45;
    this.tasks.tween(flight, (k) => {
      ball.position.lerpVectors(from, targetW, k);
      ball.position.y += Math.sin(k * Math.PI) * 0.7;
      ball.rotation.x += 0.4;
      ball.scale.setScalar(1 + k * 0.4);
    }, ease.linear).then(() => {
      this.scene.remove(ball);
      ball.material.dispose();
      this.sound.splat();
      this.fx.splash(_p2.copy(targetW).setZ(0.06), color, 60, true);
      if (onHit) onHit();
    });
    await this.tasks.tween(0.15, (k) => pt.lerpVectors(fwd, this.chestFront(_d), k));
    this.armROverride = null;
    this.goal.armR = 0;
    if (held) held.visible = true;
    return flight;
  }

  /** Moves the lying ladder somewhere new (only called while the screen is covered by a flash). */
  relocateLadder(cx) {
    this.ladderState = { mode: 'lying', x: cx };
    this.setLadderPose(this.lyingPose(cx));
  }

  /** Puts the artist back into a safe, neutral state after an error. */
  recover() {
    this._stopSounds();
    this.paint.active = false;
    this.paint.spraying = false;
    this.armROverride = this.armLOverride = null;
    this.goal = { crouch: 0, lean: 0, tiptoe: 0, armR: 0, armL: 0, sideMode: 0 };
    if (this.climb) {
      this.pos.set(this.climb.x, 0, LANE_Z);
      this.climb = null;
    }
    if (this.platform) {
      this.pos.copy(this.platform.ground);
      this.platform = null;
    }
    if (this.ladder && this.ladderState.mode !== 'lying' && this.ladderState.mode !== 'leaning') this.relocateLadder(this.pos.x - 4);
    this.pos.z = LANE_Z;
    this.ch.setTool(null);
    this.bucketHeld = Boolean(this.bucket);
  }
}

// ---------- event choreography ----------
export class Choreographer {
  constructor(ctx) {
    // ctx: { actor, wall, tasks, sound, fx, hud, rig, queue, net, useProxy }
    this.c = ctx;
    this.paintedCount = 0;
  }

  _speed() {
    // paint faster when the queue is long so busy LIVEs keep moving
    // the longer the queue, the faster everything runs (up to 4x) so nobody waits long
    const q = this.c.queue.size;
    return 1 + Math.min(3, q / 4);
  }

  async perform(job, opts = {}) {
    const { wall } = this.c;
    // several new viewers waiting: paint up to 4 names together in one welcome piece
    if (job.kind === 'join') {
      const more = this.c.queue.takeJoins(3);
      if (more.length) job = { ...job, kind: 'joins', users: [job.user, ...more.map((j) => j.user)] };
    }
    const m = measureArt(job);
    const layout = wall.allocate(job.kind, m.w);
    const avatarP = loadAvatar(job.user, this.c.useProxy);
    const seed = hashStr(job.user.id + ':' + job.id + ':' + Date.now());
    const speed = this._speed();
    this.c.actor.speedMul = speed;
    if (job.kind !== 'filler') this.c.hud.nowPainting(job);
    let aw;
    if (job.kind === 'legendary') aw = await this._legendary(job, m, layout, avatarP, seed, speed);
    else if (job.kind === 'special') aw = await this._special(job, m, layout, avatarP, seed, speed);
    else aw = await this._standard(job, m, layout, avatarP, seed, speed, opts);
    this.c.hud.clearNow();
    this.paintedCount++;
    this.c.net.saveArt({
      v: 1, kind: job.kind, word: job.word,
      users: job.users ? job.users.map((u) => ({ ...u, avatar: /^https?:/.test(u.avatar || '') ? u.avatar : '' })) : undefined,
      // generated (data:) pictures are re-created from the name, so only real URLs are stored
      user: { ...job.user, avatar: /^https?:/.test(job.user.avatar || '') ? job.user.avatar : '' }, count: job.count || 1, coins: job.coins || 0,
      x0: layout.x0, y0: layout.y0, seed, alloc: wall.allocSnapshot(),
    });
    // bake once the drips have finished running
    this._bakeWhenDry(aw);
  }

  _bakeWhenDry(aw) {
    let t = 0;
    this.c.tasks.frame((dt) => {
      t += dt;
      if (t < 1.5 || (aw.dripping && t < 12)) return false;
      this.c.wall.bake(aw);
      return true;
    });
  }

  async _paintLayers(aw, art, layers, speed, onLayer, shouldStop) {
    const actor = this.c.actor;
    for (const layer of layers) {
      if (onLayer) await onLayer(layer);
      if (actor.ch.heldName !== layer.tool && !actor.climb) {
        await actor.takeTool(layer.tool, layer.color);
        if (layer.tool === 'spray') await actor.shake();
      }
      actor.beginPaint(layer.tool, layer.color);
      const done = await actor.paintLayer(aw, layer, speed, shouldStop);
      actor.endPaint();
      if (done === false) return;
    }
  }

  async _finish(aw, art, extraFx) {
    const { tasks, fx } = this.c;
    await tasks.tween(0.35, (k) => aw.overlayFull(k * 0.5));
    aw.overlayFull(1);
    for (const e of art.extras) {
      if (e.type === 'drip') {
        aw.playExtra(e);
        continue;
      }
      tasks.wait(e.delay || 0).then(() => {
        aw.playExtra(e);
        if (e.type === 'splash') {
          const p = aw.toWorld({ x: e.X / 128, y: art.H - e.Y / 128 });
          p.z = 0.05;
          fx.splash(p, e.color, e.glow ? 30 : 16, e.glow);
        }
      });
    }
    if (extraFx) extraFx();
  }

  async _standard(job, m, layout, avatarP, seed, speed, opts = {}) {
    const { actor, wall, rig, sound, fx, hud } = this.c;
    const big = job.kind === 'big';
    const vip = job.kind === 'vip';
    if (job.kind === 'gift' || big || vip) {
      sound.pop();
      hud.giftCard(job);
    }
    rig.mode = big || vip ? 'wide' : 'follow';
    rig.focusOverride = null;
    const cx = layout.x0 + m.w / 2;
    const tool = 'spray'; // every piece is sprayed (names at full graffiti size)
    const standZ = tool === 'brush' ? 0.7 : 0.92;

    // walk straight along the wall to the next spot (no stepping back, no turning
    // to the camera), designing the piece while walking
    const walking = actor.walkTo(cx - 0.3, standZ + 0.15);
    const art = composeArt(job, m, await avatarP, seed);
    await walking;
    const aw = wall.createArtwork(art, layout);
    await actor.turnTo(Math.PI);
    if (big) {
      // 5-coin effect: three glowing paint bombs splat across the spot first
      for (let i = 0; i < 3; i++) {
        const p = aw.toWorld({ x: art.pad.l + (0.15 + Math.random() * 0.7) * art.core.w, y: art.pad.b + (0.3 + Math.random() * 0.6) * art.core.h });
        const col = NEON_BOMBS[(i + Math.floor(Math.random() * 5)) % NEON_BOMBS.length];
        await actor.throwBomb(p, col, () => aw.splatAt(p, col));
      }
      await this.c.tasks.wait(0.45);
    }
    await this._paintLayers(aw, art, art.layers, speed, null, opts.shouldStop);
    await this._finish(aw, art, () => {
      if (big) {
        const c = aw.toWorld({ x: art.W / 2, y: art.H * 0.6 });
        c.z = 0.2;
        fx.sparks(c, 70, art.color);
        fx.pulse(c.setZ(1.8), art.color, 45, 1.4);
        sound.golden();
      }
    });
    if (vip) await this._fireworks(cx, layout.y0 + art.core.h, [art.color, '#ffffff', '#ffd84d']);
    rig.mode = 'follow';
    return aw;
  }

  /** 20-coin effect: rockets launch from the pavement and burst above the piece. */
  async _fireworks(cx, topY, colors, wait = true) {
    const { tasks, fx, sound } = this.c;
    for (let i = 0; i < 3; i++) {
      const from = new V3(cx + (i - 1) * 1.3, 0.1, 1.8);
      const to = new V3(cx + (i - 1) * 1.7 + (Math.random() - 0.5), topY + 1.1 + Math.random() * 0.9, 1.0);
      const color = colors[i % colors.length];
      const pos = new V3();
      sound.whistle();
      tasks.tween(0.85, (k) => {
        pos.lerpVectors(from, to, k);
        fx.trail(pos);
      }, ease.out).then(() => {
        fx.sparks(to, 150, color, 1.3);
        fx.sparks(to, 40, '#ffffff', 0.7);
        fx.pulse(to, color, 60, 1.0);
        sound.bang();
      });
      await tasks.wait(0.2);
    }
    if (wait) await tasks.wait(0.5);
  }

  /** Drives a vehicle group from one x to another along the road, spinning its wheels. */
  _drive(group, fromX, toX, dur, wheels) {
    let last = fromX;
    group.position.x = fromX;
    return this.c.tasks.tween(dur, (k) => {
      const x = fromX + (toX - fromX) * k;
      group.position.x = x;
      wheels(x - last);
      last = x;
    }, ease.out);
  }

  /** 100 coins: a 4x4 and a boom lift roll in, two helpers spray from the basket. */
  async _legendary(job, m, layout, avatarP, seed, speed) {
    const { actor, wall, rig, sound, fx, tasks, vehicles, helpers } = this.c;
    const { truck, lift } = vehicles;
    const slotX = layout.x0 + m.w / 2;
    const TRUCK_Z = 6.5, LIFT_Z = 5.0;
    const FAST = 1.8; // whole legendary routine runs faster than base speed
    speed *= FAST;
    actor.speedMul = speed;

    // the crew from a previous legendary gift may still be driving away
    if (this._crewBusy) await this._crewBusy;

    sound.legendary();
    // keep the wide legendary camera until the vehicles have driven away
    rig.hold = { mode: 'legendary', focus: slotX };
    rig.mode = 'legendary';
    rig.focusOverride = slotX;
    const art = composeArt(job, m, await avatarP, seed);
    const aw = wall.createArtwork(art, layout);
    const [lPic, lName, lBanner] = art.layers;

    // the artist starts on the banner straight away, while the crew rolls in
    const artistPaint = (async () => {
      await actor.walkTo(layout.x0 + 0.3, 1.07);
      await actor.turnTo(Math.PI);
      await actor.takeTool('spray', lBanner.color);
      actor.beginPaint('spray', lBanner.color);
      await actor.paintLayer(aw, lBanner, speed);
      actor.endPaint();
    })();

    // the crew packs up and drives off as soon as the helpers finish; nobody waits for it
    const packUp = () => (async () => {
      lift.stow();
      const hyd = sound.hydraulic();
      await tasks.frame(() => !lift.moving);
      await Promise.all(helpers.map((h) => h.leavePlatform()));
      lift.faceWall(false);
      const exits = [new V3(slotX + 6.6, 0, TRUCK_Z - 1.55), new V3(slotX + 5.4, 0, TRUCK_Z - 1.55)];
      await Promise.all(helpers.map(async (h, i) => {
        await h.walkTo(exits[i].x - 0.6, 3.2);
        await h.walkTo(exits[i].x, exits[i].z);
        h.ch.root.visible = false;
      }));
      await tasks.frame(() => !lift.moving);
      hyd.stop();
      const doors = truck.userData.doors;
      sound.doorClunk();
      await tasks.tween(0.25, (k) => doors.forEach((d) => (d.rotation.y = -1.15 * (1 - k))));
      const engine = sound.engine();
      await Promise.all([
        this._drive(truck, truck.position.x, slotX + 50, 3.0, (dx) => spinWheels(truck, dx)),
        tasks.wait(0.4).then(() => this._drive(lift.group, lift.group.position.x, slotX + 46, 3.4, (dx) => lift.spinWheels(dx))),
      ]);
      engine.stop();
      truck.visible = lift.group.visible = false;
    })().catch((err) => console.error(err)).finally(() => {
      this._crewBusy = null;
      rig.hold = null; // vehicles gone: camera eases back to normal
    });

    const crewPaint = (async () => {
      truck.position.set(slotX - 30, 0, TRUCK_Z);
      lift.group.position.set(slotX - 36, 0, LIFT_Z);
      lift.faceWall(false);
      lift.yaw = 0;
      lift.stow();
      lift.tip.copy(lift.tipTarget);
      lift.speed = 3.4;
      lift.turnSpeed = 2.0;
      truck.visible = lift.group.visible = true;
      const engine = sound.engine();
      await Promise.all([
        this._drive(truck, slotX - 30, slotX + 5.6, 3.2, (dx) => spinWheels(truck, dx)),
        this._drive(lift.group, slotX - 36, slotX - 0.25, 3.8, (dx) => lift.spinWheels(dx)),
      ]);
      engine.stop();
      sound.horn();

      const doors = truck.userData.doors;
      sound.doorClunk();
      await tasks.tween(0.25, (k) => doors.forEach((d) => (d.rotation.y = -1.15 * k)));
      const exits = [new V3(slotX + 6.6, 0, TRUCK_Z - 1.55), new V3(slotX + 5.4, 0, TRUCK_Z - 1.55)];
      helpers.forEach((h, i) => {
        h.pos.copy(exits[i]);
        h.yaw = Math.PI;
        h.speedMul = speed;
        h.ch.setTool('spray');
        h.ch.setPaintColor(GOLD[1]);
        h.ch.root.visible = true;
      });
      lift.faceWall(true);
      const hyd = sound.hydraulic();
      const slots = [new V3(0.15, 0, -0.5), new V3(0.15, 0, 0.5)];
      await Promise.all(helpers.map(async (h, i) => {
        await h.walkTo(exits[i].x - 0.6, 3.2);
        await h.boardPlatform(lift.basket, slots[i]);
      }));
      await tasks.frame(() => !lift.moving);
      lift.setBasketWorld(new V3(slotX, layout.y0 + 2.05, 1.2));
      await tasks.frame(() => !lift.moving);
      hyd.stop();

      // both helpers spray at once: golden picture and name
      await Promise.all([[helpers[0], lPic], [helpers[1], lName]].map(async ([h, layer]) => {
        h.beginPaint('spray', layer.color);
        await h.paintLayer(aw, layer, speed);
        h.endPaint();
      }));

      // work done: pack up and drive away straight away
      this._crewBusy = packUp();
    })();

    await Promise.all([artistPaint, crewPaint]);

    // golden finale (effects run on their own; nobody waits for them)
    await this._finish(aw, art, () => {
      const c = aw.toWorld({ x: art.W / 2, y: art.H * 0.55 });
      fx.goldBurst(c.x, c.y, art.core.w, art.core.h);
      sound.golden();
    });
    this.c.hud.flash('gold');
    this._fireworks(slotX, layout.y0 + art.core.h, [GOLD[1], '#ffffff', '#ff2e88'], false);

    rig.focusOverride = null;
    rig.mode = 'follow';
    return aw;
  }

  async _special(job, m, layout, avatarP, seed, speed) {
    const { actor, wall, rig, sound, fx, hud, tasks } = this.c;
    const slotX = layout.x0 + m.w / 2;
    const FAST = 2.2; // ladder routine runs 2.2x faster than the base speed
    actor.speedMul = speed * FAST;
    speed *= FAST;

    // 1. fanfare, and the ladder is waiting just ahead (off camera, to the right)
    sound.announce();
    const ladderSpot = slotX + m.w / 2 + 2.6;
    if (Math.abs(actor.ladderState.x - ladderSpot) > 0.5 || actor.ladderState.mode !== 'lying') actor.relocateLadder(ladderSpot);

    // 2. bring the ladder
    rig.mode = 'wide';
    rig.focusOverride = null;
    const ladderX = actor.ladderState.x;
    await actor.walkTo(ladderX + 0.5, LANE_Z);
    await actor.turnTo(0);
    await actor.setDownBucket();
    const art = composeArt(job, m, await avatarP, seed);
    await actor.takeTool('spray', art.layers[0].color);
    await actor.fetchLadder();
    rig.mode = 'special';
    rig.focusOverride = slotX;
    await actor.placeLadder(slotX);

    // 3. climb and paint, top to bottom
    const aw = wall.createArtwork(art, layout);
    await actor.mountLadder();
    const heights = [5.75, 3.45, 2.2]; // world height of picture, name, banner
    for (let i = 0; i < art.layers.length; i++) {
      const layer = art.layers[i];
      const centerY = layout.y0 + (i === 0 ? 4.15 : i === 1 ? 1.85 : 0.6);
      const feet = Math.max(0.45, (heights[i] ?? centerY) - 1.5);
      await actor.climbTo(actor.climbHeightFor(feet));
      actor.beginPaint('spray', layer.color);
      await actor.paintLayer(aw, layer, speed);
      actor.endPaint();
    }
    await actor.dismountLadder();

    // 4. golden finale
    await actor.walkTo(slotX + 1.3, 2.4);
    await actor.turnTo(Math.PI * 0.9);
    actor.idleLookCamera = false;
    await this._finish(aw, art, () => {
      const c = aw.toWorld({ x: art.W / 2, y: art.H * 0.55 });
      fx.goldBurst(c.x, c.y, art.core.w, art.core.h);
      sound.golden();
    });
    hud.flash('gold');

    // 5. take the ladder down, collect the bucket, walk on
    await actor.removeLadder();
    rig.mode = 'wide';
    rig.focusOverride = null;
    await actor.walkTo(actor.bucket.position.x - 0.42, LANE_Z);
    await actor.turnTo(0);
    await actor.pickUpBucket();
    rig.mode = 'follow';
    return aw;
  }
}

export { GOLD };
