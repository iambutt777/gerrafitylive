// wall.js — the endless concrete wall and the street in front of it.
//
// The wall is built from 12 m panels created on demand as the artist moves
// right. Each panel has its own canvas texture (concrete + old graffiti).
// A piece being painted lives on its own small transparent "Artwork" plane so
// only a small texture is re-uploaded each frame. When the piece is finished
// it is baked permanently into the panel canvas and the plane is disposed.
// Panels far behind the camera are compressed and released from the GPU so
// memory stays flat during long LIVE sessions.

import * as THREE from 'three';
import { ART_PPU, NEON, INK, FONT_BLOCK, FONT_BRUSH, mulberry32, drawSplash, drawSparkle, drawDripSegment, drawDripEnd } from './art.js';

export const WALL_H = 9;
export const PANEL_W = 12;
export let PPU = ART_PPU; // wall texture pixels per metre (halved on phones)
const DEPTH = 0.6;
let LIVE_BEHIND = 48; // metres of wall kept on the GPU behind the focus point
const LIVE_AHEAD = 18;

/** Phones: half-resolution wall textures and less wall kept in memory behind the artist. */
export function setLowMemory(on) {
  if (!on) return;
  PPU = ART_PPU / 2;
  LIVE_BEHIND = 26;
}

// nothing is painted below the artist's shoulder height (~1.55 m)
export const ROW_Y0 = { upper: 1.95, lower: 1.55 };
/** Clear space (metres) left between neighbouring pieces. */
export const ART_GAP = 1.0;

export const KIND_Y0 = { gift: 1.55, big: 1.55, vip: 1.55, special: 1.6, legendary: 1.8, filler: 1.55, joins: 1.55 };

// ---------- shared procedural textures ----------
function noiseCanvas(size, lo, hi) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const d = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const v = lo + Math.random() * (hi - lo);
    d.data[i * 4] = d.data[i * 4 + 1] = d.data[i * 4 + 2] = v;
    d.data[i * 4 + 3] = 255;
  }
  g.putImageData(d, 0, 0);
  return c;
}

function concreteNormalMap(size = 256) {
  // tileable value noise → height → normals
  const h = new Float32Array(size * size);
  const octave = (cell, amp) => {
    const n = size / cell;
    const grid = new Float32Array(n * n).map(() => Math.random());
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const gx = x / cell, gy = y / cell;
        const x0 = Math.floor(gx), y0 = Math.floor(gy);
        const fx = gx - x0, fy = gy - y0;
        const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
        const v = (i, j) => grid[((j % n) * n) + (i % n)];
        const a = v(x0, y0) * (1 - sx) + v(x0 + 1, y0) * sx;
        const b = v(x0, y0 + 1) * (1 - sx) + v(x0 + 1, y0 + 1) * sx;
        h[y * size + x] += (a * (1 - sy) + b * sy) * amp;
      }
    }
  };
  octave(64, 1.0);
  octave(16, 0.5);
  octave(4, 0.35);
  octave(2, 0.25);
  for (let i = 0; i < 900; i++) {
    // pits / air bubbles typical of cast concrete
    const px = Math.floor(Math.random() * size), py = Math.floor(Math.random() * size);
    const r = 1 + Math.random() * 2.5;
    for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) {
      const d = Math.hypot(x, y);
      if (d < r) h[(((py + y + size) % size) * size) + ((px + x + size) % size)] -= (1 - d / r) * 0.9;
    }
  }
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const img = g.createImageData(size, size);
  const at = (x, y) => h[(((y + size) % size) * size) + ((x + size) % size)];
  const strength = 2.2;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = (at(x - 1, y) - at(x + 1, y)) * strength;
      const ny = (at(x, y + 1) - at(x, y - 1)) * strength;
      const nz = 1;
      const len = Math.hypot(nx, ny, nz);
      const i = (y * size + x) * 4;
      img.data[i] = ((nx / len) * 0.5 + 0.5) * 255;
      img.data[i + 1] = ((ny / len) * 0.5 + 0.5) * 255;
      img.data[i + 2] = ((nz / len) * 0.5 + 0.5) * 255;
      img.data[i + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  return c;
}

function sidewalkCanvas() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#77726b';
  g.fillRect(0, 0, 256, 256);
  g.globalAlpha = 0.35;
  g.globalCompositeOperation = 'overlay';
  g.drawImage(noiseCanvas(256, 40, 220), 0, 0);
  g.globalCompositeOperation = 'source-over';
  g.globalAlpha = 1;
  for (let i = 0; i < 12; i++) {
    g.fillStyle = `rgba(30,25,20,${0.04 + Math.random() * 0.06})`;
    g.beginPath();
    g.arc(Math.random() * 256, Math.random() * 256, 10 + Math.random() * 40, 0, Math.PI * 2);
    g.fill();
  }
  g.fillStyle = '#4b4741';
  g.fillRect(0, 0, 256, 4);
  g.fillRect(0, 0, 4, 256);
  g.fillStyle = 'rgba(255,255,255,0.12)';
  g.fillRect(0, 4, 256, 2);
  g.fillRect(4, 0, 2, 256);
  return c;
}

function asphaltCanvas() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#2b2a2f';
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i++) {
    const v = 30 + Math.random() * 70;
    g.fillStyle = `rgba(${v},${v},${v + 6},${0.5 + Math.random() * 0.5})`;
    g.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 2, 1 + Math.random() * 2);
  }
  g.strokeStyle = 'rgba(10,10,12,0.6)';
  g.lineWidth = 1.5;
  for (let i = 0; i < 4; i++) {
    g.beginPath();
    let x = Math.random() * 256, y = Math.random() * 256;
    g.moveTo(x, y);
    for (let k = 0; k < 6; k++) {
      x += (Math.random() - 0.5) * 40;
      y += (Math.random() - 0.5) * 40;
      g.lineTo(x, y);
    }
    g.stroke();
  }
  return c;
}

function windowsCanvases() {
  const base = document.createElement('canvas');
  const emis = document.createElement('canvas');
  base.width = emis.width = 64;
  base.height = emis.height = 128;
  const b = base.getContext('2d'), e = emis.getContext('2d');
  b.fillStyle = '#1d1b29';
  b.fillRect(0, 0, 64, 128);
  e.fillStyle = '#000';
  e.fillRect(0, 0, 64, 128);
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 4; x++) {
      const lit = Math.random() < 0.38;
      const col = Math.random() < 0.7 ? '#ffcf7a' : '#9fd0ff';
      b.fillStyle = lit ? col : '#2c2a3c';
      b.fillRect(x * 16 + 4, y * 16 + 4, 8, 9);
      if (lit) {
        e.fillStyle = col;
        e.fillRect(x * 16 + 4, y * 16 + 4, 8, 9);
      }
    }
  }
  return { base, emis };
}

function radialSprite(inner, outer) {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, inner);
  grd.addColorStop(1, outer);
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  return c;
}

const srgb = (tex) => {
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
};

// ---------- panel painting ----------
const OLD_WORDS = ['WAVE', 'LIVE', 'NEON', 'RUSH', 'VIBE', 'KING', 'HYPE', 'LOUD', 'GLOW', 'DRIP', 'CREW', 'ECHO', 'ZAP', 'FAM', 'BOOM', 'SKY'];
const OLD_TAGS = ['kaze', 'rx9', 'mono', 'jinx', 'oslo', 'tek', 'nova', 'ghost', 'vex', 'ryo', 'dime', 'lux'];

function paintConcrete(ctx, x0, rng, grainImg) {
  const w = ctx.canvas.width, h = ctx.canvas.height;
  const Y = (y) => (WALL_H - y) * ART_PPU;
  const X = (x) => (x - x0) * ART_PPU;
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#9b968e');
  g.addColorStop(0.55, '#8c877f');
  g.addColorStop(1, '#6f6a63');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  for (let i = 0; i < 42; i++) {
    const cx = rng() * w, cy = rng() * h, r = 60 + rng() * 240;
    const dark = rng() < 0.6;
    const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    rg.addColorStop(0, dark ? 'rgba(40,35,30,0.08)' : 'rgba(255,250,240,0.07)');
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = rg;
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  }
  ctx.save();
  ctx.globalCompositeOperation = 'overlay';
  ctx.globalAlpha = 0.45;
  ctx.fillStyle = ctx.createPattern(grainImg, 'repeat');
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
  for (let i = 0; i < 1800; i++) {
    ctx.fillStyle = rng() < 0.5 ? 'rgba(30,26,22,0.35)' : 'rgba(240,235,225,0.25)';
    ctx.fillRect(rng() * w, rng() * h, 1 + rng() * 2, 1 + rng() * 2);
  }

  // cast-concrete form seams, world-aligned every 2.4 m
  for (let k = Math.ceil(x0 / 2.4); k * 2.4 <= x0 + PANEL_W; k++) {
    const sx = X(k * 2.4);
    ctx.fillStyle = 'rgba(35,30,26,0.55)';
    ctx.fillRect(sx - 2, 0, 3, h);
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.fillRect(sx + 1, 0, 1.5, h);
  }
  for (const sy of [3, 6]) {
    ctx.fillStyle = 'rgba(35,30,26,0.5)';
    ctx.fillRect(0, Y(sy) - 2, w, 3);
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.fillRect(0, Y(sy) + 1, w, 1.5);
  }
  // form-tie holes
  for (let k = Math.floor(x0 / 2.4); k * 2.4 <= x0 + PANEL_W; k++) {
    for (const off of [0.6, 1.8]) {
      const hx = X(k * 2.4 + off);
      if (hx < -10 || hx > w + 10) continue;
      for (const hy of [0.75, 2.25, 3.75, 5.25, 6.75, 8.25]) {
        ctx.fillStyle = 'rgba(255,255,255,0.18)';
        ctx.beginPath();
        ctx.arc(hx + 1, Y(hy) + 1, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(28,24,20,0.75)';
        ctx.beginPath();
        ctx.arc(hx, Y(hy), 5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  // rain streaks
  for (let i = 0; i < 28; i++) {
    const sx = rng() * w;
    const from = rng() < 0.5 ? 0 : Y(6) + 2;
    const len = 60 + rng() * 380;
    const sg = ctx.createLinearGradient(0, from, 0, from + len);
    sg.addColorStop(0, `rgba(40,34,28,${0.12 + rng() * 0.12})`);
    sg.addColorStop(1, 'rgba(40,34,28,0)');
    ctx.fillStyle = sg;
    ctx.fillRect(sx, from, 4 + rng() * 22, len);
  }
  const grime = ctx.createLinearGradient(0, Y(0.7), 0, h);
  grime.addColorStop(0, 'rgba(25,20,16,0)');
  grime.addColorStop(1, 'rgba(25,20,16,0.45)');
  ctx.fillStyle = grime;
  ctx.fillRect(0, Y(0.7), w, h - Y(0.7));
}

function paintOldGraffiti(ctx, x0, rng) {
  const w = ctx.canvas.width;
  const Y = (y) => (WALL_H - y) * ART_PPU;
  // buffed-over patches (old graffiti painted out in a slightly different grey)
  for (let i = 0; i < 2; i++) {
    if (rng() < 0.35) continue;
    const bw = (1.4 + rng() * 2.4) * ART_PPU, bh = (1 + rng() * 2) * ART_PPU;
    ctx.fillStyle = rng() < 0.5 ? 'rgba(150,145,138,0.85)' : 'rgba(118,113,106,0.85)';
    ctx.fillRect(rng() * (w - bw), Y(4 + rng() * 4), bw, bh);
  }
  // throw-ups high on the wall, faded
  const pieces = 1 + Math.floor(rng() * 2);
  for (let i = 0; i < pieces; i++) {
    const word = OLD_WORDS[Math.floor(rng() * OLD_WORDS.length)];
    const px = 150 + rng() * 140;
    const cx = (0.12 + (i + rng() * 0.8) / pieces * 0.76) * w;
    const cy = Y(4.9 + rng() * 2.8);
    const c1 = NEON[Math.floor(rng() * NEON.length)];
    const c2 = NEON[Math.floor(rng() * NEON.length)];
    ctx.save();
    ctx.globalAlpha = 0.42 + rng() * 0.18;
    ctx.translate(cx, cy);
    ctx.rotate((rng() - 0.5) * 0.18);
    ctx.font = `${px}px ${FONT_BLOCK}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = px * 0.24;
    ctx.strokeStyle = '#f2efe8';
    ctx.strokeText(word, 0, 0);
    ctx.lineWidth = px * 0.11;
    ctx.strokeStyle = INK;
    ctx.strokeText(word, 0, 0);
    const g = ctx.createLinearGradient(0, -px / 2, 0, px / 2);
    g.addColorStop(0, c1);
    g.addColorStop(1, c2);
    ctx.fillStyle = g;
    ctx.fillText(word, 0, 0);
    ctx.restore();
    for (let d = 0; d < 4; d++) {
      const dx = cx + (rng() - 0.5) * px * word.length * 0.6;
      const dy = cy + px * 0.4;
      const drip = { X: dx, Y: dy, lenPx: 20 + rng() * 90, w: 3 + rng() * 4, color: c2 };
      ctx.globalAlpha = 0.45;
      drawDripSegment(ctx, drip, 0, drip.lenPx);
      drawDripEnd(ctx, drip);
      ctx.globalAlpha = 1;
    }
  }
  // tags
  const tags = 4 + Math.floor(rng() * 4);
  for (let i = 0; i < tags; i++) {
    ctx.save();
    ctx.globalAlpha = 0.35 + rng() * 0.25;
    ctx.translate(rng() * w, Y(rng() < 0.65 ? 4 + rng() * 4.6 : 0.35 + rng() * 0.4));
    ctx.rotate((rng() - 0.5) * 0.4);
    ctx.font = `${36 + rng() * 44}px ${FONT_BRUSH}`;
    ctx.fillStyle = rng() < 0.55 ? INK : NEON[Math.floor(rng() * NEON.length)];
    ctx.fillText(OLD_TAGS[Math.floor(rng() * OLD_TAGS.length)], 0, 0);
    ctx.restore();
  }
  // stencil stars
  for (let i = 0; i < 2; i++) {
    if (rng() < 0.5) continue;
    ctx.save();
    ctx.globalAlpha = 0.4;
    drawSparkle(ctx, rng() * w, Y(4.3 + rng() * 4), 20 + rng() * 30, NEON[Math.floor(rng() * NEON.length)]);
    ctx.restore();
  }
  for (let i = 0; i < 2; i++) {
    ctx.save();
    ctx.globalAlpha = 0.35;
    drawSplash(ctx, rng() * w, Y(4 + rng() * 4.5), 30 + rng() * 40, NEON[Math.floor(rng() * NEON.length)], rng, false);
    ctx.restore();
  }
}

// ---------- the artwork being painted ----------
const scratch = document.createElement('canvas');
const sctx = scratch.getContext('2d');
const gradCache = new Map();
function brushMask(d, hardness) {
  const key = d + ':' + hardness.toFixed(2);
  let g = gradCache.get(key);
  if (!g) {
    g = sctx.createRadialGradient(d / 2, d / 2, 0, d / 2, d / 2, d / 2);
    g.addColorStop(0, 'rgba(0,0,0,1)');
    g.addColorStop(Math.min(0.95, hardness), 'rgba(0,0,0,0.92)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    gradCache.set(key, g);
    if (gradCache.size > 400) gradCache.delete(gradCache.keys().next().value);
  }
  return g;
}

export class Artwork {
  constructor(wall, art, layout) {
    this.wall = wall;
    this.art = art;
    this.x0 = layout.x0 - art.pad.l;
    this.y0 = layout.y0 - art.pad.b;
    this.canvas = document.createElement('canvas');
    this.canvas.width = art.canvas.width;
    this.canvas.height = art.canvas.height;
    this.ctx = this.canvas.getContext('2d');
    this.tex = srgb(new THREE.CanvasTexture(this.canvas));
    this.tex.anisotropy = 4;
    this.mat = new THREE.MeshStandardMaterial({
      map: this.tex,
      transparent: true,
      depthWrite: false,
      roughness: art.gold ? 0.45 : 0.72,
      metalness: art.gold ? 0.2 : 0,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4,
      emissive: 0xffffff,
      emissiveMap: this.tex,
      emissiveIntensity: art.glow ? 0.22 : 0.06,
    });
    this.geo = new THREE.PlaneGeometry(art.W, art.H);
    this.mesh = new THREE.Mesh(this.geo, this.mat);
    this.mesh.position.set(this.x0 + art.W / 2, this.y0 + art.H / 2, 0.006);
    this.mesh.receiveShadow = true;
    this.mesh.renderOrder = 2;
    wall.scene.add(this.mesh);
    this.drips = [];
    this.dirty = false;
    this.disposed = false;
  }

  toWorld(p, out = new THREE.Vector3()) {
    return out.set(this.x0 + p.x, this.y0 + p.y, 0);
  }

  /** Reveals the finished artwork inside a soft round stamp. */
  stamp(x, y, r, alpha, hardness, overspray, rng = Math.random) {
    const H = this.art.H;
    const px = x * ART_PPU, py = (H - y) * ART_PPU;
    const d = Math.max(4, Math.ceil(r * ART_PPU * 2) + 2);
    if (scratch.width < d || scratch.height < d) {
      scratch.width = scratch.height = Math.max(d, 128);
      gradCache.clear();
    }
    sctx.globalCompositeOperation = 'source-over';
    sctx.clearRect(0, 0, d, d);
    sctx.drawImage(this.art.canvas, px - d / 2, py - d / 2, d, d, 0, 0, d, d);
    sctx.globalCompositeOperation = 'destination-in';
    sctx.fillStyle = brushMask(d, hardness);
    sctx.fillRect(0, 0, d, d);
    sctx.globalCompositeOperation = 'source-over';
    const ctx = this.ctx;
    ctx.globalAlpha = alpha;
    ctx.drawImage(scratch, 0, 0, d, d, px - d / 2, py - d / 2, d, d);
    if (overspray) {
      ctx.fillStyle = overspray;
      for (let i = 0; i < 6; i++) {
        const a = rng() * Math.PI * 2;
        const dist = (d / 2) * (0.8 + rng() * 1.5);
        ctx.globalAlpha = 0.18 + rng() * 0.25;
        ctx.fillRect(px + Math.cos(a) * dist, py + Math.sin(a) * dist, 0.8 + rng() * 1.6, 0.8 + rng() * 1.6);
      }
    }
    ctx.globalAlpha = 1;
    this.dirty = true;
  }

  /** A paint-bomb splat at a world position (drawn straight onto the piece). */
  splatAt(worldP, color) {
    const lx = worldP.x - this.x0, ly = worldP.y - this.y0;
    drawSplash(this.ctx, lx * ART_PPU, (this.art.H - ly) * ART_PPU, 0.42 * ART_PPU, color, Math.random, true);
    this.dirty = true;
  }

  /** Paints the full finished artwork at the given opacity (final clean-up pass). */
  overlayFull(alpha) {
    this.ctx.globalAlpha = alpha;
    this.ctx.drawImage(this.art.canvas, 0, 0);
    this.ctx.globalAlpha = 1;
    this.dirty = true;
  }

  playExtra(e) {
    if (e.type === 'drip') {
      this.drips.push({ ...e, cur: 0, speed: 50 + Math.random() * 70, done: false });
    } else if (e.type === 'splash') {
      drawSplash(this.ctx, e.X, e.Y, e.s, e.color, mulberry32(e.seed), e.glow);
      this.dirty = true;
    } else if (e.type === 'sparkle') {
      drawSparkle(this.ctx, e.X, e.Y, e.s, e.color);
      this.dirty = true;
    }
  }

  get dripping() {
    return this.drips.some((d) => !d.done);
  }

  update(dt) {
    for (const d of this.drips) {
      if (d.done) continue;
      if (d.delay > 0) {
        d.delay -= dt;
        continue;
      }
      const prev = d.cur;
      d.cur = Math.min(d.lenPx, d.cur + d.speed * dt * (1 - (d.cur / d.lenPx) * 0.7));
      drawDripSegment(this.ctx, d, prev, d.cur);
      if (d.cur >= d.lenPx - 0.75) {
        d.cur = d.lenPx;
        drawDripEnd(this.ctx, d);
        d.done = true;
      }
      this.dirty = true;
    }
    if (this.dirty) {
      this.tex.needsUpdate = true;
      this.dirty = false;
    }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.wall.scene.remove(this.mesh);
    this.geo.dispose();
    this.mat.dispose();
    this.tex.dispose();
    this.canvas.width = this.canvas.height = 1;
  }
}

// ---------- wall ----------
export class Wall {
  constructor(scene, renderer) {
    this.scene = scene;
    this.maxAniso = renderer.capabilities.getMaxAnisotropy();
    this.panels = new Map();
    this.artworks = new Set();
    this.glows = [];
    this.alloc = { row: [2, 2], block: 2, last: 1.4 };
    this.time = 0;
    this._buildShared();
  }

  _buildShared() {
    this.grain = noiseCanvas(256, 30, 225);
    const normal = new THREE.CanvasTexture(concreteNormalMap(256));
    normal.wrapS = normal.wrapT = THREE.RepeatWrapping;
    normal.repeat.set(PANEL_W / 2, WALL_H / 2);
    this.normalTex = normal;

    const walkTex = srgb(new THREE.CanvasTexture(sidewalkCanvas()));
    walkTex.wrapS = walkTex.wrapT = THREE.RepeatWrapping;
    walkTex.repeat.set(PANEL_W / 1.2, 3.4 / 1.2);
    walkTex.anisotropy = Math.min(8, this.maxAniso);
    const roadTex = srgb(new THREE.CanvasTexture(asphaltCanvas()));
    roadTex.wrapS = roadTex.wrapT = THREE.RepeatWrapping;
    roadTex.repeat.set(PANEL_W / 4, 22 / 4);
    roadTex.anisotropy = Math.min(8, this.maxAniso);
    const win = windowsCanvases();

    const M = (o) => new THREE.MeshStandardMaterial(o);
    this.mat = {
      side: M({ color: 0x8a857e, roughness: 0.95, normalMap: normal }),
      cap: M({ color: 0xa29d95, roughness: 0.9 }),
      walk: M({ map: walkTex, roughness: 0.95 }),
      curb: M({ color: 0x8f8a83, roughness: 0.9 }),
      road: M({ map: roadTex, roughness: 0.88 }),
      pole: M({ color: 0x2c2f36, roughness: 0.5, metalness: 0.6 }),
      lampHead: M({ color: 0x222222, emissive: 0xffd9a0, emissiveIntensity: 2.2 }),
      crate: M({ color: 0x1f6fe0, roughness: 0.7 }),
      canCap: M({ color: 0xeeeeee, roughness: 0.4 }),
      cans: NEON.map((c) => M({ color: c, roughness: 0.35, metalness: 0.4 })),
      bld: [8, 11, 15].map((rows) => {
        const map = srgb(new THREE.CanvasTexture(win.base));
        const emissiveMap = srgb(new THREE.CanvasTexture(win.emis));
        for (const t of [map, emissiveMap]) {
          t.wrapS = t.wrapT = THREE.RepeatWrapping;
          t.repeat.set(3, rows / 2);
        }
        return M({ map, emissiveMap, emissive: 0xffffff, emissiveIntensity: 0.9, roughness: 0.8 });
      }),
      lampGlow: new THREE.SpriteMaterial({
        map: new THREE.CanvasTexture(radialSprite('rgba(255,220,160,1)', 'rgba(255,170,90,0)')),
        blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
      }),
      pool: new THREE.MeshBasicMaterial({
        map: new THREE.CanvasTexture(radialSprite('rgba(255,190,120,0.55)', 'rgba(255,160,90,0)')),
        blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
      }),
    };
    this.geo = {
      wall: new THREE.BoxGeometry(PANEL_W, WALL_H, DEPTH),
      cap: new THREE.BoxGeometry(PANEL_W, 0.16, DEPTH + 0.12),
      walk: new THREE.PlaneGeometry(PANEL_W, 3.4).rotateX(-Math.PI / 2),
      curb: new THREE.BoxGeometry(PANEL_W, 0.22, 0.26),
      road: new THREE.PlaneGeometry(PANEL_W, 22).rotateX(-Math.PI / 2),
      bld: new THREE.BoxGeometry(1, 1, 1),
      pole: new THREE.CylinderGeometry(0.06, 0.08, 6.2, 10),
      arm: new THREE.BoxGeometry(0.08, 0.08, 1.3),
      lampHead: new THREE.BoxGeometry(0.32, 0.12, 0.55),
      can: new THREE.CylinderGeometry(0.033, 0.033, 0.17, 12),
      canCap: new THREE.CylinderGeometry(0.028, 0.03, 0.05, 12),
      crate: new THREE.BoxGeometry(0.42, 0.3, 0.32),
      pool: new THREE.PlaneGeometry(6, 6).rotateX(-Math.PI / 2),
    };
  }

  panelIndexAt(x) {
    return Math.floor(x / PANEL_W);
  }

  _createPanel(i) {
    const x0 = i * PANEL_W;
    const rng = mulberry32(i * 7919 + 1013);
    const canvas = document.createElement('canvas');
    canvas.width = PANEL_W * PPU;
    canvas.height = WALL_H * PPU;
    const ctx = canvas.getContext('2d');
    if (PPU === ART_PPU) {
      paintConcrete(ctx, x0, rng, this.grain);
      paintOldGraffiti(ctx, x0, rng);
    } else {
      if (!this.designCanvas) {
        this.designCanvas = document.createElement('canvas');
        this.designCanvas.width = PANEL_W * ART_PPU;
        this.designCanvas.height = WALL_H * ART_PPU;
      }
      const dctx = this.designCanvas.getContext('2d');
      paintConcrete(dctx, x0, rng, this.grain);
      paintOldGraffiti(dctx, x0, rng);
      ctx.drawImage(this.designCanvas, 0, 0, canvas.width, canvas.height);
    }
    const tex = srgb(new THREE.CanvasTexture(canvas));
    tex.anisotropy = Math.min(8, this.maxAniso);
    const front = new THREE.MeshStandardMaterial({
      map: tex, normalMap: this.normalTex, normalScale: new THREE.Vector2(0.8, 0.8), roughness: 0.92,
    });
    const group = new THREE.Group();
    const cx = x0 + PANEL_W / 2;

    const wall = new THREE.Mesh(this.geo.wall, [this.mat.side, this.mat.side, this.mat.cap, this.mat.side, front, this.mat.side]);
    wall.position.set(cx, WALL_H / 2, -DEPTH / 2);
    wall.receiveShadow = true;
    group.add(wall);
    const cap = new THREE.Mesh(this.geo.cap, this.mat.cap);
    cap.position.set(cx, WALL_H + 0.08, -DEPTH / 2);
    group.add(cap);

    const walk = new THREE.Mesh(this.geo.walk, this.mat.walk);
    walk.position.set(cx, 0, 1.7);
    walk.receiveShadow = true;
    group.add(walk);
    const curb = new THREE.Mesh(this.geo.curb, this.mat.curb);
    curb.position.set(cx, -0.09, 3.53);
    curb.receiveShadow = true;
    group.add(curb);
    const road = new THREE.Mesh(this.geo.road, this.mat.road);
    road.position.set(cx, -0.18, 3.66 + 11);
    road.receiveShadow = true;
    group.add(road);

    // skyline behind the wall
    for (let b = 0; b < 2; b++) {
      const which = Math.floor(rng() * 3);
      const hgt = [16, 22, 30][which];
      const bld = new THREE.Mesh(this.geo.bld, this.mat.bld[which]);
      bld.scale.set(6, hgt, 6);
      bld.position.set(x0 + 3 + b * 6 + (rng() - 0.5) * 1.5, hgt / 2 - 0.2, -9 - rng() * 8);
      group.add(bld);
    }

    // street lamp
    const lx = x0 + 3 + rng() * 2;
    const pole = new THREE.Mesh(this.geo.pole, this.mat.pole);
    pole.position.set(lx, 3.1, 3.3);
    pole.castShadow = true;
    group.add(pole);
    const arm = new THREE.Mesh(this.geo.arm, this.mat.pole);
    arm.position.set(lx, 6.15, 2.7);
    group.add(arm);
    const head = new THREE.Mesh(this.geo.lampHead, this.mat.lampHead);
    head.position.set(lx, 6.07, 2.15);
    group.add(head);
    const glow = new THREE.Sprite(this.mat.lampGlow);
    glow.position.set(lx, 5.95, 2.15);
    glow.scale.set(2.6, 2.6, 1);
    group.add(glow);
    const pool = new THREE.Mesh(this.geo.pool, this.mat.pool);
    pool.position.set(lx, 0.012, 1.9);
    group.add(pool);

    // dropped spray cans and a crate along the wall base
    const cans = 3 + Math.floor(rng() * 3);
    for (let k = 0; k < cans; k++) {
      const can = new THREE.Group();
      const body = new THREE.Mesh(this.geo.can, this.mat.cans[Math.floor(rng() * this.mat.cans.length)]);
      const top = new THREE.Mesh(this.geo.canCap, this.mat.canCap);
      top.position.y = 0.105;
      body.castShadow = top.castShadow = true;
      can.add(body, top);
      const lying = rng() < 0.45;
      can.position.set(x0 + rng() * PANEL_W, lying ? 0.033 : 0.085, 0.14 + rng() * 0.3);
      if (lying) can.rotation.set(0, rng() * Math.PI, Math.PI / 2);
      group.add(can);
    }
    if (rng() < 0.5) {
      const crate = new THREE.Mesh(this.geo.crate, this.mat.crate);
      crate.position.set(x0 + rng() * PANEL_W, 0.15, 0.3);
      crate.rotation.y = (rng() - 0.5) * 0.4;
      crate.castShadow = crate.receiveShadow = true;
      group.add(crate);
    }

    this.scene.add(group);
    const panel = { i, x0, canvas, ctx, tex, front, group, archived: false, glows: [] };
    this.panels.set(i, panel);
    return panel;
  }

  ensurePanel(i) {
    return this.panels.get(i) || this._createPanel(i);
  }

  _archive(p) {
    if (p.archived) return;
    p.archived = true;
    p.group.visible = false;
    for (const g of p.glows) g.visible = false;
    p.tex.dispose();
    for (const g of p.glows) g.material.map.dispose();
    // keep a compressed copy so the panel could be restored, then free the canvas
    if (p.canvas.toBlob) {
      p.canvas.toBlob((b) => {
        p.blob = b;
        p.canvas.width = p.canvas.height = 1;
      }, 'image/webp', 0.85);
    }
  }

  /** Reserves wall space for the next piece, always to the right of the last one. */
  allocate(kind, w) {
    // every piece gets its own stretch of wall with ART_GAP of bare concrete
    // between neighbours; names alternate high / low for a hand-made rhythm
    const a = this.alloc;
    const extra = kind === 'special' ? 0.6 : 0;
    const x = Math.max(a.row[0], a.row[1], a.block) + extra;
    const end = x + w + ART_GAP + extra;
    a.row = [end, end];
    a.block = end;
    a.last = x;
    if (kind === 'like' || kind === 'share' || kind === 'join') {
      a.high = !a.high;
      return { x0: x, y0: a.high ? ROW_Y0.upper : ROW_Y0.lower };
    }
    return { x0: x, y0: KIND_Y0[kind] };
  }

  allocSnapshot() {
    return { row: [...this.alloc.row], block: this.alloc.block, last: this.alloc.last };
  }

  restoreAlloc(s) {
    if (!s || !Array.isArray(s.row)) return;
    this.alloc = { row: [Number(s.row[0]) || 2, Number(s.row[1]) || 2], block: Number(s.block) || 2, last: Number(s.last) || 1.4 };
  }

  createArtwork(art, layout) {
    for (let i = this.panelIndexAt(layout.x0 - 1); i <= this.panelIndexAt(layout.x0 + art.W + 1); i++) this.ensurePanel(i);
    const aw = new Artwork(this, art, layout);
    this.artworks.add(aw);
    return aw;
  }

  /** Permanently paints a canvas into the wall panels it overlaps. */
  bakeCanvas(canvas, x0, y0, wMetres, hMetres, glow) {
    const top = y0 + hMetres;
    for (let i = this.panelIndexAt(x0); i <= this.panelIndexAt(x0 + wMetres); i++) {
      const p = this.ensurePanel(i);
      if (p.archived) continue;
      const k = PPU / ART_PPU;
      p.ctx.drawImage(canvas, (x0 - p.x0) * PPU, (WALL_H - top) * PPU, canvas.width * k, canvas.height * k);
      p.tex.needsUpdate = true;
    }
    if (glow) this._addGlow(canvas, x0, y0, wMetres, hMetres);
  }

  bake(aw) {
    if (aw.disposed) return;
    this.bakeCanvas(aw.canvas, aw.x0, aw.y0, aw.art.W, aw.art.H, aw.art.glow);
    this.artworks.delete(aw);
    aw.dispose();
  }

  _addGlow(src, x0, y0, w, h) {
    const scale = 1 / 6;
    const m = 12;
    const c = document.createElement('canvas');
    c.width = Math.ceil(src.width * scale) + m * 2;
    c.height = Math.ceil(src.height * scale) + m * 2;
    const g = c.getContext('2d');
    g.filter = 'blur(5px)';
    g.drawImage(src, m, m, src.width * scale, src.height * scale);
    g.filter = 'none';
    const tex = srgb(new THREE.CanvasTexture(c));
    const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.4 });
    const gw = w * (c.width / (src.width * scale)), gh = h * (c.height / (src.height * scale));
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(gw, gh), mat);
    mesh.position.set(x0 + w / 2, y0 + h / 2, 0.02);
    mesh.renderOrder = 3;
    mesh.userData.phase = Math.random() * 10;
    this.scene.add(mesh);
    const p = this.ensurePanel(this.panelIndexAt(x0 + w / 2));
    p.glows.push(mesh);
    this.glows.push(mesh);
  }

  update(dt, focusX) {
    this.time += dt;
    // create at most one off-screen panel per frame to avoid hitches
    const need = [];
    for (let i = this.panelIndexAt(focusX - LIVE_BEHIND); i <= this.panelIndexAt(focusX + LIVE_AHEAD); i++) {
      if (!this.panels.has(i)) need.push(i);
    }
    if (need.length) {
      need.sort((a, b) => Math.abs(a * PANEL_W - focusX) - Math.abs(b * PANEL_W - focusX));
      this._createPanel(need[0]);
    }
    for (const p of this.panels.values()) {
      if (!p.archived && p.x0 + PANEL_W < focusX - LIVE_BEHIND - PANEL_W) {
        this._archive(p);
        break;
      }
    }
    for (const aw of this.artworks) aw.update(dt);
    for (const g of this.glows) {
      if (g.visible) g.material.opacity = 0.32 + Math.sin(this.time * 1.7 + g.userData.phase) * 0.1;
    }
  }
}
