// vehicles.js — the legendary-gift crew vehicles.
//   buildPickup()  a rugged 4x4 double-cab pickup (original design, no badges)
//   BoomLift       an articulating boom lift: orange chassis, cream booms,
//                  orange basket. The basket is placed with 2-link IK so it
//                  can be sent to any point in front of the wall.
// Both vehicles face +X locally (their driving direction).

import * as THREE from 'three';

const std = (color, roughness = 0.6, metalness = 0, extra = {}) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });

function addBox(parent, w, h, d, mat, x, y, z) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function addCyl(parent, rTop, rBot, h, mat, x, y, z, seg = 14) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, h, seg), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  parent.add(m);
  return m;
}

function makeWheel(r, w, tire, hub) {
  const g = new THREE.Group();
  const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 26).rotateX(Math.PI / 2), tire);
  t.castShadow = true;
  g.add(t);
  // chunky tread blocks so the rolling is visible
  for (let i = 0; i < 16; i++) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(r * 0.22, 0.05, w * 0.9), tire);
    const a = (i / 16) * Math.PI * 2;
    b.position.set(Math.cos(a) * r, Math.sin(a) * r, 0);
    b.rotation.z = a + Math.PI / 2;
    g.add(b);
  }
  const h = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.56, r * 0.56, w * 1.04, 14).rotateX(Math.PI / 2), hub);
  g.add(h);
  for (let i = 0; i < 5; i++) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(r * 0.95, r * 0.1, w * 1.08), tire);
    s.rotation.z = (i / 5) * Math.PI;
    g.add(s);
  }
  g.userData.r = r;
  return g;
}

/** Rugged 4x4 double-cab pickup. Doors on the -Z side open toward the wall. */
export function buildPickup() {
  const g = new THREE.Group();
  const body = std(0xf0efea, 0.32, 0.35);
  const trim = std(0x1d1e22, 0.6, 0.2);
  const glass = std(0x0e1216, 0.08, 0.85);
  const chrome = std(0xcfd3d8, 0.25, 0.9);
  const head = std(0xffffff, 0.3, 0, { emissive: 0xfff3d6, emissiveIntensity: 2.2 });
  const tail = std(0x550000, 0.4, 0, { emissive: 0xff2020, emissiveIntensity: 1.4 });
  const amber = std(0x553300, 0.4, 0, { emissive: 0xffa21f, emissiveIntensity: 2 });

  addBox(g, 4.9, 0.25, 1.5, trim, 0, 0.62, 0);
  addBox(g, 2.4, 0.7, 1.86, body, 0.35, 1.05, 0);
  addBox(g, 2.1, 0.62, 1.7, body, 0.25, 1.71, 0);
  addBox(g, 1.95, 0.45, 1.72, glass, 0.25, 1.72, 0);
  const ws = addBox(g, 0.06, 0.62, 1.62, glass, 1.33, 1.68, 0);
  ws.rotation.z = 0.42;
  addBox(g, 1.35, 0.55, 1.86, body, 2.2, 1.02, 0);
  addBox(g, 0.06, 0.4, 1.4, trim, 2.88, 0.98, 0);
  for (const z of [-0.66, 0.66]) addBox(g, 0.05, 0.14, 0.32, head, 2.9, 1.12, z);
  // bull bar
  addBox(g, 0.08, 0.55, 1.75, trim, 3.02, 0.85, 0);
  addBox(g, 0.3, 0.07, 1.75, trim, 2.9, 1.12, 0);
  // bed
  addBox(g, 1.95, 0.12, 1.86, trim, -1.9, 0.95, 0);
  for (const z of [-0.89, 0.89]) addBox(g, 1.95, 0.5, 0.08, body, -1.9, 1.22, z);
  addBox(g, 0.08, 0.5, 1.86, body, -2.86, 1.22, 0);
  for (const z of [-0.72, 0.72]) addBox(g, 0.05, 0.22, 0.2, tail, -2.9, 1.25, z);
  addBox(g, 0.08, 0.5, 1.8, chrome, -1.05, 1.55, 0); // headache rack
  // roof light bar and snorkel
  addBox(g, 0.3, 0.1, 1.45, trim, 0.55, 2.08, 0);
  addBox(g, 0.06, 0.07, 1.3, amber, 0.71, 2.08, 0);
  addCyl(g, 0.05, 0.05, 1.0, trim, 1.6, 1.55, 0.95, 10);
  // fender flares
  for (const x of [1.75, -1.55]) for (const z of [-0.9, 0.9]) addBox(g, 1.15, 0.12, 0.14, trim, x, 0.98, z);
  // side steps
  for (const z of [-0.98, 0.98]) addBox(g, 2.3, 0.06, 0.2, chrome, 0.35, 0.5, z);

  const tire = std(0x151515, 0.95);
  const hub = std(0x3b3f45, 0.4, 0.7);
  const wheels = [];
  for (const x of [1.75, -1.55]) {
    for (const z of [-0.86, 0.86]) {
      const w = makeWheel(0.45, 0.34, tire, hub);
      w.position.set(x, 0.45, z);
      g.add(w);
      wheels.push(w);
    }
  }
  // doors on the wall side, hinged at their front edge
  const doors = [];
  for (const hx of [1.3, 0.12]) {
    const pivot = new THREE.Group();
    pivot.position.set(hx, 1.05, -0.95);
    const panel = addBox(pivot, 1.12, 1.25, 0.05, body, -0.56, 0.32, 0);
    panel.castShadow = true;
    addBox(pivot, 0.95, 0.42, 0.06, glass, -0.56, 0.67, 0);
    addBox(pivot, 0.16, 0.04, 0.07, chrome, -0.95, 0.25, -0.01);
    g.add(pivot);
    doors.push(pivot);
  }
  g.userData = { wheels, doors };
  return g;
}

/** Articulating boom lift with a level basket. */
export class BoomLift {
  constructor() {
    const g = (this.group = new THREE.Group());
    const orange = std(0xf26a1b, 0.5, 0.1);
    const cream = std(0xe6d9ad, 0.55, 0.05);
    const dark = std(0x24272c, 0.6, 0.3);
    const steel = std(0xb8bcc4, 0.35, 0.8);
    this.mats = { orange, cream, dark };

    // chassis, counterweight and wheels
    addBox(g, 3.0, 0.72, 1.85, orange, 0, 0.88, 0);
    addBox(g, 3.1, 0.18, 1.95, dark, 0, 0.5, 0);
    addBox(g, 1.15, 0.8, 1.75, orange, -1.0, 1.5, 0).scale.set(1, 1, 1);
    addCyl(g, 0.42, 0.42, 1.75, orange, -1.55, 1.48, 0, 20).rotation.x = Math.PI / 2;
    addBox(g, 0.5, 0.35, 0.5, dark, 1.2, 1.4, 0.55);
    const tire = std(0x151515, 0.95);
    const hub = std(0xf2f2f2, 0.5, 0.2);
    this.wheels = [];
    for (const x of [1.05, -1.05]) {
      for (const z of [-0.98, 0.98]) {
        const w = makeWheel(0.52, 0.4, tire, hub);
        w.position.set(x, 0.52, z);
        g.add(w);
        this.wheels.push(w);
      }
    }

    // turntable with the boom pivot
    this.turntable = new THREE.Group();
    this.turntable.position.set(0.25, 1.25, 0);
    g.add(this.turntable);
    addCyl(this.turntable, 0.75, 0.8, 0.15, dark, 0, 0.07, 0, 24);
    addBox(this.turntable, 1.3, 0.55, 1.0, orange, 0.1, 0.4, 0);
    this.P = new THREE.Vector3(-0.25, 0.75, 0);
    this.L1 = 3.3;
    this.L2 = 4.5;
    this.B = new THREE.Vector3(0.6, -0.55, 0); // basket floor centre relative to the boom tip

    this.lower = new THREE.Group();
    this.lower.position.copy(this.P);
    this.turntable.add(this.lower);
    addBox(this.lower, this.L1, 0.34, 0.36, cream, this.L1 / 2, 0, 0);
    addCyl(this.lower, 0.06, 0.06, this.L1 * 0.7, steel, this.L1 * 0.4, 0.26, 0, 10).rotation.z = Math.PI / 2;

    this.upper = new THREE.Group();
    this.turntable.add(this.upper);
    addBox(this.upper, this.L2 * 0.62, 0.32, 0.32, cream, this.L2 * 0.31, 0, 0);
    addBox(this.upper, this.L2 * 0.45, 0.24, 0.24, orange, this.L2 * 0.76, 0, 0);
    addBox(this.upper, 0.9, 0.1, 0.1, dark, this.L2 * 0.3, -0.21, 0);

    this.jib = new THREE.Group();
    this.turntable.add(this.jib);
    addBox(this.jib, 0.5, 0.2, 0.2, orange, 0.2, -0.2, 0);
    addCyl(this.jib, 0.12, 0.12, 0.3, dark, 0, 0, 0, 12).rotation.x = Math.PI / 2;

    // basket (origin = floor centre)
    this.basket = new THREE.Group();
    this.turntable.add(this.basket);
    addBox(this.basket, 1.05, 0.08, 2.1, orange, 0, 0, 0);
    addBox(this.basket, 1.05, 0.15, 2.1, orange, 0, 0.1, 0).scale.set(1, 1, 1);
    for (const x of [-0.5, 0.5]) for (const z of [-1.02, 1.02]) addBox(this.basket, 0.05, 1.1, 0.05, orange, x, 0.55, z);
    for (const y of [0.55, 1.1]) {
      for (const z of [-1.02, 1.02]) addBox(this.basket, 1.05, 0.05, 0.05, orange, 0, y, z);
      for (const x of [-0.5, 0.5]) addBox(this.basket, 0.05, 0.05, 2.1, orange, x, y, 0);
    }
    addBox(this.basket, 0.25, 0.3, 0.45, dark, -0.4, 0.95, 0.6);

    this.tip = new THREE.Vector2(2.5, -0.95);
    this.tipTarget = this.tip.clone();
    this.yaw = 0;
    this.yawTarget = 0;
    this.moving = false;
    this.speed = 1.6; // metres per second at the boom tip
    this.turnSpeed = 0.9; // turret, radians per second
    this.group.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    this._apply();
  }

  _apply() {
    const { L1, L2, P, B } = this;
    let u = this.tip.x, v = this.tip.y;
    let d = Math.hypot(u, v);
    const dc = THREE.MathUtils.clamp(d, Math.abs(L1 - L2) + 0.05, L1 + L2 - 0.05);
    if (d > 1e-6 && dc !== d) {
      u *= dc / d;
      v *= dc / d;
      d = dc;
    }
    const a = Math.acos(THREE.MathUtils.clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1));
    const t1 = Math.atan2(v, u) + a; // elbow up, like a real articulating boom
    const ex = L1 * Math.cos(t1), ey = L1 * Math.sin(t1);
    const t2 = Math.atan2(v - ey, u - ex);
    this.lower.rotation.z = t1;
    this.upper.position.set(P.x + ex, P.y + ey, 0);
    this.upper.rotation.z = t2;
    this.jib.position.set(P.x + u, P.y + v, 0);
    this.basket.position.set(P.x + u + B.x, P.y + v + B.y, 0);
    this.turntable.rotation.y = this.yaw;
  }

  /** Folded with the basket just above the ground in front of the turret. */
  stow() {
    this.tipTarget.set(2.5, -0.95);
  }

  /** Sends the basket floor centre to a world position (using the target turret angle). */
  setBasketWorld(floorW) {
    const saved = this.turntable.rotation.y;
    this.turntable.rotation.y = this.yawTarget;
    this.group.updateMatrixWorld(true);
    const l = this.turntable.worldToLocal(floorW.clone());
    this.turntable.rotation.y = saved;
    this.tipTarget.set(l.x - this.B.x - this.P.x, l.y - this.B.y - this.P.y);
  }

  faceWall(on) {
    this.yawTarget = on ? Math.PI / 2 : 0;
  }

  spinWheels(dx) {
    for (const w of this.wheels) w.rotation.z -= dx / w.userData.r;
  }

  update(dt) {
    const step = this.speed * dt;
    const dist = this.tip.distanceTo(this.tipTarget);
    if (dist > 1e-4) this.tip.lerp(this.tipTarget, Math.min(1, step / dist));
    const dy = this.yawTarget - this.yaw;
    if (Math.abs(dy) > 1e-4) this.yaw += Math.sign(dy) * Math.min(Math.abs(dy), this.turnSpeed * dt);
    this.moving = dist > 0.01 || Math.abs(dy) > 0.01;
    this._apply();
  }
}

export function spinWheels(group, dx) {
  for (const w of group.userData.wheels || []) w.rotation.z -= dx / w.userData.r;
}
