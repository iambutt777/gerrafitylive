// character.js — the 3D graffiti artist.
// A fully articulated figure (hips, spine, chest, neck, head, shoulders,
// elbows, wrists, hips, knees, ankles) driven procedurally: a walk cycle for
// locomotion plus two-bone IK so hands land exactly on the wall / ladder rails
// and feet stay planted on the ground or on ladder rungs.

import * as THREE from 'three';

export const DIM = { hip: 0.91, thigh: 0.43, shin: 0.42, ankle: 0.06, upper: 0.3, fore: 0.27, grip: 0.07 };

const clamp = THREE.MathUtils.clamp;
const damp = THREE.MathUtils.damp;
const ID_Q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _bm = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();
const _q3 = new THREE.Quaternion();
const _v = Array.from({ length: 8 }, () => new THREE.Vector3());
const _b1 = new THREE.Vector3(), _b2 = new THREE.Vector3(), _b3 = new THREE.Vector3();
const _fw = new THREE.Vector3(), _up = new THREE.Vector3(), _ft = new THREE.Vector3(), _pl = new THREE.Vector3(), _lk = new THREE.Vector3();

/** Rotation whose -Y points along `dir` and whose +Z leans toward `pole`. */
function boneQuat(dir, pole, out) {
  _b1.copy(dir).negate();
  _b2.copy(pole).addScaledVector(_b1, -pole.dot(_b1));
  if (_b2.lengthSq() < 1e-8) {
    _b2.set(0, 0, 1).addScaledVector(_b1, -_b1.z);
    if (_b2.lengthSq() < 1e-8) _b2.set(1, 0, 0);
  }
  _b2.normalize();
  _b3.crossVectors(_b1, _b2);
  _bm.makeBasis(_b3, _b1, _b2);
  return out.setFromRotationMatrix(_bm);
}

/**
 * Analytic two-bone IK. `upper` and `lower` are joint pivots whose bones point
 * down their local -Y. Blends from the current (FK) pose by `weight`.
 */
export function solveTwoBone(upper, lower, L1, L2, targetW, poleW, weight) {
  if (weight < 0.001) return;
  const parent = upper.parent;
  parent.updateWorldMatrix(true, false);
  _m.copy(parent.matrixWorld).invert();
  const t = _v[0].copy(targetW).applyMatrix4(_m);
  parent.getWorldQuaternion(_q).invert();
  const pole = _v[1].copy(poleW).applyQuaternion(_q);
  const dir = _v[2].subVectors(t, upper.position);
  let dist = dir.length();
  if (dist < 1e-5) return;
  dir.divideScalar(dist);
  dist = clamp(dist, Math.abs(L1 - L2) + 0.02, (L1 + L2) * 0.999);
  pole.addScaledVector(dir, -pole.dot(dir));
  if (pole.lengthSq() < 1e-8) pole.set(0, 0, 1);
  pole.normalize();
  const a = Math.acos(clamp((L1 * L1 + dist * dist - L2 * L2) / (2 * L1 * dist), -1, 1));
  const axis = _v[3].crossVectors(dir, pole).normalize();
  const upperDir = _v[4].copy(dir).applyAxisAngle(axis, a);
  const elbow = _v[5].copy(upper.position).addScaledVector(upperDir, L1);
  const fore = _v[6].copy(upper.position).addScaledVector(dir, dist).sub(elbow).normalize();
  boneQuat(upperDir, pole, _q2);
  boneQuat(fore, pole, _q3);
  const qLower = _q.copy(_q2).invert().multiply(_q3);
  upper.quaternion.slerp(_q2, weight);
  lower.quaternion.slerp(qLower, weight);
}

/** Rotates `node` so a child holder (with local rotation holderQ) aims +Z along aimW with +Y toward upW. */
export function orientTo(node, holderQ, aimW, upW, weight) {
  if (weight < 0.001) return;
  const z = _v[0].copy(aimW).normalize();
  const x = _v[1].crossVectors(upW, z);
  if (x.lengthSq() < 1e-6) x.set(1, 0, 0);
  x.normalize();
  const y = _v[2].crossVectors(z, x);
  _bm.makeBasis(x, y, z);
  _q.setFromRotationMatrix(_bm);
  _q2.copy(holderQ).invert();
  _q.multiply(_q2);
  node.parent.getWorldQuaternion(_q3).invert();
  _q3.multiply(_q);
  node.quaternion.slerp(_q3, weight);
}

const std = (color, roughness = 0.8, metalness = 0, extra = {}) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });

function addMesh(parent, geo, mat, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function addGroup(parent, x = 0, y = 0, z = 0) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  parent.add(g);
  return g;
}

const capsule = (r, l) => new THREE.CapsuleGeometry(r, l, 4, 12);

// ---------- tools ----------
function buildSprayGun() {
  const g = new THREE.Group();
  const dark = std(0x1d1f24, 0.5, 0.4);
  const metal = std(0xc4c8cf, 0.3, 0.85);
  const paint = std(0xff2e88, 0.35, 0.1);
  const grip = addMesh(g, new THREE.BoxGeometry(0.032, 0.105, 0.042), dark, 0, -0.045, -0.005);
  grip.rotation.x = 0.25;
  const body = addMesh(g, new THREE.CylinderGeometry(0.022, 0.026, 0.17, 14), metal, 0, 0.018, 0.06);
  body.rotation.x = Math.PI / 2;
  addMesh(g, new THREE.CylinderGeometry(0.042, 0.036, 0.11, 16), paint, 0, -0.058, 0.105);
  addMesh(g, new THREE.CylinderGeometry(0.044, 0.044, 0.012, 16), metal, 0, -0.002, 0.105);
  addMesh(g, new THREE.CylinderGeometry(0.008, 0.008, 0.05, 8), metal, 0, -0.025, 0.105);
  const nozzle = addMesh(g, new THREE.CylinderGeometry(0.006, 0.013, 0.035, 10), dark, 0, 0.018, 0.163);
  nozzle.rotation.x = Math.PI / 2;
  addMesh(g, new THREE.BoxGeometry(0.008, 0.04, 0.012), dark, 0, -0.012, 0.03);
  g.userData.tip = new THREE.Vector3(0, 0.018, 0.182);
  g.userData.paintMats = [paint];
  return g;
}

function buildBrush() {
  const g = new THREE.Group();
  const wood = std(0x9b6a3c, 0.6);
  const metal = std(0xc4c8cf, 0.3, 0.85);
  const bristle = std(0x2a2420, 0.9);
  const paint = std(0xff2e88, 0.35);
  const handle = addMesh(g, new THREE.CylinderGeometry(0.011, 0.014, 0.23, 10), wood, 0, 0, 0.075);
  handle.rotation.x = Math.PI / 2;
  const ferrule = addMesh(g, new THREE.CylinderGeometry(0.017, 0.016, 0.045, 12), metal, 0, 0, 0.21);
  ferrule.rotation.x = Math.PI / 2;
  addMesh(g, new THREE.BoxGeometry(0.042, 0.015, 0.06), bristle, 0, 0, 0.255);
  addMesh(g, new THREE.BoxGeometry(0.044, 0.017, 0.03), paint, 0, 0, 0.283);
  g.userData.tip = new THREE.Vector3(0, 0, 0.298);
  g.userData.paintMats = [paint];
  return g;
}

export function buildBucket() {
  const g = new THREE.Group();
  const plastic = std(0xe8e4dc, 0.6, 0, { side: THREE.DoubleSide });
  const paint = std(0xff2e88, 0.3);
  addMesh(g, new THREE.CylinderGeometry(0.15, 0.125, 0.27, 20, 1, true), plastic, 0, 0.135, 0);
  addMesh(g, new THREE.CircleGeometry(0.125, 20).rotateX(-Math.PI / 2), plastic, 0, 0.004, 0);
  addMesh(g, new THREE.CylinderGeometry(0.142, 0.142, 0.01, 20), paint, 0, 0.225, 0);
  const handle = addMesh(g, new THREE.TorusGeometry(0.15, 0.007, 6, 20, Math.PI), std(0x555a60, 0.4, 0.8), 0, 0.27, 0);
  handle.castShadow = false;
  const canMats = [std(0x19e3ff, 0.35, 0.4), std(0xb6ff3b, 0.35, 0.4)];
  for (let i = 0; i < 2; i++) {
    const can = addMesh(g, new THREE.CylinderGeometry(0.033, 0.033, 0.18, 12), canMats[i], i ? -0.05 : 0.05, 0.27, i ? -0.03 : 0.03);
    can.rotation.z = i ? 0.18 : -0.15;
  }
  // a few paint drips down the side
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.4;
    const drip = addMesh(g, new THREE.BoxGeometry(0.02, 0.06 + i * 0.02, 0.004), paint, Math.cos(a) * 0.148, 0.24 - i * 0.012, Math.sin(a) * 0.148);
    drip.lookAt(0, drip.position.y, 0);
  }
  g.userData.paintMats = [paint];
  g.userData.handleTop = 0.42;
  return g;
}

export const LADDER = { LEN: 7.4, LEAN: Math.asin(1.3 / 7.4), SP: 0.3, RUNGS: 23, BASE_Z: 1.3, RAIL: 0.21, LIE_Z: 3.05 };

export function buildLadder() {
  const g = new THREE.Group();
  const alu = std(0xc9ccd1, 0.35, 0.75);
  const rubber = std(0x1a1a1a, 0.9);
  for (const x of [-LADDER.RAIL, LADDER.RAIL]) {
    addMesh(g, new THREE.BoxGeometry(0.045, LADDER.LEN, 0.075), alu, x, LADDER.LEN / 2, 0);
    addMesh(g, new THREE.BoxGeometry(0.06, 0.06, 0.09), rubber, x, 0.03, 0);
  }
  const rung = new THREE.CylinderGeometry(0.018, 0.018, LADDER.RAIL * 2, 10).rotateZ(Math.PI / 2);
  for (let k = 0; k < LADDER.RUNGS; k++) addMesh(g, rung, alu, 0, (k + 1) * LADDER.SP, 0);
  return g;
}

// ---------- the artist ----------
export class Character {
  constructor() {
    this.root = new THREE.Group();
    this.root.name = 'artist';
    this.root.rotation.order = 'YXZ';
    const M = (this.mats = {
      skin: std(0xb67a58, 0.6),
      hoodie: std(0x26232f, 0.92),
      trim: std(0xff2e88, 0.55, 0, { emissive: 0xff2e88, emissiveIntensity: 0.15 }),
      jeans: std(0x2f3f5c, 0.88),
      shoe: std(0xf2f2f0, 0.55),
      sole: std(0x19e3ff, 0.5),
      glove: std(0x18181c, 0.7),
      cap: std(0xffc93c, 0.7),
      mask: std(0x2c2f35, 0.45, 0.25),
      filter: std(0xff2e88, 0.5),
      eye: std(0x0e0e10, 0.25),
      string: std(0xf0f0f0, 0.6),
    });
    const j = (this.j = {});
    const R = this.root;

    j.hips = addGroup(R, 0, DIM.hip, 0);
    const pelvis = addMesh(j.hips, capsule(0.13, 0.13), M.jeans, 0, 0.01, 0);
    pelvis.rotation.z = Math.PI / 2;
    pelvis.scale.set(1, 1, 0.82);
    addMesh(j.hips, new THREE.TorusGeometry(0.14, 0.012, 6, 24).rotateX(Math.PI / 2), M.glove, 0, 0.06, 0).scale.set(1.05, 1, 0.85);

    j.spine = addGroup(j.hips, 0, 0.08, 0);
    addMesh(j.spine, capsule(0.135, 0.12), M.hoodie, 0, 0.1, 0).scale.set(1.1, 1, 0.85);
    j.chest = addGroup(j.spine, 0, 0.17, 0);
    addMesh(j.chest, capsule(0.16, 0.2), M.hoodie, 0, 0.17, 0).scale.set(1.22, 1, 0.82);
    addMesh(j.chest, new THREE.SphereGeometry(0.12, 14, 10), M.hoodie, 0, 0.38, -0.08).scale.set(1.45, 0.7, 1);
    addMesh(j.chest, new THREE.BoxGeometry(0.2, 0.04, 0.01), M.trim, 0, 0.22, 0.137);
    addMesh(j.chest, new THREE.BoxGeometry(0.2, 0.012, 0.01), M.trim, 0, 0.17, 0.137);
    for (const sx of [-0.04, 0.04]) addMesh(j.chest, new THREE.CylinderGeometry(0.006, 0.006, 0.14, 6), M.string, sx, 0.27, 0.13);
    addMesh(j.chest, new THREE.BoxGeometry(0.26, 0.09, 0.02), M.hoodie, 0, 0.04, 0.13);

    j.neck = addGroup(j.chest, 0, 0.4, 0);
    addMesh(j.neck, new THREE.CylinderGeometry(0.05, 0.056, 0.1, 10), M.skin, 0, 0.03, 0);
    j.head = addGroup(j.neck, 0, 0.08, 0);
    addMesh(j.head, new THREE.SphereGeometry(0.115, 20, 16), M.skin, 0, 0.1, 0).scale.set(0.93, 1.06, 1);
    addMesh(j.head, new THREE.SphereGeometry(0.123, 18, 10, 0, Math.PI * 2, 0, Math.PI / 2), M.cap, 0, 0.125, -0.005).scale.set(1, 0.86, 1.05);
    const brim = addMesh(j.head, new THREE.BoxGeometry(0.2, 0.014, 0.13), M.cap, 0, 0.135, -0.165);
    brim.rotation.x = -0.12;
    addMesh(j.head, new THREE.SphereGeometry(0.014, 8, 6), M.cap, 0, 0.23, 0);
    addMesh(j.head, new THREE.SphereGeometry(0.068, 14, 10), M.mask, 0, 0.05, 0.095).scale.set(1.2, 0.85, 0.85);
    for (const sx of [-1, 1]) {
      const f = addMesh(j.head, new THREE.CylinderGeometry(0.036, 0.036, 0.04, 14), M.mask, sx * 0.072, 0.035, 0.11);
      f.rotation.set(Math.PI / 2, 0, sx * 0.6);
      f.rotation.order = 'ZXY';
      const ring = addMesh(j.head, new THREE.TorusGeometry(0.03, 0.006, 6, 16), M.filter, sx * 0.084, 0.035, 0.125);
      ring.rotation.y = sx * 0.6;
      addMesh(j.head, new THREE.SphereGeometry(0.016, 8, 6), M.eye, sx * 0.04, 0.125, 0.1);
      addMesh(j.head, new THREE.SphereGeometry(0.028, 8, 6), M.skin, sx * 0.11, 0.1, 0).scale.set(0.6, 1, 0.9);
    }

    for (const [side, sx] of [['L', 1], ['R', -1]]) {
      const sh = (j['sh' + side] = addGroup(j.chest, sx * 0.205, 0.33, 0));
      addMesh(sh, new THREE.SphereGeometry(0.07, 12, 10), M.hoodie);
      addMesh(sh, capsule(0.058, 0.2), M.hoodie, 0, -0.15, 0);
      const el = (j['el' + side] = addGroup(sh, 0, -DIM.upper, 0));
      addMesh(el, capsule(0.05, 0.18), M.hoodie, 0, -0.13, 0);
      addMesh(el, new THREE.CylinderGeometry(0.053, 0.053, 0.035, 12), M.trim, 0, -0.245, 0);
      const hand = (j['hand' + side] = addGroup(el, 0, -DIM.fore, 0));
      addMesh(hand, new THREE.BoxGeometry(0.075, 0.095, 0.04), M.glove, 0, -0.05, 0);
      addMesh(hand, new THREE.BoxGeometry(0.022, 0.05, 0.022), M.glove, -sx * 0.042, -0.04, 0.02);
      const mount = (j['mount' + side] = addGroup(hand, 0, -DIM.grip, 0));
      mount.rotation.x = Math.PI / 2;

      const thigh = (j['thigh' + side] = addGroup(j.hips, sx * 0.1, 0, 0));
      addMesh(thigh, capsule(0.08, 0.27), M.jeans, 0, -0.215, 0);
      const knee = (j['knee' + side] = addGroup(thigh, 0, -DIM.thigh, 0));
      addMesh(knee, capsule(0.065, 0.29), M.jeans, 0, -0.21, 0);
      const foot = (j['foot' + side] = addGroup(knee, 0, -DIM.shin, 0));
      addMesh(foot, new THREE.BoxGeometry(0.105, 0.07, 0.27), M.shoe, 0, -0.015, 0.05);
      addMesh(foot, new THREE.BoxGeometry(0.112, 0.022, 0.285), M.sole, 0, -0.049, 0.05);
      addMesh(foot, new THREE.BoxGeometry(0.06, 0.012, 0.1), M.trim, 0, 0.022, 0.09);
    }
    this.mountQ = j.mountR.quaternion.clone();

    this.tools = { spray: buildSprayGun(), brush: buildBrush() };
    this.held = null;
    this.heldName = null;
    this._t = 0;
    this._look = { yaw: 0, pitch: 0 };
  }

  /** Changes clothing colours, e.g. hi-vis outfits for the legendary helpers. */
  recolor({ hoodie, cap, trim, jeans, sole } = {}) {
    if (hoodie != null) this.mats.hoodie.color.set(hoodie);
    if (cap != null) this.mats.cap.color.set(cap);
    if (trim != null) {
      this.mats.trim.color.set(trim);
      this.mats.trim.emissive.set(trim);
    }
    if (jeans != null) this.mats.jeans.color.set(jeans);
    if (sole != null) this.mats.sole.color.set(sole);
  }

  setTool(name) {
    if (this.held) this.j.mountR.remove(this.held);
    this.held = name ? this.tools[name] : null;
    this.heldName = name || null;
    if (this.held) this.j.mountR.add(this.held);
  }

  setPaintColor(hex) {
    for (const t of Object.values(this.tools)) for (const m of t.userData.paintMats) m.color.set(hex);
  }

  toolTipWorld(out) {
    if (!this.held) return this.j.handR.getWorldPosition(out);
    return out.copy(this.held.userData.tip).applyMatrix4(this.held.matrixWorld);
  }

  gripWorld(side, out) {
    return this.j['mount' + side].getWorldPosition(out);
  }

  /** Applies locomotion (FK), then IK for legs and arms, then the head look. */
  applyPose(s, dt) {
    const j = this.j;
    const wb = s.walkBlend, ph = s.walkPhase, sm = s.sideMode || 0;
    this._t += dt;
    const breathe = Math.sin(this._t * 2.1);
    const bob = (Math.cos(2 * ph) * 0.5 + 0.5) * 0.03 * wb;

    j.hips.position.y = DIM.hip + bob - s.crouch * 0.42 + s.tiptoe * 0.06 + breathe * 0.004;
    j.hips.rotation.set(0, Math.sin(ph) * 0.1 * wb * (1 - sm), 0);
    j.spine.rotation.set(s.lean + s.crouch * 0.3 + 0.04 * wb, 0, 0);
    j.chest.rotation.set(breathe * 0.015, -Math.sin(ph) * 0.12 * wb * (1 - sm), 0);

    for (const [side, off, sx] of [['L', 0, 1], ['R', Math.PI, -1]]) {
      const p = ph + off;
      j['thigh' + side].rotation.set(-Math.sin(p) * 0.5 * wb * (1 - sm), 0, Math.sin(p) * 0.16 * wb * sm * sx + sx * 0.03);
      j['knee' + side].rotation.set((Math.max(0, Math.cos(p)) * 0.95 + 0.06) * wb, 0, 0);
      j['foot' + side].rotation.set(Math.sin(p) * 0.2 * wb * (1 - sm), 0, 0);
    }

    const swing = 0.42 * wb * (1 - sm);
    j.shL.rotation.set(Math.sin(ph) * swing - 0.05 + breathe * 0.01, 0, s.holdBucket ? 0.2 : 0.1);
    j.elL.rotation.set(s.holdBucket ? -0.05 : -0.25 - 0.25 * wb, 0, 0);
    j.shR.rotation.set(-Math.sin(ph) * swing - 0.05 + breathe * 0.01, 0, -0.1);
    j.elR.rotation.set(-0.25 - 0.25 * wb, 0, 0);
    j.handL.quaternion.identity();
    j.handR.quaternion.identity();

    this.root.updateMatrixWorld(true);
    const rq = this.root.quaternion;
    _fw.set(0, 0, 1).applyQuaternion(rq);
    _up.set(0, 1, 0).applyQuaternion(rq);

    if (s.legW > 0.001) {
      for (const [side, sx] of [['L', 1], ['R', -1]]) {
        const tgt = s['foot' + side] || this.root.localToWorld(_ft.set(0.11 * sx, DIM.ankle, 0.02));
        _pl.set(sx * 0.15, 0.1, 1).applyQuaternion(rq);
        solveTwoBone(j['thigh' + side], j['knee' + side], DIM.thigh, DIM.shin, tgt, _pl, s.legW);
        j['knee' + side].updateMatrixWorld(true);
        orientTo(j['foot' + side], ID_Q, _fw, _up, s.legW);
      }
    }

    for (const [side, sx] of [['R', -1], ['L', 1]]) {
      const arm = side === 'R' ? s.armR : s.armL;
      if (arm.w < 0.001) continue;
      _pl.set(sx * 0.6, -1, -0.45).applyQuaternion(rq);
      solveTwoBone(j['sh' + side], j['el' + side], DIM.upper, DIM.fore, arm.target, _pl, arm.w);
      j['el' + side].updateMatrixWorld(true);
      orientTo(j['hand' + side], this.mountQ, arm.aim, arm.up, arm.w);
    }

    let yaw = 0, pitch = 0;
    if (s.look) {
      j.chest.updateMatrixWorld(true);
      const lp = j.chest.worldToLocal(_lk.copy(s.look)).sub(j.neck.position);
      yaw = clamp(Math.atan2(lp.x, lp.z), -1.1, 1.1);
      pitch = clamp(-Math.atan2(lp.y - 0.12, Math.hypot(lp.x, lp.z)), -0.7, 0.6);
    }
    this._look.yaw = damp(this._look.yaw, yaw, 6, dt);
    this._look.pitch = damp(this._look.pitch, pitch, 6, dt);
    j.neck.rotation.set(this._look.pitch * 0.4, this._look.yaw * 0.45, 0);
    j.head.rotation.set(this._look.pitch * 0.6, this._look.yaw * 0.55, 0);
  }
}
