// game.js — boots the 3D scene and runs the director loop.
//
// URL options:
//   ?clean=1   hide the control panel and sound prompt (use this in OBS / LIVE Studio)
//   ?hud=0     hide the whole overlay
//   ?demo=1    start the auto demo
//   ?q=low     lighter rendering (automatic on phones; use ?q=high to force full quality)
//   ?filler=0  stand still when idle instead of spraying street-art words
//   ?debug=1   show an FPS counter

import * as THREE from 'three';
import { Character, buildBucket, buildLadder } from './character.js';
import { Wall, setLowMemory } from './wall.js';
import { buildPickup, BoomLift } from './vehicles.js';
import { Effects } from './effects.js';
import { Sound } from './audio.js';
import { EventQueue } from './queue.js';
import { Hud } from './hud.js';
import { createNet, Simulator } from './net.js';
import { Tasks, Actor, Choreographer, LANE_Z } from './animations.js';
import { measureArt, composeArt, finalCanvas, loadAvatar, setNameMode } from './art.js';

const params = new URLSearchParams(location.search);
const CLEAN = params.get('clean') === '1';
const MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const LOW = params.get('q') === 'low' || (MOBILE && params.get('q') !== 'high');

// Words the artist sprays between viewers so the stream never stands still.
// Edit freely. Up to 40 characters; longer phrases are drawn a bit smaller to fit.
const FILLER_WORDS = [
  'GIFT FLOWER FOR PROFILE',
  'LIKE FOR YOUR NAME',
  'SHARE FOR YOUR NAME',
  'BIG GIFT = BIG ART',
];
const FILLER = params.get('filler') !== '0' && FILLER_WORDS.length > 0;
const DEBUG = params.get('debug') === '1';
const USE_PROXY = !window.__noSocket && typeof window.io === 'function';

const stage = document.getElementById('stage');
const canvas = document.getElementById('scene');
const hudRoot = document.getElementById('hud');
const bootEl = document.getElementById('boot');
if (params.get('hud') === '0') hudRoot.style.display = 'none';

async function loadFonts() {
  if (!document.fonts) return;
  const fonts = ['64px "Permanent Marker"', '64px "Bungee"', '600 20px "Barlow Condensed"'];
  await Promise.race([
    Promise.all(fonts.map((f) => document.fonts.load(f).catch(() => null))),
    new Promise((r) => setTimeout(r, 4000)),
  ]);
}

function skyTexture() {
  const c = document.createElement('canvas');
  c.width = 4;
  c.height = 512;
  const g = c.getContext('2d');
  const grd = g.createLinearGradient(0, 0, 0, 512);
  grd.addColorStop(0, '#120f2b');
  grd.addColorStop(0.45, '#3a2a5e');
  grd.addColorStop(0.75, '#8a4a78');
  grd.addColorStop(1, '#e88a5e');
  g.fillStyle = grd;
  g.fillRect(0, 0, 4, 512);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

class CameraRig {
  constructor(camera) {
    this.camera = camera;
    this.pos = new THREE.Vector3(6, 3, 9);
    this.look = new THREE.Vector3(0, 2, 0);
    this.mode = 'follow';
    this.focusX = 1;
    this.focusOverride = null;
    // while set, overrides every job's camera: { mode, focus } (used while the legendary crew is on site)
    this.hold = null;
    this.t = 0;
    this._p = new THREE.Vector3();
    this._l = new THREE.Vector3();
  }

  snap(x) {
    this.focusX = x;
    this.update(10, x);
  }

  update(dt, actorX) {
    this.t += dt;
    // the camera is always centred on the artist (the zoom level still changes per routine)
    const target = actorX;
    const mode = this.hold ? this.hold.mode : this.mode;
    this.focusX = THREE.MathUtils.damp(this.focusX, target, 1.7, dt);
    const f = this.focusX;
    const p = this._p, l = this._l;
    // the camera sits front-right and looks back along the wall, so earlier
    // artwork recedes into the distance on the left
    switch (mode) {
      case 'wide': p.set(f + 5.2, 3.3, 10.6); l.set(f - 0.9, 2.3, 0); break;
      case 'special': p.set(f + 6.6, 4.8, 14.8); l.set(f - 0.5, 4.3, 0); break;
      case 'announce': p.set(f + 2.1, 1.85, 4.4); l.set(f - 0.1, 1.6, 0.9); break;
      case 'legendary': p.set(f + 9.5, 5.4, 20); l.set(f - 0.6, 4.2, 1.5); break;
      default: p.set(f + 4.3, 2.85, 8.9); l.set(f - 0.8, 2.0, 0);
    }
    p.x += Math.sin(this.t * 0.21) * 0.25;
    p.y += Math.sin(this.t * 0.17) * 0.12;
    l.y += Math.sin(this.t * 0.13) * 0.05;
    const k = 1 - Math.exp(-dt * 1.8);
    this.pos.lerp(p, k);
    this.look.lerp(l, k);
    this.camera.position.copy(this.pos);
    this.camera.lookAt(this.look);
  }
}

async function main() {
  await loadFonts();

  // ----- renderer & scene -----
  setLowMemory(LOW);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !LOW, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = !LOW;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = skyTexture();
  scene.fog = new THREE.Fog(0x3d2f57, 26, 72);
  const camera = new THREE.PerspectiveCamera(50, 9 / 16, 0.1, 200);

  scene.add(new THREE.HemisphereLight(0x95a2ff, 0x3a2a24, 0.95));
  const key = new THREE.DirectionalLight(0xffb37a, 2.3);
  key.castShadow = !LOW;
  key.shadow.mapSize.set(MOBILE ? 1024 : 2048, MOBILE ? 1024 : 2048);
  Object.assign(key.shadow.camera, { left: -8, right: 8, top: 9, bottom: -3, near: 0.5, far: 45 });
  key.shadow.bias = -0.0004;
  key.shadow.normalBias = 0.02;
  scene.add(key, key.target);
  const work = new THREE.SpotLight(0xe9f1ff, 70, 20, 0.6, 0.55, 2);
  scene.add(work, work.target);

  // ----- systems -----
  const tasks = new Tasks();
  const sound = new Sound();
  const readLocal = (k, d) => {
    try { const v = localStorage.getItem(k); return v == null ? d : v; } catch { return d; }
  };
  const writeLocal = (k, v) => {
    try { localStorage.setItem(k, String(v)); } catch { /* private mode */ }
  };
  let effectsVolume = Number(readLocal('gw-fx-volume', '0.8'));
  let tabSound = readLocal('gw-tab-sound', '1') === '1';
  // painting + walking speed (0.25x - 3x), set in the control panel and shared with OBS
  const clampSpeed = (v) => (Number.isFinite(v) ? Math.max(0.25, Math.min(3, v)) : 1);
  let gameSpeed = clampSpeed(Number(readLocal('gw-speed', '1')));
  // the OBS source (clean mode) always plays effects; other tabs can be muted
  const applyVolume = () => sound.setVolume(CLEAN || tabSound ? effectsVolume : 0);
  applyVolume();
  const fx = new Effects(scene);
  const wall = new Wall(scene, renderer);
  const character = new Character();
  const bucket = buildBucket();
  const ladder = buildLadder();
  scene.add(bucket, ladder);
  const actor = new Actor({ character, tasks, sound, fx, scene, ladder, bucket, camera });

  // legendary crew: two helpers in hi-vis, a 4x4 pickup and a boom lift
  const helpers = [
    { hoodie: '#f2c400', cap: '#ffffff', trim: '#ff6a00', jeans: '#2b3a55', sole: '#ff6a00' },
    { hoodie: '#ff7a00', cap: '#f2c400', trim: '#d4ff3b', jeans: '#343434', sole: '#f2c400' },
  ].map((colors) => {
    const ch = new Character();
    ch.recolor(colors);
    const h = new Actor({ character: ch, tasks, sound, fx, scene, ladder: null, bucket: null, camera });
    ch.root.visible = false;
    return h;
  });
  const truck = buildPickup();
  const lift = new BoomLift();
  truck.visible = false;
  lift.group.visible = false;
  scene.add(truck, lift.group);
  const vehicles = { truck, lift };
  const rig = new CameraRig(camera);
  const queue = new EventQueue();
  const hud = new Hud(hudRoot, { useProxy: USE_PROXY, clean: CLEAN });
  // test events go through the server (so OBS sees them too); offline they stay local
  let sendEvent = (e) => queue.ingest(e);
  const sim = new Simulator((e) => sendEvent(e));
  const localBoard = new Map();
  const localGift = (e) => {
    if (e.type !== 'gift') return;
    const id = e.user.id || e.user.handle;
    const entry = localBoard.get(id) || { user: e.user, coins: 0 };
    entry.coins += e.coins;
    localBoard.set(id, entry);
    hud.setTopGifters([...localBoard.values()].sort((a, b) => b.coins - a.coins).slice(0, 3));
  };

  // wall options (shared with every screen through the server)
  let options = { nameMode: 'handle', joins: true, likePopups: false, likeEvery: 1 };
  try { options = { ...options, ...JSON.parse(localStorage.getItem('gw-options2') || '{}') }; } catch { /* defaults */ }
  const applyOptions = (o) => {
    options = { ...options, ...o };
    setNameMode(options.nameMode);
    queue.setOptions({
      joins: options.joins !== false,
      likePopups: Boolean(options.likePopups),
      likeEvery: Number(options.likeEvery) || 1,
    });
    hud.setOptions(options);
    try { localStorage.setItem('gw-options2', JSON.stringify(options)); } catch { /* private mode */ }
  };

  queue.onChange((q) => hud.setQueue(q.upcoming(5), q.size));
  queue.onPopup((p) => hud.popup(p));
  hud.setQueue([], 0);
  hud.loadLocalLayout();
  try { hud.setLists(JSON.parse(localStorage.getItem('gw-lists') || '{}')); } catch { hud.setLists({}); }

  // viewer count decides whether likes are painted or shown as popups
  let realViewers = null;
  let simViewers = null; // null = use the real count
  const applyViewers = () => {
    const n = simViewers ?? realViewers;
    queue.setViewerCount(n);
    const label = n == null ? 'auto' : String(n);
    hud.setViewersLabel(`Viewers: ${label}${queue.likesAsPopups ? ' (likes as popups)' : ''}`);
  };

  // ----- history restore (server keeps the wall across refreshes) -----
  let resolveHistory;
  const historyReady = new Promise((r) => (resolveHistory = r));
  async function restoreHistory(records) {
    try {
      if (!records.length) return;
      const last = records[records.length - 1];
      wall.restoreAlloc(last.alloc);
      const keepFrom = last.x0 - 46;
      const recent = records.filter((r) => r.x0 >= keepFrom);
      const avatars = await Promise.all(recent.map((r) => loadAvatar(r.user, USE_PROXY)));
      recent.forEach((r, i) => {
        const job = { kind: r.kind, word: r.word, user: r.user, users: r.users, count: r.count || 1, coins: r.coins || 0 };
        const m = measureArt(job);
        const art = composeArt(job, m, avatars[i], r.seed >>> 0);
        wall.bakeCanvas(finalCanvas(art), r.x0 - art.pad.l, r.y0 - art.pad.b, art.W, art.H, art.glow);
      });
      actor.pos.x = last.x0 + 1.5;
      actor.relocateLadder(actor.pos.x - 8);
      rig.snap(actor.pos.x);
    } catch (err) {
      console.error('Could not restore the wall', err);
    } finally {
      resolveHistory();
    }
  }

  const statusLabel = (s) => {
    if (s.state === 'connected') return [`LIVE: @${s.username}`, 'live'];
    if (s.state === 'connecting') return [`Connecting to @${s.username}…`, 'wait'];
    if (s.state === 'error' || (s.state === 'disconnected' && s.username)) return ['Reconnecting to TikTok…', 'wait'];
    if (s.state === 'ended') return ['LIVE ended', 'off'];
    if (s.state === 'server-offline') return ['Server offline', 'off'];
    return ['Simulator', 'sim'];
  };

  // admin password (only needed when the server was started with ADMIN_PASSWORD, e.g. online)
  const urlKey = params.get('key') || '';
  let adminKey = urlKey || readLocal('gw-key', '');
  const net = createNet({
    clean: CLEAN,
    key: adminKey,
    onAuth: (a) => {
      if (!a.required) return;
      if (a.admin) {
        if (adminKey && !urlKey) writeLocal('gw-key', adminKey);
        return;
      }
      writeLocal('gw-key', '');
      if (CLEAN) return; // OBS source: add &key=YOUR_PASSWORD to its address
      setTimeout(() => {
        const k = window.prompt(a.wrong ? 'Wrong password. Admin password:' : 'Admin password (Cancel to only watch):');
        if (k) { adminKey = k.trim(); net.login(adminKey); }
        else hud.setConnectMessage('Viewing only. Reload the page and enter the admin password to use the controls.', 'error');
      }, 50);
    },
    onLive: (e) => {
      queue.ingest(e);
      hud.noteEvent(e);
    },
    onStatus: (s) => {
      const [text, tone] = statusLabel(s);
      hud.setStatus(text, tone);
      hud.setPanelStatus(text, tone);
      if ('hasKey' in s) hud.setHasKey(s.hasKey);
      if (s.error && s.state !== 'connected') hud.setConnectMessage(s.error, 'error');
      else if (s.state === 'connected') hud.setConnectMessage(`Connected to @${s.username}`, 'ok');
    },
    onHistory: (records, cleared) => {
      if (cleared) location.reload();
      else restoreHistory(records);
    },
    onViewers: (n) => {
      realViewers = n;
      applyViewers();
    },
    onLayout: (layout) => hud.applyLayout(layout),
    onLeaderboard: (list) => hud.setTopGifters(list),
    onPrefs: (p) => {
      const o = {};
      if (p.nameMode) o.nameMode = p.nameMode;
      if (typeof p.joins === 'boolean') o.joins = p.joins;
      if (typeof p.likePopups === 'boolean') o.likePopups = p.likePopups;
      if (Number.isFinite(p.likeEvery)) o.likeEvery = p.likeEvery;
      if (Object.keys(o).length) applyOptions(o);
      if (Number.isFinite(p.speed)) {
        gameSpeed = clampSpeed(p.speed);
        writeLocal('gw-speed', gameSpeed);
        hud.setSpeed(gameSpeed);
      }
      if (Number.isFinite(p.volume)) {
        effectsVolume = p.volume;
        writeLocal('gw-fx-volume', effectsVolume);
        applyVolume();
        hud.setEffectsVolume(effectsVolume);
      }
      if (p.show) {
        hud.setLists(p.show);
        writeLocal('gw-lists', JSON.stringify(p.show));
      }
    },
  });
  if (net.online) {
    sendEvent = (e) => net.sendSim(e);
  } else {
    hud.setStatus('Simulator', 'sim');
    sendEvent = (e) => {
      queue.ingest(e);
      localGift(e);
    };
    resolveHistory();
  }
  hud.setTopGifters([]);
  setTimeout(resolveHistory, 3000);

  const choreo = new Choreographer({ actor, wall, tasks, sound, fx, hud, rig, queue, net, helpers, vehicles, useProxy: USE_PROXY });
  hud.onLayout = (layout) => net.saveLayout(layout);

  if (!CLEAN) {
    hud.buildPanel({
      online: net.online,
      onConnect: async (username, apiKey) => {
        hud.setConnectMessage(`Connecting to @${username.replace(/^@/, '')}…`);
        const res = await net.connect(username, apiKey);
        if (!res.ok) hud.setConnectMessage(res.error || 'Could not connect.', 'error');
      },
      onDisconnect: () => {
        net.disconnect();
        hud.setConnectMessage('Disconnected. The simulator still works.');
      },
      onSim: (kind) => {
        sound.unlock();
        if (kind === 'viewers') {
          // cycle: real count → 5 (likes painted) → 25 (likes as popups) → real
          simViewers = simViewers == null ? 5 : simViewers === 5 ? 25 : null;
          applyViewers();
          return;
        }
        sim.run(kind);
      },
      onReset: () => net.resetWall(),
      audio: {
        effectsVolume,
        tabSound,
        onEffectsVolume: (v) => {
          effectsVolume = v;
          writeLocal('gw-fx-volume', v);
          applyVolume();
          net.savePrefs({ volume: v });
        },
        onTabSound: (on) => {
          tabSound = on;
          writeLocal('gw-tab-sound', on ? '1' : '0');
          applyVolume();
        },
      },
      speed: gameSpeed,
      onSpeed: (v) => {
        gameSpeed = clampSpeed(v);
        writeLocal('gw-speed', gameSpeed);
        net.savePrefs({ speed: gameSpeed });
      },
      options,
      onOptions: (o) => {
        applyOptions(o);
        net.savePrefs({
          nameMode: options.nameMode, joins: options.joins, likePopups: options.likePopups,
          likeEvery: options.likeEvery,
        });
      },
      onLists: (show) => {
        writeLocal('gw-lists', JSON.stringify(show));
        net.savePrefs({ show });
      },
      onResetBoard: () => {
        if (net.online) net.resetLeaderboard();
        localBoard.clear();
        hud.setTopGifters([]);
      },
      onAuto: (on) => sim.setAuto(on),
    });
  }
  if (params.get('demo') === '1') sim.setAuto(true);
  applyOptions({});
  applyViewers();

  // ----- sound unlock -----
  // sound starts silently on the first click / key press; no on-screen prompt
  const unlock = () => sound.unlock();
  window.addEventListener('pointerdown', unlock);
  window.addEventListener('keydown', unlock);
  sound.unlock();

  // ----- layout: always a 9:16 stage -----
  function resize() {
    const ar = 9 / 16;
    let w = window.innerWidth, h = window.innerHeight;
    if (w / h > ar) w = h * ar;
    else h = w / ar;
    stage.style.width = `${w}px`;
    stage.style.height = `${h}px`;
    stage.style.setProperty('--s', String(w / 1080));
    const pr = Math.max(0.5, Math.min(window.devicePixelRatio || 1, 2, 1920 / h) * (LOW ? 0.75 : 1));
    renderer.setPixelRatio(pr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    fx.setViewport(h * pr, camera.fov);
    hud.relayout();
  }
  window.addEventListener('resize', resize);
  resize();

  // ----- director: one job at a time, never interrupted -----
  // Endless loop: real events first; when nobody is sending anything the artist
  // keeps walking right and spraying filler words. A filler stops at the next
  // letter as soon as a real event arrives, so viewers never wait long.
  let fillerId = 0;
  let lastWord = '';
  const fillerJob = () => {
    let word;
    do word = FILLER_WORDS[Math.floor(Math.random() * FILLER_WORDS.length)];
    while (word === lastWord && FILLER_WORDS.length > 1);
    lastWord = word;
    return { kind: 'filler', word, id: 'f' + ++fillerId, user: { id: 'filler', handle: '', name: '', avatar: '' }, count: 1, coins: 0 };
  };

  async function director() {
    await historyReady;
    const waiting = () => queue.size > 0;
    let posed = true;
    for (;;) {
      let job = queue.next();
      let opts = {};
      if (!job) {
        if (actor.climb) {
          await tasks.wait(0.25);
          continue;
        }
        // nobody waiting: face the camera briefly, then keep spraying fillers
        if (!posed) {
          posed = true;
          await actor.poseForCamera(waiting);
          continue;
        }
        if (!FILLER) {
          actor.idleLookCamera = true;
          await tasks.wait(0.25);
          continue;
        }
        job = fillerJob();
        opts = { shouldStop: waiting };
      }
      actor.idleLookCamera = false;
      try {
        await choreo.perform(job, opts);
      } catch (err) {
        console.error('Paint job failed, recovering', err);
        actor.recover();
        hud.clearNow();
        // never leave the camera stuck zoomed out or the crew standing around after an error
        if (!choreo._crewBusy) {
          rig.hold = null;
          truck.visible = lift.group.visible = false;
          for (const h of helpers) h.ch.root.visible = false;
        }
      }
      posed = false;
    }
  }

  // ----- render loop -----
  const clock = new THREE.Clock();
  let fpsEl = null, frames = 0, fpsT = 0;
  if (DEBUG) {
    fpsEl = document.createElement('div');
    fpsEl.className = 'fps';
    stage.appendChild(fpsEl);
  }
  rig.snap(actor.pos.x);

  renderer.setAnimationLoop(() => {
    const dt = Math.min(clock.getDelta(), 1 / 20);
    // the speed slider scales the artist's time (walking, painting, ladder, helpers, spray);
    // big steps are split so fast settings stay smooth and accurate
    const sdt = dt * gameSpeed;
    const steps = Math.max(1, Math.ceil(sdt / (1 / 30)));
    const sub = sdt / steps;
    for (let i = 0; i < steps; i++) {
      tasks.update(sub);
      actor.update(sub);
      for (const h of helpers) if (h.ch.root.visible) h.update(sub);
      if (lift.group.visible) lift.update(sub);
      fx.update(sub);
    }
    rig.update(dt, actor.climb ? actor.climb.x : actor.pos.x);
    wall.update(dt, rig.focusX);
    const f = rig.focusX;
    key.position.set(f - 7, 13, 9);
    key.target.position.set(f, 0, 0.5);
    work.position.set(f + 2.5, 5.4, 5);
    work.target.position.set(f - 0.3, 2, 0);
    renderer.render(scene, camera);
    if (fpsEl) {
      frames++;
      fpsT += dt;
      if (fpsT >= 0.5) {
        fpsEl.textContent = `${Math.round(frames / fpsT)} fps  ${renderer.info.memory.textures} tex  ${queue.size} queued`;
        frames = 0;
        fpsT = 0;
      }
    }
  });

  bootEl.classList.add('done');
  setTimeout(() => bootEl.remove(), 800);
  window.graffiti = { queue, sim, actor, wall };
  director();
}

main().catch((err) => {
  console.error(err);
  bootEl.textContent = `The wall could not start: ${err.message}. Check that this browser supports WebGL.`;
});

export { LANE_Z };
