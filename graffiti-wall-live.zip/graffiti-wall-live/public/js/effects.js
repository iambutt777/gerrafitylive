// effects.js — GPU particles for spray mist, paint splashes and golden sparks,
// plus short coloured light pulses. Particles live in fixed-size ring buffers,
// so nothing is allocated per frame and memory stays flat on long streams.

import * as THREE from 'three';

const VERT = /* glsl */ `
  attribute vec3 pcolor;
  attribute float psize;
  attribute float palpha;
  uniform float uScale;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    vColor = pcolor;
    vAlpha = palpha;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = psize * uScale / max(0.1, -mv.z);
    gl_Position = projectionMatrix * mv;
  }
`;

const FRAG = /* glsl */ `
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    float a = smoothstep(0.5, 0.12, d) * vAlpha;
    if (a < 0.01) discard;
    gl_FragColor = vec4(vColor, a);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

class Particles {
  constructor(scene, max, blending) {
    this.max = max;
    this.cursor = 0;
    this.pos = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max);
    this.alpha = new Float32Array(max);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max);
    this.a0 = new Float32Array(max);
    this.grav = new Float32Array(max);
    this.drag = new Float32Array(max);
    this.grow = new Float32Array(max);
    this.wallStop = new Uint8Array(max);
    const geo = new THREE.BufferGeometry();
    this.attrPos = new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage);
    this.attrCol = new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage);
    this.attrSize = new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage);
    this.attrAlpha = new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', this.attrPos);
    geo.setAttribute('pcolor', this.attrCol);
    geo.setAttribute('psize', this.attrSize);
    geo.setAttribute('palpha', this.attrAlpha);
    this.material = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 900 } },
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      depthWrite: false,
      blending,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
    scene.add(this.points);
    this.active = 0;
  }

  emit(p, v, color, size, life, alpha, opts = {}) {
    const i = this.cursor;
    this.cursor = (i + 1) % this.max;
    const i3 = i * 3;
    this.pos[i3] = p.x; this.pos[i3 + 1] = p.y; this.pos[i3 + 2] = p.z;
    this.vel[i3] = v.x; this.vel[i3 + 1] = v.y; this.vel[i3 + 2] = v.z;
    this.col[i3] = color.r; this.col[i3 + 1] = color.g; this.col[i3 + 2] = color.b;
    this.size[i] = size;
    this.life[i] = this.maxLife[i] = life;
    this.alpha[i] = this.a0[i] = alpha;
    this.grav[i] = opts.gravity || 0;
    this.drag[i] = opts.drag || 0;
    this.grow[i] = opts.grow || 0;
    this.wallStop[i] = opts.wallStop ? 1 : 0;
  }

  update(dt) {
    let alive = 0;
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.alpha[i] = 0;
        continue;
      }
      alive++;
      const i3 = i * 3;
      const k = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i3] *= k;
      this.vel[i3 + 1] = this.vel[i3 + 1] * k - this.grav[i] * dt;
      this.vel[i3 + 2] *= k;
      this.pos[i3] += this.vel[i3] * dt;
      this.pos[i3 + 1] += this.vel[i3 + 1] * dt;
      this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      if (this.wallStop[i] && this.pos[i3 + 2] < 0.012) {
        this.life[i] = 0;
        this.alpha[i] = 0;
        continue;
      }
      if (this.pos[i3 + 1] < 0) {
        this.pos[i3 + 1] = 0.005;
        this.vel[i3 + 1] *= -0.2;
        this.vel[i3] *= 0.5;
        this.vel[i3 + 2] *= 0.5;
      }
      this.size[i] += this.grow[i] * dt;
      const t = this.life[i] / this.maxLife[i];
      this.alpha[i] = this.a0[i] * Math.min(1, t * 2.2);
    }
    this.active = alive;
    this.attrPos.needsUpdate = true;
    this.attrAlpha.needsUpdate = true;
    this.attrSize.needsUpdate = true;
    this.attrCol.needsUpdate = true;
  }
}

const _c = new THREE.Color();
const _v = new THREE.Vector3();
const _d = new THREE.Vector3();
const _p = new THREE.Vector3();

export class Effects {
  constructor(scene) {
    this.scene = scene;
    this.mist = new Particles(scene, 4000, THREE.NormalBlending);
    this.glow = new Particles(scene, 1800, THREE.AdditiveBlending);
    this.lights = [0, 1].map(() => {
      const l = new THREE.PointLight(0xffd84d, 0, 14, 2);
      scene.add(l);
      return { light: l, t: 0, dur: 1, peak: 0 };
    });
    this.lightCursor = 0;
    this._sprayCarry = 0;
  }

  setViewport(heightPx, fovDeg) {
    const s = heightPx / (2 * Math.tan(THREE.MathUtils.degToRad(fovDeg) / 2));
    this.mist.material.uniforms.uScale.value = s;
    this.glow.material.uniforms.uScale.value = s;
  }

  /** Continuous spray from a nozzle toward a point on the wall. */
  spray(nozzle, target, color, dt, intensity = 1) {
    _c.set(color);
    _d.subVectors(target, nozzle);
    const dist = Math.max(0.05, _d.length());
    _d.divideScalar(dist);
    this._sprayCarry += dt * 520 * intensity;
    const n = Math.floor(this._sprayCarry);
    this._sprayCarry -= n;
    for (let k = 0; k < n; k++) {
      const speed = 4 + Math.random() * 3;
      _v.set(_d.x + (Math.random() - 0.5) * 0.22, _d.y + (Math.random() - 0.5) * 0.22, _d.z + (Math.random() - 0.5) * 0.1)
        .normalize().multiplyScalar(speed);
      this.mist.emit(nozzle, _v, _c, 0.012 + Math.random() * 0.022, (dist / speed) * (1 + Math.random() * 0.4) + 0.05, 0.55, { wallStop: true });
    }
    if (Math.random() < dt * 30 * intensity) {
      _p.copy(target).add(_v.set((Math.random() - 0.5) * 0.15, (Math.random() - 0.5) * 0.15, 0.05));
      _v.set((Math.random() - 0.5) * 0.15, 0.04 + Math.random() * 0.08, 0.12 + Math.random() * 0.1);
      this.mist.emit(_p, _v, _c, 0.14 + Math.random() * 0.1, 1.1 + Math.random() * 0.6, 0.09, { drag: 1.2, grow: 0.12 });
    }
  }

  /** Small drops flicked off a brush. */
  flick(point, color, count = 6) {
    _c.set(color);
    for (let k = 0; k < count; k++) {
      _v.set((Math.random() - 0.5) * 1.2, Math.random() * 1.2, 0.4 + Math.random() * 0.8);
      this.mist.emit(point, _v, _c, 0.018 + Math.random() * 0.02, 0.6 + Math.random() * 0.5, 0.95, { gravity: 9.8 });
    }
  }

  /** Paint bursting off the wall. Glowing splashes use additive particles. */
  splash(point, color, count = 40, glow = false) {
    _c.set(color);
    const sys = glow ? this.glow : this.mist;
    for (let k = 0; k < count; k++) {
      const a = Math.random() * Math.PI * 2;
      const r = 0.6 + Math.random() * 2.2;
      _v.set(Math.cos(a) * r, Math.sin(a) * r + 0.6, 0.6 + Math.random() * 1.6);
      sys.emit(point, _v, _c, 0.025 + Math.random() * 0.04, 0.5 + Math.random() * 0.8, glow ? 0.9 : 0.85, { gravity: 6, drag: 0.8 });
    }
  }

  sparks(point, count = 60, color = '#ffd84d', spread = 1) {
    _c.set(color);
    for (let k = 0; k < count; k++) {
      const a = Math.random() * Math.PI * 2;
      const r = (1 + Math.random() * 3.5) * spread;
      _v.set(Math.cos(a) * r, Math.sin(a) * r + 1.5, 0.5 + Math.random() * 2.5);
      this.glow.emit(point, _v, _c, 0.03 + Math.random() * 0.05, 0.6 + Math.random() * 1.0, 1, { gravity: 4.5, drag: 0.6 });
    }
  }

  /** A few glowing sparks left behind a rising firework rocket. */
  trail(pos, color = '#fff6c2') {
    _c.set(color);
    for (let k = 0; k < 3; k++) {
      _v.set((Math.random() - 0.5) * 0.4, -0.5 - Math.random() * 0.5, (Math.random() - 0.5) * 0.4);
      this.glow.emit(pos, _v, _c, 0.04 + Math.random() * 0.03, 0.35 + Math.random() * 0.3, 0.9, { gravity: 1.5 });
    }
  }

  /** Big golden burst across a rectangle of wall. */
  goldBurst(cx, cy, w, h) {
    for (let i = 0; i < 9; i++) {
      _p.set(cx + (Math.random() - 0.5) * w, cy + (Math.random() - 0.5) * h, 0.15);
      this.sparks(_p, 40, i % 3 === 0 ? '#ffffff' : '#ffd84d', 0.8);
    }
    this.pulse(_p.set(cx, cy, 2.2), '#ffcf40', 90, 1.8);
    this.pulse(_p.set(cx - w * 0.3, cy + h * 0.3, 1.6), '#fff1b0', 50, 1.2);
  }

  pulse(pos, color, peak, dur) {
    const slot = this.lights[this.lightCursor];
    this.lightCursor = (this.lightCursor + 1) % this.lights.length;
    slot.light.position.copy(pos);
    slot.light.color.set(color);
    slot.t = 0;
    slot.dur = dur;
    slot.peak = peak;
  }

  update(dt) {
    this.mist.update(dt);
    this.glow.update(dt);
    for (const s of this.lights) {
      if (s.peak <= 0) continue;
      s.t += dt;
      const k = s.t / s.dur;
      if (k >= 1) {
        s.light.intensity = 0;
        s.peak = 0;
      } else {
        s.light.intensity = s.peak * Math.sin(Math.min(1, k * 4) * Math.PI * 0.5) * (1 - k);
      }
    }
  }
}
