# Build the Android APK with GitHub

The APK is a small app that opens the game in a full-screen WebView. The game itself (and the TikTok connection) keeps running on your computer or online server, exactly as before. Enter that server's address the first time you open the app.

## 1. Put the project on GitHub
1. Create a new repository on github.com (private is fine).
2. Upload this whole folder, including the hidden `.github` folder. The easiest way is git:
   ```bash
   git init
   git add .
   git commit -m "Graffiti Wall"
   git branch -M main
   git remote add origin https://github.com/YOUR-NAME/YOUR-REPO.git
   git push -u origin main
   ```

## 2. Build
1. On GitHub open the **Actions** tab. If asked, enable workflows.
2. Choose **Build Android APK** then **Run workflow**. It also runs by itself whenever you change `android-app/`.
3. After about 5 to 8 minutes open the finished run and download **graffiti-wall-apk** from "Artifacts". Unzip it to get `app-debug.apk`.

## 3. Install
1. Send `app-debug.apk` to the phone and open it. Allow "Install unknown apps" when Android asks.
2. Start the game on the computer (`npm start`). Phone and computer must be on the same Wi-Fi.
3. Open the app and type the computer's address, for example `192.168.1.10:3000` (on Windows run `ipconfig` and use the IPv4 address). Press **Save and open**.
4. The app remembers it. On each launch you get 3 seconds to press **Change address**.

Use the small gear to open the control panel and the Up / down slider to slide it.

## Notes
- The APK is a debug build: fine to install directly, not for the Play Store.
- Allow Node.js through the Windows firewall (private networks) so the phone can reach port 3000.
- The screen stays on while the app is open, and it is locked to portrait.
- Change the app name or icon later in `android-app/capacitor.config.json`.
