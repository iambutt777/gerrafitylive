# Run the game online, always live

GitHub only stores the files. A hosting service runs them. The steps below use **Render** (works the same on Railway or Fly.io, which also read the Dockerfile).

## Cost and limits
- Needs an always-on instance. On Render that is the **Starter** plan (about $7 a month). Free instances go to sleep after 15 minutes without visitors, which would drop your TikTok connection.
- Add a **disk** so the painted wall survives restarts (also a paid feature on Render).
- Cloud servers can be refused by TikTok more often than a home PC. If it won't connect, add your free Euler API key (see below). If it still fails, run the server at home instead.

## 1. GitHub
Create a repository and upload two files to its main folder:
1. `graffiti-wall-live.zip`
2. `Dockerfile` (the one that comes next to this guide, which unzips the project)

Do not put any passwords in GitHub. They go into the host's settings below.

## 2. Render
1. render.com, sign in with GitHub, **New**, **Web Service**, pick your repository.
2. Language: **Docker**. Instance type: **Starter**.
3. Environment variables:
   | Name | Value |
   | --- | --- |
   | `ADMIN_PASSWORD` | a strong password only you know |
   | `TIKTOK_USERNAME` | your TikTok name without @ |
   | `EULER_API_KEY` | free key from eulerstream.com (optional but recommended) |
   | `DATA_DIR` | `/var/data` |
4. Advanced, **Add Disk**: mount path `/var/data`, size 1 GB.
5. **Create Web Service**. After a few minutes you get an address like `https://graffiti-wall-live.onrender.com`.

## 3. Use it
- **Phone app:** enter the https address once. The app asks for the admin password and remembers it.
- **OBS / TikTok LIVE Studio:** Browser source `https://YOUR-ADDRESS/?clean=1&key=YOUR_PASSWORD`, 1080 x 1920. The `key` lets this screen save the wall.
- **TikTok:** the server connects to `TIKTOK_USERNAME` by itself and checks again every minute after a LIVE ends, so go live and it connects. You can still change the account in the control panel.
- Viewers who open the address can only watch. Without the password nobody can change settings, clear the wall or connect another account.

## Updating
Upload a new zip with the same name to GitHub (Add file, Upload files). Render rebuilds automatically.
