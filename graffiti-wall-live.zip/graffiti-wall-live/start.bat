@echo off
title Graffiti Wall LIVE
cd /d "%~dp0"

echo.
echo  ==========================================
echo    Graffiti Wall LIVE
echo  ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed.
  echo  Your browser will open nodejs.org - install the LTS version,
  echo  then double-click start.bat again.
  start "" https://nodejs.org
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\express" goto install
if not exist "node_modules\socket.io" goto install
if not exist "node_modules\tiktok-live-connector" goto install
goto run

:install
echo  First start: installing the game files. This takes a minute...
echo.
call npm install --ignore-scripts
if errorlevel 1 (
  echo.
  echo  The install failed. Check your internet connection and try again.
  pause
  exit /b 1
)

:run
echo.
echo  Starting... the control panel opens in your browser.
echo  Connect your TikTok LIVE from the control panel.
echo  OBS / TikTok LIVE Studio browser source: http://localhost:3000/?clean=1  (1080 x 1920)
echo  Keep this window open while you stream. Close it to stop the game.
echo.

start "" /min cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"

call npm start

echo.
echo  The game has stopped.
pause
